// Temporary observation only: no altered operation, cancellation, retry or deadline.
import { AsyncLocalStorage } from 'node:async_hooks';
const context = new AsyncLocalStorage<{ owner: string }>();
export function journalScope<T>(owner: string, run: () => Promise<T>): Promise<T> { return context.run({ owner }, run); }
let sequence = 0;
const active = new Map<number, { operation: string; owner: string; started: number }>();
const totals = new Map<string, { count: number; failures: number; totalMs: number; maxMs: number; codes: Record<string, number> }>();
export function journalOwner(owner: string): void { const current = context.getStore(); if (current) current.owner = owner; }
export function journalPending() {
  const now = performance.now();
  return [...active.values()].map(item => ({ operation: item.operation, owner: item.owner, elapsedMs: now - item.started }));
}
export function journalTotals() { return [...totals].map(([operation, values]) => ({ operation, ...values })); }
export async function observeJournal<T>(operation: string, run: () => Promise<T>): Promise<T> {
  const id = ++sequence, item = { operation, owner: context.getStore()?.owner ?? 'outside model case', started: performance.now() };
  active.set(id, item);
  let code: string | undefined;
  try { return await run(); }
  catch (error) {
    code = (error as { code?: string }).code ?? 'error';
    throw error;
  } finally {
    const elapsedMs = performance.now() - item.started;
    active.delete(id);
    const total = totals.get(operation) ?? { count: 0, failures: 0, totalMs: 0, maxMs: 0, codes: {} };
    total.count++; total.totalMs += elapsedMs; total.maxMs = Math.max(total.maxMs, elapsedMs);
    if (code) { total.failures++; total.codes[code] = (total.codes[code] ?? 0) + 1; }
    totals.set(operation, total);
    // Diagnostic output threshold only; it does not affect any operation/test deadline.
    if (elapsedMs >= 100) console.error('QUA_STORAGE_SPAN', JSON.stringify({ operation, owner: item.owner, elapsedMs, code }));
  }
}
