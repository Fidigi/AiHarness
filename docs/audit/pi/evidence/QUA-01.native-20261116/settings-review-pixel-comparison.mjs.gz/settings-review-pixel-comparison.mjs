import sharp from 'sharp';
const ref = await sharp('/app/e2e/settings-administration-live.spec.ts-snapshots/settings-readback-fr-dark-1280-chromium-linux.png').ensureAlpha().raw().toBuffer({ resolveWithObject: true });
for (const file of ['unaligned.png', 'pixel-aligned.png', 'settings-readback-fr-dark-1280-actual.png']) {
  const img = await sharp('/evidence/' + file).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  if (ref.info.width !== img.info.width || ref.info.height !== img.info.height) {
    console.log(JSON.stringify({ file, reference: ref.info, actual: img.info, comparison: 'dimension mismatch' }));
    continue;
  }
  let count = 0, sum = 0;
  for (let i = 0; i < ref.data.length; i += 4) {
    let different = false;
    for (let k = 0; k < 3; k++) {
      const d = Math.abs(ref.data[i + k] - img.data[i + k]);
      different ||= d !== 0; sum += d;
    }
    count += Number(different);
  }
  console.log(JSON.stringify({ file, reference: ref.info, actual: img.info, exactlyDifferentPixels: count, rgbAbsoluteError: sum }));
}
