#!/bin/bash
set -eu
image=aih-qua01:native-20261116
container=qua01-native-20261116-targeted
docker create --name "$container" --network none -e CI=true "$image" bash -c 'npm test -- packages/core/src/sdk/public-consumer.test.ts packages/cli/src/commands/codex-login.test.ts packages/web/src/components/settings-locale.test.ts && npm test -- tests/functional-parity/installed-executable.test.ts -t "dispatches native Ant Ling"'
for file in packages/core/src/sdk/public-consumer.test.ts packages/cli/src/commands/codex-login.test.ts packages/web/src/components/settings-locale.test.ts tests/functional-parity/installed-executable.test.ts; do
  docker cp "/app/projects/AiHarness/$file" "$container:/app/$file"
done
docker start --attach "$container"
