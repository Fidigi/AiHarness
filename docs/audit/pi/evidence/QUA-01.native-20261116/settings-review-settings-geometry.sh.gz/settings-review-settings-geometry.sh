#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-settings-geometry-fixed
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs e2e/settings-administration-live.spec.ts '--grep=fr/dark/1280' --reporter=line,json || exit $?
docker cp "$base/settings-review/settings-geometry.spec.ts" "$container:/app/e2e/settings-administration-live.spec.ts" || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/settings-geometry-fixed-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/settings-geometry-fixed-artifacts/"
exit "$status"
