import fs from 'node:fs';
import ts from 'typescript';
const sourcePath = '/app/packages/core/src/sessions/session-manager.ts';
const source = fs.readFileSync(sourcePath, 'utf8');
const tree = ts.createSourceFile(sourcePath, source, ts.ScriptTarget.Latest, true);
const edits = [];
function name(node) {
  if (!ts.isCallExpression(node)) return node.getText(tree);
  const callee = node.expression;
  if (ts.isPropertyAccessExpression(callee) && ['catch', 'finally'].includes(callee.name.text)) return name(callee.expression);
  return callee.getText(tree);
}
function visit(node) {
  if (ts.isAwaitExpression(node)) {
    const operation = name(node.expression);
    if (/^(?:fs\.|handle\.|directoryHandle\.|directory\??\.|acquireSessionLock$|readStableDirectoryEntries$|releaseStableLockPath$|releaseInventory\??$|release$|previous$|this\.clearInProgress$)/.test(operation)
      || node.expression.getText(tree).includes('setTimeout(resolve, SESSION_LOCK_RETRY_MS)')) {
      const start = node.expression.getStart(tree), end = node.expression.end;
      const line = tree.getLineAndCharacterOfPosition(start).line + 1;
      const label = `session-manager:${line}:${operation.startsWith('new Promise') ? 'lock-retry-wait' : operation}`;
      edits.push({ start, end, label, text: `observeJournal(${JSON.stringify(label)}, () => (${source.slice(start, end)}))` });
      return;
    }
  }
  ts.forEachChild(node, visit);
}
visit(tree);
let result = source;
for (const edit of edits.sort((a, b) => b.start - a.start)) result = result.slice(0, edit.start) + edit.text + result.slice(edit.end);
result = "import { observeJournal } from './journal-observation.js';\n" + result;
const checked = ts.createSourceFile(sourcePath, result, ts.ScriptTarget.Latest, true);
if (checked.parseDiagnostics.length) throw new Error(ts.formatDiagnosticsWithColorAndContext(checked.parseDiagnostics, {
  getCurrentDirectory: () => '/app', getCanonicalFileName: value => value, getNewLine: () => '\n',
}));
fs.mkdirSync('/observation', { recursive: true });
fs.writeFileSync('/observation/session-manager.ts', result);
fs.writeFileSync('/observation/wrapped-operations.json', JSON.stringify(edits.map(({ label }) => label).reverse(), null, 2) + '\n');
console.log('Instrumented await sites:', edits.length);
