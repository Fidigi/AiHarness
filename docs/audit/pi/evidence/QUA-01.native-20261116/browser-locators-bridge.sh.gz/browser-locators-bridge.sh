#!/bin/bash
set -u
container=qua01-native-20261116-browser-locators-bridge
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs e2e/chat.spec.ts e2e/settings.spec.ts '--grep=utilise le fournisseur|présente les fournisseurs|filtre le catalogue|gère OAuth' --reporter=line,json || exit $?
for file in e2e/chat.spec.ts e2e/settings.spec.ts; do docker cp "/app/projects/AiHarness/$file" "$container:/app/$file" || exit $?; done
docker start --attach "$container"
status=$?
mkdir -p /tmp/aih-qua01-native-20261116/evidence/locator-bridge-artifacts
docker cp "$container:/app/test-results/." /tmp/aih-qua01-native-20261116/evidence/locator-bridge-artifacts/
exit "$status"
