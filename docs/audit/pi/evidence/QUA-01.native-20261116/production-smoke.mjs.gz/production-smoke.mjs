import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm } from 'node:fs/promises';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createRequire } from 'node:module';
import { setTimeout as delay } from 'node:timers/promises';
import { createAgentSession } from '/app/packages/core/dist/index.js';
import { testCodemodeSandbox } from '/app/packages/core/dist/tools/codemode.js';
const execute = promisify(execFile);
const root = await mkdtemp('/tmp/aih-qua01-prod-');
const cwd = root + '/work';
const checks = [];
const environment = { ...process.env, HOME: root, AI_HARNESS_DATA_DIR: root + '/data',
  AI_HARNESS_AGENT_DIR: root + '/agent', AI_HARNESS_OFFLINE: '1', AI_HARNESS_WEB_HOSTNAME: '127.0.0.1',
  AI_HARNESS_WEB_NO_OPEN: '1', AI_HARNESS_WEB_PORT: '3080' };
let web, sdk;
try {
  assert.notEqual(process.getuid(), 0); checks.push('non-root');
  await mkdir(environment.AI_HARNESS_AGENT_DIR);
  await mkdir(cwd);
  const cli = '/app/packages/cli/dist/index.js';
  const help = await execute(process.execPath, [cli, '--help'], { cwd, env: environment, timeout: 5000 });
  assert.equal(help.stderr, ''); assert.match(help.stdout, /ai-harness \[options\]/); checks.push('CLI help outside checkout');
  const printOperation = execute(process.execPath, [cli, '--offline', '--no-approve', '--no-extensions',
    '--no-context-files', '--no-session', '--model', 'mock/mock-model', '--print', 'Native smoke'],
    { cwd, env: environment, timeout: 10000 });
  printOperation.child.stdin.end();
  const printed = await printOperation;
  assert.match(printed.stdout, /\[Mock AI Response\]/); checks.push('CLI mock turn');
  sdk = await createAgentSession({ cwd, allowedRoots: [cwd], isProjectTrusted: () => true,
    provider: { kind: 'config', config: { type: 'mock' } } });
  assert.equal((await sdk.promptAndWait('Native SDK smoke')).phase, 'completed');
  assert.equal(sdk.messages().filter(message => message.role === 'assistant').at(-1).content, '[Mock AI Response]');
  await sdk.dispose(); sdk = undefined; checks.push('public SDK completed turn and disposal');
  const sandbox = await testCodemodeSandbox();
  assert.equal(sandbox.state, 'passed'); checks.push('production QuickJS worker');
  const require = createRequire('/app/packages/server/package.json');
  const pty = require('node-pty');
  await new Promise((resolve, reject) => {
    const terminal = pty.spawn('/bin/sh', ['-c', 'printf "qua01-pty-é"'], { cwd, env: environment, cols: 80, rows: 24 });
    let text = ''; const timer = setTimeout(() => { terminal.kill(); reject(new Error('PTY smoke deadline')); }, 5000);
    terminal.onData(data => { text += data; }); terminal.onExit(({ exitCode }) => {
      clearTimeout(timer); try { assert.equal(exitCode, 0); assert.equal(text, 'qua01-pty-é'); resolve(); } catch (error) { reject(error); }
    });
  }); checks.push('native PTY UTF-8 and exit');
  let output = ''; let webExit;
  web = spawn('ai-harness-web', ['--hostname', '127.0.0.1', '--port', '3080', '--no-open'], { cwd, env: environment, stdio: ['ignore', 'pipe', 'pipe'] });
  const settled = new Promise((resolve, reject) => { web.on('error', reject); web.on('exit', (code, signal) => { webExit = { code, signal }; resolve(webExit); }); });
  web.stdout.on('data', data => { output += data; }); web.stderr.on('data', data => { output += data; });
  const deadline = Date.now() + 15000;
  while (!output.includes('AiHarness Web disponible')) {
    if (webExit) throw new Error(`Web exited before readiness: ${JSON.stringify(webExit)}; ${output}`);
    if (Date.now() > deadline) throw new Error('Web readiness deadline: ' + output);
    await delay(50);
  }
  const base = 'http://127.0.0.1:3080';
  const health = await fetch(base + '/health'); assert.equal(health.status, 200);
  const page = await fetch(base + '/'); assert.equal(page.status, 200); const html = await page.text();
  const asset = html.match(/src="([^"]+\.js)"/); assert.ok(asset); const javascript = await fetch(new URL(asset[1], base));
  assert.equal(javascript.status, 200); assert.ok((await javascript.text()).length > 100);
  checks.push('PATH Web launcher, real HTTP health/index/JavaScript');
  web.kill('SIGTERM'); assert.deepEqual(await settled, { code: 0, signal: null }); web = undefined;
  checks.push('Web graceful SIGTERM');
  console.log(JSON.stringify({ node: process.version, uid: process.getuid(), checks, sandbox }, null, 2));
} finally {
  web?.kill('SIGKILL'); await sdk?.dispose(); await rm(root, { recursive: true, force: true });
}
