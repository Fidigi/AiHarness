#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-preload-order
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs --config=e2e/interaction-queue.config.ts e2e/interaction-single-asset-load.spec.ts '--grep=failed imports stay cached' --reporter=line,json || exit $?
docker cp "$base/import-review/preload-order.spec.ts" "$container:/app/e2e/interaction-single-asset-load.spec.ts" || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/preload-order-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/preload-order-artifacts/"
exit "$status"
