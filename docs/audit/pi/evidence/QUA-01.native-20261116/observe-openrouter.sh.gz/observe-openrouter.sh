#!/bin/bash
set -eu
container=qua01-native-20261116-openrouter-observation
docker create --name "$container" --network none -e CI=true aih-qua01:native-final-20261116 npm test -- packages/core/src/providers/openrouter-completions.test.ts
docker cp /tmp/aih-qua01-native-20261116/openrouter-observation.test.ts "$container:/app/packages/core/src/providers/openrouter-completions.test.ts"
docker start --attach "$container"
