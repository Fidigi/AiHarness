#!/bin/bash
set -u
container=qua01-native-20261116-interaction-observation
docker create --name "$container" --network none --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs --config=e2e/interaction-queue.config.ts e2e/interaction-single-asset-load.spec.ts '--grep=failed imports stay cached' --reporter=line,json || exit $?
docker cp /tmp/aih-qua01-native-20261116/interaction-observation.spec.ts "$container:/app/e2e/interaction-single-asset-load.spec.ts" || exit $?
docker start --attach "$container"
status=$?
mkdir -p /tmp/aih-qua01-native-20261116/evidence/interaction-observation-artifacts
docker cp "$container:/app/test-results/." /tmp/aih-qua01-native-20261116/evidence/interaction-observation-artifacts/
exit "$status"
