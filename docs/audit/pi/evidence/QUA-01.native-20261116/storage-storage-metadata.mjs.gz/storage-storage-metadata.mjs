import fs from 'node:fs';
import os from 'node:os';
const paths = ['/proc/pressure/io', '/proc/pressure/cpu', '/sys/fs/cgroup/io.stat', '/sys/fs/cgroup/io.pressure',
  '/sys/fs/cgroup/cpu.stat', '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/cpu.pressure', '/sys/fs/cgroup/memory.events'];
const counters = Object.fromEntries(paths.map(path => {
  try { return [path, fs.readFileSync(path, 'utf8')]; }
  catch (error) { return [path, { unavailable: error.code }]; }
}));
console.log('QUA_STORAGE_ENV', JSON.stringify({ stage: process.argv[2], at: new Date().toISOString(),
  tmp: os.tmpdir(), filesystem: fs.statfsSync(os.tmpdir()), counters }));
