#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-minimap-references
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs e2e/visual.spec.ts '--grep=Régression visuelle des historiques paginés' --reporter=line,json || exit $?
for variant in desktop-dark tablet-dark mobile-light; do
  file=e2e/visual.spec.ts-snapshots/history-minimap-$variant-chromium-linux.png
  docker cp "/app/projects/AiHarness/$file" "$container:/app/$file" || exit $?
done
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/minimap-reference-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/minimap-reference-artifacts/"
exit "$status"
