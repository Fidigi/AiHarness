#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-settings-references
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs e2e/settings-administration-live.spec.ts --reporter=line,json || exit $?
for variant in en-light-1280 en-dark-390 fr-light-390 fr-dark-1280; do
  file=e2e/settings-administration-live.spec.ts-snapshots/settings-readback-$variant-chromium-linux.png
  docker cp "/app/projects/AiHarness/$file" "$container:/app/$file" || exit $?
done
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/settings-reference-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/settings-reference-artifacts/"
exit "$status"
