#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-storage-observation
docker create --name "$container" --network none -e CI=true aih-qua01:native-final-20261116 bash -c 'node /app/storage-metadata.mjs before; npm test -- packages/core/src/providers/openrouter-completions.test.ts; result=$?; node /app/storage-metadata.mjs after; exit "$result"' || exit $?
docker cp "$base/storage-review/session-manager.ts" "$container:/app/packages/core/src/sessions/session-manager.ts" || exit $?
docker cp "$base/storage-review/journal-observation.ts" "$container:/app/packages/core/src/sessions/journal-observation.ts" || exit $?
docker cp "$base/storage-review/openrouter-storage.test.ts" "$container:/app/packages/core/src/providers/openrouter-completions.test.ts" || exit $?
docker cp "$base/storage-review/storage-metadata.mjs" "$container:/app/storage-metadata.mjs" || exit $?
docker inspect "$container" --format '{{json .Id}} {{json .Image}} {{json .Mounts}} {{json .HostConfig.Tmpfs}} {{json .HostConfig.NetworkMode}}' > "$base/storage-review/container.txt"
docker start --attach "$container"
exit $?
