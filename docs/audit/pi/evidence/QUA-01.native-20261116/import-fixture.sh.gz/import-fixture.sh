#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-import-fixture
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-final-20261116 node .docker/run-e2e.mjs --config=e2e/interaction-queue.config.ts e2e/interaction-single-asset-load.spec.ts --reporter=line,json || exit $?
docker cp /app/projects/AiHarness/e2e/interaction-single-asset-load.spec.ts "$container:/app/e2e/interaction-single-asset-load.spec.ts" || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/import-fixture-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/import-fixture-artifacts/"
exit "$status"
