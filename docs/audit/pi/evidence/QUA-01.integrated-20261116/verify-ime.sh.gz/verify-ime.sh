#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-ime-monotonic
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-integrated-20261116 node .docker/run-e2e.mjs e2e/markdown.spec.ts --reporter=line,json || exit $?
for file in e2e/markdown.spec.ts packages/web/src/components/ChatView.tsx; do
  docker cp "/app/projects/AiHarness/$file" "$container:/app/$file" || exit $?
done
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/ime-monotonic-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/ime-monotonic-artifacts/"
exit "$status"
