# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: markdown.spec.ts >> newline mode continues CJK lists at the caret while IME confirmation and sending never continue
- Location: e2e/markdown.spec.ts:202:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: locator('.input-container textarea')
Timeout: 5000ms
- Expected  - 2
+ Received  + 1

- - 
-  tail
+ - selected tail

Call log:
  - Expect "toHaveValue" locator('.input-container textarea') with timeout 5000ms
  - waiting for locator('.input-container textarea')
    14 × locator resolved to <textarea rows="1" aria-label="Message composer" placeholder="Type your message... (Provider: mock)">- selected tail</textarea>
       - unexpected value "- selected tail"

```

```yaml
- textbox "Message composer":
  - /placeholder: "Type your message... (Provider: mock)"
  - text: "- selected tail"
```

# Test source

```ts
  126 |   await input.press('Shift+Enter');
  127 |   await expect(input).toHaveValue('- [x] completed\n- [ ] ');
  128 |   await input.press('Shift+Enter');
  129 |   await expect(input).toHaveValue('- [x] completed\n');
  130 |   await input.fill('009. item');
  131 |   await input.press('Shift+Enter');
  132 |   await expect(input).toHaveValue('009. item\n010. ');
  133 |   await input.fill('```text\n- code');
  134 |   await input.press('Shift+Enter');
  135 |   await expect(input).toHaveValue('```text\n- code\n');
  136 |   expect(api.requests.some(request => request.path === '/api/agent/runs' && request.method === 'POST')).toBe(false);
  137 | });
  138 | 
  139 | test('clipboard metadata is inert before filtering and bounded without losing plaintext', async ({ page }) => {
  140 |   const requests: string[] = [];
  141 |   page.on('request', request => { if (request.url().includes('clipboard.invalid')) requests.push(request.url()); });
  142 |   await page.route('https://clipboard.invalid/**', route => route.fulfill({ status: 200, body: '' }));
  143 |   await installMockApi(page, { sessions: [mockSession('markdown-security', 'Clipboard security')] });
  144 |   await page.goto('/chat/markdown-security');
  145 |   const input = page.locator('.input-container textarea');
  146 |   await expect(input).toBeVisible();
  147 |   const original = '  First\r\n\t第二\r\n\r\nlast  ';
  148 |   expect(await page.evaluate(async text => {
  149 |     const path = '/src/components/markdown-paste.ts';
  150 |     const helper = await import(path);
  151 |     return helper.clipboardTextToMarkdown(text, '<div>First</div><div>第二</div><div>last</div>');
  152 |   }, original)).toBe(original);
  153 |   await page.evaluate(() => {
  154 |     customElements.define('clipboard-probe', class extends HTMLElement {
  155 |       constructor() { super(); (window as Window & { __clipboardInjected?: boolean }).__clipboardInjected = true; }
  156 |     });
  157 |   });
  158 |   const paste = async (text: string, html: string) => {
  159 |     await input.fill('');
  160 |     await input.evaluate((node: HTMLTextAreaElement, payload) => {
  161 |       const clipboard = new DataTransfer();
  162 |       clipboard.setData('text/plain', payload.text);
  163 |       clipboard.setData('text/html', payload.html);
  164 |       node.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: clipboard }));
  165 |     }, { text, html });
  166 |   };
  167 |   await paste('one\r\nDocs\n\tlast  ', `
  168 |     <clipboard-probe></clipboard-probe>
  169 |     <img src="https://clipboard.invalid/img" onerror="window.__clipboardInjected=true">
  170 |     <iframe src="https://clipboard.invalid/frame"></iframe>
  171 |     <iframe srcdoc='<img src="https://clipboard.invalid/srcdoc">'></iframe>
  172 |     <object data="https://clipboard.invalid/object"></object><embed src="https://clipboard.invalid/embed">
  173 |     <link rel="stylesheet" href="https://clipboard.invalid/css">
  174 |     <style>@import url(https://clipboard.invalid/import); div { background: url(https://clipboard.invalid/bg); }</style>
  175 |     <svg><image href="https://clipboard.invalid/svg" /></svg>
  176 |     <video poster="https://clipboard.invalid/poster"><source src="https://clipboard.invalid/video"></video>
  177 |     <audio src="https://clipboard.invalid/audio"></audio>
  178 |     <script src="https://clipboard.invalid/script">window.__clipboardInjected=true</script>
  179 |     <div>one</div><div><a href="https://example.com/docs">Docs</a></div><div>last</div>`);
  180 |   // The textarea uses the browser's LF normalization, but the helper never rewrites plaintext.
  181 |   await expect(input).toHaveValue('one\n[Docs](https://example.com/docs)\n\tlast  ');
  182 |   await page.waitForTimeout(500);
  183 |   expect(requests).toEqual([]);
  184 |   expect(await page.evaluate(() => '__clipboardInjected' in window)).toBe(false);
  185 |   await paste('safe Docs unsafe', '<a href="javascript:alert(1)">unsafe</a><a href="https://example.com">Docs</a>');
  186 |   await expect(input).toHaveValue('safe [Docs](https://example.com) unsafe');
  187 |   // Every overflow discards only optional metadata, not any plain user text.
  188 |   const text = '  Docs\n\t原文  '.repeat(10_000);
  189 |   for (const html of [
  190 |     'x'.repeat(65_537),
  191 |     '<span></span>'.repeat(1_025) + '<a href="https://example.com">Docs</a>',
  192 |     '<a href="https://example.com">Docs</a>'.repeat(33),
  193 |     '<a href="https://example.com">' + 'x'.repeat(1_025) + '</a>',
  194 |     '<a href="https://example.com/' + 'x'.repeat(2_048) + '">Docs</a>',
  195 |   ]) {
  196 |     await paste(text, html);
  197 |     await expect(input).toHaveValue(text);
  198 |   }
  199 |   expect(requests).toEqual([]);
  200 | });
  201 | 
  202 | test('newline mode continues CJK lists at the caret while IME confirmation and sending never continue', async ({ page }) => {
  203 |   await page.addInitScript(() => localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({ version: 4, sendMode: 'mod-enter' })));
  204 |   const api = await installMockApi(page, { sessions: [mockSession('markdown-ime', 'IME lists')] });
  205 |   await page.goto('/chat/markdown-ime');
  206 |   const input = page.locator('.input-container textarea');
  207 |   await expect(input).toBeVisible();
  208 |   await input.fill('1、项目');
  209 |   await input.press('Enter');
  210 |   await expect(input).toHaveValue('1、项目\n2、');
  211 |   await expect.poll(() => input.evaluate((node: HTMLTextAreaElement) => node.selectionStart)).toBe(7);
  212 |   await input.fill('- composing');
  213 |   await input.evaluate((node: HTMLTextAreaElement) => {
  214 |     node.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
  215 |     node.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', shiftKey: true, isComposing: true, bubbles: true, cancelable: true }));
  216 |     node.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 229, bubbles: true, cancelable: true }));
  217 |     node.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: '项目' }));
  218 |     node.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
  219 |   });
  220 |   await expect(input).toHaveValue('- composing');
  221 |   expect(api.requests.filter(request => request.path === '/api/agent/runs' && request.method === 'POST')).toHaveLength(0);
  222 |   await page.waitForTimeout(150);
  223 |   await input.fill('- selected tail');
  224 |   await input.evaluate((node: HTMLTextAreaElement) => node.setSelectionRange(2, 10));
  225 |   await input.press('Enter');
> 226 |   await expect(input).toHaveValue('- \n tail');
      |                       ^ Error: expect(locator).toHaveValue(expected) failed
  227 |   await input.fill('- send item');
  228 |   await input.press('Control+Enter');
  229 |   await expect.poll(() => api.requests.filter(request => request.path === '/api/agent/runs' && request.method === 'POST').length).toBe(1);
  230 |   const sent = api.requests.find(request => request.path === '/api/agent/runs' && request.method === 'POST');
  231 |   expect(sent?.body).toMatchObject({ input: '- send item' });
  232 | });
  233 | 
  234 | test('file preview and noninteractive minimap share currency, CJK and math semantics', async ({ page }) => {
  235 |   const content = '**Price: $20/month**\nPlus a $6 fee. Formula: $2 + 2 = 4$.\n\nhttps://example.com/docs，后面';
  236 |   await installMockApi(page, { sessions: [mockSession('markdown-preview', 'Preview', [
  237 |     ...Array.from({ length: 8 }, (_, index) => ({ role: 'assistant' as const, content: `Earlier ${index}` })),
  238 |     { role: 'assistant', content },
  239 |   ])], workspaceFiles: [
  240 |     { path: 'README.md', language: 'markdown', content },
  241 |   ] });
  242 |   await page.goto('/chat/markdown-preview');
  243 |   const chat = page.locator('.message.assistant .markdown-content');
  244 |   await expect(chat.locator('.katex')).toHaveCount(1);
  245 |   await page.getByRole('button', { name: 'Conversation map', exact: true }).click();
  246 |   const minimap = page.locator('.conversation-minimap');
  247 |   await expect(minimap.locator('.markdown-compact').filter({ hasText: 'Price:' })).toContainText('Price: $20/month Plus a $6 fee. Formula: 2 + 2 = 4.');
  248 |   await expect(minimap.locator('.minimap-entry a, .minimap-entry button')).toHaveCount(0);
  249 |   await expect(minimap.locator('.markdown-compact').filter({ hasText: 'Price:' })).not.toContainText('**');
  250 |   const mapEntry = minimap.locator('.minimap-entry').filter({ hasText: 'Price:' });
  251 |   await expect(mapEntry).toHaveAccessibleName('assistant: Price: $20/month Plus a $6 fee. Formula: 2 + 2 = 4. https://example.com/docs，后面');
  252 |   expect(await mapEntry.getAttribute('title')).toBeNull();
  253 |   const panel = page.getByRole('complementary', { name: 'Workspace explorer' });
  254 |   await panel.locator('.file-name').filter({ hasText: 'README.md' }).click();
  255 |   await panel.getByRole('button', { name: 'Preview', exact: true }).click();
  256 |   const preview = panel.locator('.markdown-preview .markdown-content');
  257 |   await expect(preview.locator('.katex')).toHaveCount(1);
  258 |   await expect(preview.getByRole('link', { name: 'https://example.com/docs' })).toHaveAttribute('href', 'https://example.com/docs');
  259 |   await expect(preview.locator('strong')).toHaveText('Price: $20/month');
  260 | });
  261 | 
  262 | test('raw-text blocks and executable URLs remain inert while later Markdown survives', async ({ page }) => {
  263 |   const content = 'Use a <textarea> here\nand a button\nplease\n\n<script>window.__markdownInjected=true</script>\n\n$20 <img src="x" onerror="window.__markdownInjected=true"> $6 [unsafe](javascript:alert(1))\n\n**safe end**';
  264 |   await installMockApi(page, { sessions: [mockSession('markdown-raw', 'Raw text', [{ role: 'user', content }])] });
  265 |   await page.goto('/chat/markdown-raw');
  266 |   const markdown = page.locator('.message.user .markdown-content');
  267 |   await expect(markdown.locator('strong')).toHaveText('safe end');
  268 |   await expect(markdown.locator('script, textarea, img, [onerror]')).toHaveCount(0);
  269 |   await expect(markdown.locator('p').filter({ hasText: 'Use a' }).locator('br')).toHaveCount(0);
  270 |   await expect(markdown.locator('.katex')).toHaveCount(0);
  271 |   expect(await page.evaluate(() => '__markdownInjected' in window)).toBe(false);
  272 |   await expect(markdown.getByRole('link')).toHaveCount(0);
  273 | });
  274 | 
```