#!/bin/bash
set -eu
container=qua01-native-20261116-integrated-smoke
docker create --name "$container" --network none aih-qua01:native-integrated-prod-20261116 node /tmp/production-smoke.mjs
docker cp /tmp/aih-qua01-native-20261116/evidence/production-smoke.mjs "$container:/tmp/production-smoke.mjs"
docker start --attach "$container"
