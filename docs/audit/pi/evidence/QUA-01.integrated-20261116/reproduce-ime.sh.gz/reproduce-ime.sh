#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-ime-wall-clock
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-integrated-20261116 node .docker/run-e2e.mjs e2e/markdown.spec.ts '--grep=newline mode continues' --reporter=line,json || exit $?
docker cp /app/projects/AiHarness/e2e/markdown.spec.ts "$container:/app/e2e/markdown.spec.ts" || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/ime-wall-clock-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/ime-wall-clock-artifacts/"
exit "$status"
