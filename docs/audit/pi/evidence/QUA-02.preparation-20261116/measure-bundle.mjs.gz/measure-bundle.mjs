import { readFileSync, readdirSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const root='/app/packages/web/dist';
const html=readFileSync(`${root}/index.html`,'utf8');
const entry=html.match(/<script[^>]+src="\/assets\/([^"?]+\.js)"/)[1];
const files=readdirSync(`${root}/assets`).filter(x=>/\.(?:m?js|css)$/.test(x)).sort();
const assets=files.map(file=>{const b=readFileSync(`${root}/assets/${file}`);return {file,raw:b.length,gzip:gzipSync(b).length,sha256:createHash('sha256').update(b).digest('hex')};});
const eager=new Set([entry]);
for(const m of html.matchAll(/(?:src|href)="\/assets\/([^"?]+\.(?:js|css))"/g))eager.add(m[1]);
const pending=[entry];
while(pending.length){const file=pending.pop();const text=readFileSync(`${root}/assets/${file}`,'utf8');for(const m of text.matchAll(/(?:from\s*|import\s*)["']\.\/([^"']+\.js)["']/g)){if(!eager.has(m[1])){eager.add(m[1]);pending.push(m[1]);}}}
console.log(JSON.stringify({image:'sha256:bb7fb54843773414206d8e23e202691948f28cb2bc5d9aff1ae1ef5501b63513',entry:assets.find(x=>x.file===entry),eager:[...eager].sort(),eagerGzip:[...eager].reduce((a,x)=>a+assets.find(y=>y.file===x).gzip,0),assets},null,2));
