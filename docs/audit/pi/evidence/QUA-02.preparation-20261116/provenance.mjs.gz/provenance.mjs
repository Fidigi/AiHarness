import { readFileSync, lstatSync, readlinkSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
const commit='111c5da1fd82eb847b66811ab30479e8ad0a866e';
const base='/tmp/aih-qua02-20261116';
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',a,{encoding:'utf8'}).trim();
let checked=0; const differences=[];
for(const entry of execFileSync('git',['ls-tree','-rz',commit]).toString().split('\0').filter(Boolean)){
 const [meta,file]=entry.split('\t'); const [mode,type,hash]=meta.split(' '); if(type!=='blob')throw Error(type);
 const p=`${base}/source/${file}`, stat=lstatSync(p); const content=mode==='120000'?Buffer.from(readlinkSync(p)):readFileSync(p);
 const actual=createHash('sha1').update(`blob ${content.length}\0`).update(content).digest('hex');
 if(actual!==hash || (mode==='120000')!==stat.isSymbolicLink() || (mode==='100755')!==Boolean(stat.mode&0o111)&&mode!=='120000')differences.push(file); checked++;
}
const unchanged=git('diff','--name-only','9f675713',commit,'--','.',':!docs')==='';
const originalDirs=['QUA-01.ime-integrated-20261116','QUA-01.closure-20261116']; let originalArtifacts=0;
for(const dir of originalDirs)for(const item of JSON.parse(readFileSync(`docs/audit/pi/evidence/${dir}/artifacts.json`))){
 const b=readFileSync(`docs/audit/pi/evidence/${dir}/${item.file}`);if(sha(b)!==item.sha256)throw Error('artifact '+item.file);
 if(item.uncompressedSha256&&sha(gunzipSync(b))!==item.uncompressedSha256)throw Error('gzip '+item.file); originalArtifacts++;
}
const receipt='docs/audit/pi/evidence/QUA-01.ime-integrated-20261116/browser-standard.json.gz';
const r=JSON.parse(gunzipSync(readFileSync(receipt)));
const walk=suites=>suites.flatMap(s=>[...(s.specs??[]).flatMap(spec=>(spec.tests??[]).map(t=>({file:spec.file,title:spec.title,results:t.results.map(x=>({status:x.status,retry:x.retry,duration:x.duration}))}))),...walk(s.suites??[])]);
const selected=walk(r.suites).filter(x=>/^(live-server|accessibility|sidebar-organisation-live|settings-administration-live|terminal-lifecycle-live|performance|native-session-links-live|visual)\.spec/.test(x.file));
const counts={}; for(const x of selected){counts[x.file]??={passed:0,failed:0};for(const a of x.results)counts[x.file][a.status==='passed'?'passed':'failed']++;}
const references=['pi','pi-web'].map(name=>{const cwd=`/tmp/aih-parity-audit-ejvmwn/${name}`;return {name,path:cwd,commit:execFileSync('git',['rev-parse','HEAD'],{cwd,encoding:'utf8'}).trim(),status:execFileSync('git',['status','--porcelain'],{cwd,encoding:'utf8'}).trim(),package:JSON.parse(readFileSync(`${cwd}/${name==='pi'?'packages/coding-agent/':''}package.json`)).version};});
const result={commit,tree:git('rev-parse',commit+'^{tree}'),sourceArchiveSha256:sha(readFileSync(base+'/source.tar')),verifiedBlobsAndModes:checked,differences,nonDocsEqualToQua01Product:unchanged,originalArtifactsVerified:originalArtifacts,references,nativeReuse:{report:receipt,sha256:sha(readFileSync(receipt)),counts,selected},scope:'Git-source and reused-artifact verification, not a platform certificate or fresh execution of reused tests.'};
if(differences.length||!unchanged)throw Error('source mismatch');
writeFileSync(base+'/results/provenance.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({checked,differences,unchanged,originalArtifacts,references,counts},null,2));
