# QUA-02 paired browser protocol — fixed before execution

2026-11-16. User approves Linux x64/Chromium at1440x900,820x1180,390x844, light/dark. Windows/Edge/Safari are optional if available (none exposed); physical mobile is explicitly not a blocker and remains unverified. No unsupported-platform declaration.

## Sources and toolchain

Native product/test/build9f675713 remains unchanged; checkout3d4cd6b7 adds excluded evidence only. Native image sha256:bb7fb54843773414206d8e23e202691948f28cb2bc5d9aff1ae1ef5501b63513. Pi Web0.12.2 clean source b017cd48425d05aa4952051db2e4fc031c134094, built with its exact package-lock via official npm ci && npm run build on that native base. Pi dependency packages must all be1.2.0; source reference06a466935536f8c9bcacb2d5efc0fc021be1bdff remains separate from published SDK build provenance. Reference image sha256:2d291cd9a43500455e460b5da35ab71ec486b769e14734ae4057420b4394974f. Node24.15.0/npm12.1.0/Chromium156.0.8078.79/Playwright1.63.0, viewport-only narrow cases, default DPR1/no physical touch or IME claim.

## Gap and reused scenarios

Existing native live-server, conversation-live, Settings/theme, native-links and terminal-lifecycle journeys plus upstream e2e/run.mjs, themes.mjs, sidebar.mjs and terminal.mjs cover owning behavior, but supply no current paired browser captures. Reuse their bounded operations; a temporary Playwright acceptance collector in /app/e2e adds only paired outcomes/screenshots/network evidence. This is not a framework, a product change, an exhaustive equivalence suite or new provider integration.

For each cell and each application:
1. Create a genuine empty session via its native HTTP route, submit a synthetic prompt through the composer, observe a completed assistant response and reload it exactly once. Pi uses one explicit models.json loopback OpenAI-compatible fixture with a synthetic key; AiHarness uses its existing native MockProvider. Compare useful send/settle/persistence outcomes, not provider output identity, latency or wire aliases.
2. Open a180-message history seeded before Server reads by the existing native Core SessionManager or upstream's existing v3 JSONL fixture pattern. Navigate from the actual sidebar, load an older page through the existing UI, see row90, retain original message order and reload the same session. No Pi import or session-format equivalence claim.
3. Open Settings, select the opposite light/dark theme and then the cell's approved theme using the real UI control, reload and verify persistence. Capture the original unmasked Settings UI; no preference/budget/runtime policy relaxation.
4. Open a seeded Markdown workspace file via its actual explorer, then a genuine PTY, execute printf with a split marker (not satisfied by echoed command), see QUA02_PTY_OK, and capture. Existing native exhaustive PTY/auth/refusal evidence remains separate.

Four original full-viewport captures/application/cell: settled conversation, older history, Settings, workspace/terminal. All screenshots keep errors/notifications; only normal screenshot animations:'disabled' and caret:'hide', no masks, CSS transformations, hidden UI or baseline updates. Review each pair individually as intentional native presentation, demonstrated defect or unverified. No cross-product pixel comparator or default graphics identity requirement. Any review contact sheet is derived navigation only; original PNGs/hashes remain authoritative.

## Execution and stop rules

Use existing official node .docker/run-e2e.mjs e2e/qua02-differential.spec.ts --reporter=line,json --trace=on --max-failures=1 in Docker; it builds native product and enforces one worker/zero retries. First select1440-light only (two application cases). If both pass, execute the remaining five distinct cells with --grep-invert=1440-light, not a repeated run of the first cell. Separate owned containers/artifacts; no concurrent Make in one checkout. Each app/cell has its own disposable HOME/agent/store/workspace/server and browser context. Docker --network=none, only loopback services. No personal mount or protected pi/qwen-moe container interaction.

Temporary new cases use the existing owning live-intent60s case budget, ordinary5s native assertions, existing15s mock-response observation,120s readiness bound and10s graceful child termination bound. Preserve existing product/runtime/compiler options, transport policies, all old assertions/deadlines/references/budgets. Capture exceptions, browser errors, HTTP status/path and loopback provider requests; an in-case429/5xx or pageerror fails, never retries. On first failure retain full log/report/trace/actual screenshot and stop that command. Additional execution requires a demonstrated fixture fix, an exact non-reproduction control or a distinct announced hypothesis. No broad native/global replay.

No new performance thresholds: reuse the separately sealed two-case measurements and existing bundle budgets. This campaign makes no latency-gain, real-account, physical-device, remote-CI or distribution claim.
