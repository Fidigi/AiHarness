import fs from 'node:fs';import path from 'node:path';import{gzipSync}from'node:zlib';import{createHash}from'node:crypto';import{execFileSync}from'node:child_process';
const base='/tmp/aih-qua02-differential-20261116',out='docs/audit/pi/evidence/QUA-02.differential-20261116';fs.mkdirSync(out,{recursive:true});const entries=[];
const sha=b=>createHash('sha256').update(b).digest('hex');
function add(source,file,compress=true){const raw=fs.readFileSync(source),b=compress?gzipSync(raw):raw;file+=compress?'.gz':'';fs.mkdirSync(path.dirname(out+'/'+file),{recursive:true});fs.writeFileSync(out+'/'+file,b);entries.push({file,bytes:b.length,sha256:sha(b),...(compress?{uncompressedBytes:raw.length,uncompressedSha256:sha(raw)}:{}),source});}
for(const f of ['Dockerfile','Dockerfile.collector','Dockerfile.regression-red','build-reference.sh','run-cell.sh','protocol.md','protocol-fixture-addendum.md','collector-gap-fixes.md','observe-network.mjs','make-pairs.mjs','gather.mjs','seal-pilot.mjs','terminal-controls.spec.ts'])add(base+'/'+f,'inputs/'+f);
add(base+'/availability.log','availability.log');
for(const name of fs.readdirSync(base+'/results')){const p=base+'/results/'+name;if(fs.statSync(p).isFile())add(p,'preparation/'+name);}
for(const name of ['initial','initial-home-fixed','initial-internal','initial-scroll-fixed','native-observation','initial-contract-fixed','initial-persisted-id','remaining','narrow-explorer-fixed']){
 const root=base+'/results/'+name;for(const f of ['command','exit','container-id','container.json','run.log'])add(root+'/'+f,'runs/'+name+'/'+f);
 const archive=execFileSync('tar',['-czf','-','-C',root,'test-results'],{maxBuffer:128*1024*1024});const file='runs/'+name+'/test-results.tar.gz';fs.writeFileSync(out+'/'+file,archive);entries.push({file,bytes:archive.length,sha256:sha(archive),scope:'Complete original JSON/report/error context/PNG/trace payloads; original paths retained within archive.'});
}
const red=execFileSync('tar',['-czf','-','-C',base+'/results','overlay-red-test-results'],{maxBuffer:128*1024*1024});fs.writeFileSync(out+'/preparation/overlay-red-test-results.tar.gz',red);entries.push({file:'preparation/overlay-red-test-results.tar.gz',bytes:red.length,sha256:sha(red),scope:'Owning real-PTY regression RED on unchanged product, before repair.'});
for(const f of fs.readdirSync(base+'/review').filter(x=>!x.endsWith('-pair.png')))add(base+'/review/'+f,'review/'+f,!f.endsWith('.png'));
fs.writeFileSync(out+'/artifacts.json',JSON.stringify(entries,null,2)+'\n');console.log(entries.length+' pilot artifacts sealed; all failed and partial executions retained.');
