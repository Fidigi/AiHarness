import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const base='/tmp/aih-qua02-differential-20261116',out=base+'/review';fs.mkdirSync(out,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
const walk=s=>s.flatMap(x=>[...(x.specs??[]),...walk(x.suites??[])]);
const cases=[];
for(const [run,allowed] of [['initial-persisted-id',/^1440-light /],['remaining',/^1440-dark /],['narrow-explorer-fixed',/^(820|390)-/]]){
 const root=base+'/results/'+run, report=JSON.parse(fs.readFileSync(root+'/test-results/focused/report.json'));
 for(const spec of walk(report.suites).filter(x=>allowed.test(x.title))){
  const [test]=spec.tests,[result]=test.results;if(result.status!=='passed'||result.retry!==0||test.results.length!==1)throw Error(spec.title);
  const match=spec.title.match(/^(\d+)-(light|dark) (native|piweb) /),[,width,theme,app]=match;
  const outcomeAttachment=result.attachments.find(x=>x.name==='outcomes'); const outcomes=JSON.parse(Buffer.from(outcomeAttachment.body,'base64'));
  if(outcomes.stage!=='complete'||outcomes.httpErrors.length||outcomes.browserErrors.length)throw Error('incomplete '+spec.title);
  const screens=[];
  for(const scene of ['conversation','history','settings','workspace']){
   const attachment=result.attachments.find(x=>x.name===scene);if(!attachment)throw Error(scene);
   const source=root+attachment.path.replace('/app','');const bytes=fs.readFileSync(source),file=`${width}-${theme}-${app}-${scene}.png`;
   fs.writeFileSync(out+'/'+file,bytes);screens.push({scene,file,bytes:bytes.length,sha256:sha(bytes),source});
  }
  fs.writeFileSync(out+`/${width}-${theme}-${app}-outcomes.json`,JSON.stringify(outcomes,null,2)+'\n');
  cases.push({cell:`${width}-${theme}`,app,run,reportSha256:sha(fs.readFileSync(root+'/test-results/focused/report.json')),duration:result.duration,status:result.status,retry:result.retry,stage:outcomes.stage,viewport:outcomes.viewport,screens,providerRequests:outcomes.providerRequests.length,consoleErrors:outcomes.events.filter(x=>x.consoleError),history:outcomes.events.find(x=>x.renderedHistoryIndices),roles:outcomes.events.find(x=>x.persistedMessageRoles)});
 }
}
if(cases.length!==12||new Set(cases.map(x=>x.cell+x.app)).size!==12)throw Error('coverage');
fs.writeFileSync(out+'/coverage.json',JSON.stringify(cases,null,2)+'\n');console.log(JSON.stringify(cases.map(({screens,...x})=>x),null,2));
