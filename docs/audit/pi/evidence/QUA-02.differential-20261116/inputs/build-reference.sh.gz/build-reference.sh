#!/bin/bash
set -u
base=/tmp/aih-qua02-differential-20261116
mkdir -p "$base/reference" "$base/results"
git -C /tmp/aih-parity-audit-ejvmwn/pi-web archive --format=tar b017cd48425d05aa4952051db2e4fc031c134094 -o "$base/reference.tar"
sha256sum "$base/reference.tar" > "$base/results/reference-archive.sha256"
tar -xf "$base/reference.tar" -C "$base/reference"
printf 'start=%s\ncommand=docker build -f Dockerfile -t aih-qua02:reference-20261116 .\n' "$(date -u +%FT%TZ)" > "$base/results/reference-build.command"
cd "$base"
docker build -f Dockerfile -t aih-qua02:reference-20261116 . > "$base/results/reference-build.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/reference-build.command"
printf '%s\n' "$code" > "$base/results/reference-build.exit"
exit "$code"
