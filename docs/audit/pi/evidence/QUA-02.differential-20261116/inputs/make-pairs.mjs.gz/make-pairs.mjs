import sharp from '/app/node_modules/sharp/lib/index.js';
import fs from 'node:fs';
const root='/tmp/qua02-review';
for(const width of [1440,820,390])for(const theme of ['light','dark'])for(const scene of ['conversation','history','settings','workspace']){
 const label=`${width}-${theme}-${scene}`,a=root+`/${width}-${theme}-native-${scene}.png`,b=root+`/${width}-${theme}-piweb-${scene}.png`;
 const meta=await sharp(a).metadata();
 const header=Buffer.from(`<svg width="${width*2}" height="32"><rect width="100%" height="100%" fill="#fff"/><text x="8" y="22" font-size="18" fill="#111">${label} — AiHarness (original below)</text><text x="${width+8}" y="22" font-size="18" fill="#111">Pi Web 0.12.2 / Pi 1.2.0 (original below)</text></svg>`);
 await sharp({create:{width:width*2,height:meta.height+32,channels:4,background:'#fff'}}).composite([{input:header,left:0,top:0},{input:a,left:0,top:32},{input:b,left:width,top:32}]).png().toFile(root+'/'+label+'-pair.png');
}
console.log('24 review-only pairs generated without resizing/cropping originals.');
