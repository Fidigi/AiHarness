import { chromium } from '/app/node_modules/playwright-core/index.mjs';
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium' });
try {
 const page = await browser.newPage();
 console.log(JSON.stringify({ navigatorOnline: await page.evaluate(() => navigator.onLine) }));
} finally { await browser.close(); }
