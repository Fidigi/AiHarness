# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qua02-differential.spec.ts >> 1440-light native paired acceptance
- Location: e2e/qua02-differential.spec.ts:16:3

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: getByText('History row 90: bounded qualification history.', { exact: true })
Expected: attached
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeAttached" getByText('History row 90: bounded qualification history.', { exact: true }) with timeout 5000ms
  - waiting for getByText('History row 90: bounded qualification history.', { exact: true })

```

```yaml
- complementary "Main navigation":
  - heading "AiHarness" [level=1]
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Français"
  - button "New chat": +
  - text: Workspace
  - button "work /tmp/qua02/1440-light/native/work"
  - link "Open project in a new tab":
    - /url: /?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
    - text: ↗
  - button "Open workspace in file manager": ↗
  - button "Linked directories"
  - searchbox "Search conversations"
  - button "Refresh files": ↻
  - group: Organise navigation
  - navigation "Conversations":
    - list:
      - listitem:
        - link "QUA02 live turn 2 · 1 second ago":
          - /url: /chat/3df90194-81af-478b-8d7b-adf6b52dfe08?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
      - listitem:
        - link "QUA02 history 180 · 2 seconds ago":
          - /url: /chat/9b145935-5c1d-4e96-becb-2ae73c76706f?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
  - button "⚙ Settings"
- main:
  - strong: QUA02 history
  - text: /tmp/qua02/1440-light/native/work
  - group "Conversation navigation":
    - button "Previous conversation": ←
    - button "Next conversation" [disabled]: →
  - status
  - button "Open child agents (0)": Child agents 0
  - button "Branches"
  - button "Context"
  - button "Information"
  - button "Conversation map"
  - log "Conversation messages":
    - button "Load earlier messages"
    - 'article "user: History row 92: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 92: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 93: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 93: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 94: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 94: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 95: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 95: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 96: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 96: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 97: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 97: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 98: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 98: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 99: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 99: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 100: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 100: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 101: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 101: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 102: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 102: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 103: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 103: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 104: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 104: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 105: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 105: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 106: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 106: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 107: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 107: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 108: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 108: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 109: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 109: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 110: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 110: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
    - 'article "assistant: History row 111: bounded qualification history."':
      - text: 🤖 Assistant
      - region "Response":
        - paragraph: "History row 111: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
    - 'article "user: History row 112: bounded qualification history."':
      - text: 👤 You
      - paragraph: "History row 112: bounded qualification history."
      - time: 5:31:45 PM
      - button "Copy"
      - button "Edit from here"
      - button "New chat from here"
  - button "Back to bottom": ↓ Back to bottom
  - textbox "Message composer":
    - /placeholder: "Type your message... (Provider: mock)"
  - button "Add images"
  - button "Add images": ＋📷
  - text: Model
  - combobox "Select the model"
  - combobox "Thinking level":
    - option "Auto · off" [selected]
    - option "off"
    - option "minimal"
    - option "low"
    - option "medium"
    - option "high"
    - option "xhigh"
    - option "max"
  - combobox "Tool preset":
    - option "Auto · default" [selected]
    - option "configured"
    - option "chat-only"
    - option "read-only"
    - option "default"
    - option "full"
  - combobox "Auto-compaction":
    - option "Auto · On" [selected]
    - option "On"
    - option "Off"
  - button "Send" [disabled]
  - group: "Model: built-in default"
  - group: "Thinking level: built-in default"
  - text: "Tools: built-in default Auto-compaction: built-in default"
- complementary "Workspace explorer":
  - button "Files"
  - button "Changes"
  - button "Close": ×
  - button "Open terminal from file explorer": ⌘
  - button "Collapse workspace explorer": ›
  - button "Linked directories"
  - searchbox "Search files"
  - button "Refresh files": ↻
  - text: ↑ On conflict
  - combobox "On conflict":
    - option "Reject" [selected]
    - option "Keep both"
    - option "Overwrite"
  - checkbox "Show hidden files"
  - text: Show hidden files
  - list:
    - listitem:
      - button "📄 note.md"
      - button "Mention note.md": "@"
- button "Open workspace terminal": ⌘
- complementary "Status messages"
```

# Test source

```ts
  22  |     let child: ChildProcess | undefined, model: ReturnType<typeof createServer> | undefined;
  23  |     let base = '', historyId = '', liveId = '', stage = 'bootstrap', serverLog = '';
  24  |     let nativeStarted = false;
  25  |     const names = ['AI_HARNESS_AUTH_TOKEN', 'AI_HARNESS_ADMIN_TOKEN', 'AI_HARNESS_AGENT_DIR', 'HOME'] as const;
  26  |     const previous = names.map(name => process.env[name]);
  27  |     const capture = async (name: string) => {
  28  |       await page.evaluate(() => document.fonts.ready);
  29  |       expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(viewport.width);
  30  |       const file = info.outputPath(`${name}.png`);
  31  |       await page.screenshot({ path: file, animations: 'disabled', caret: 'hide' });
  32  |       await info.attach(name, { path: file, contentType: 'image/png' });
  33  |     };
  34  |     const sidebar = async () => {
  35  |       const toggle = page.getByRole('button', { name: app === 'native' ? 'Toggle navigation' : 'Show sidebar', exact: true });
  36  |       if (app === 'native') {
  37  |         if (viewport.width < 960 && await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
  38  |       } else if (await toggle.isVisible()) await toggle.click();
  39  |     };
  40  |     const refFiles = async () => {
  41  |       await sidebar();
  42  |       const files = page.locator('#session-sidebar-panel-files');
  43  |       const tab = page.getByRole('tab', { name: 'Files', exact: true });
  44  |       const toggle = files.locator('.sidebar-files-section-toggle');
  45  |       await expect(tab.or(toggle).first()).toBeVisible();
  46  |       if (await tab.count()) { if (await tab.getAttribute('aria-selected') !== 'true') await tab.click(); }
  47  |       else if (await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
  48  |       await expect(files.locator('.sidebar-files-body')).toBeVisible();
  49  |     };
  50  |     try {
  51  |       if (app === 'native') {
  52  |         process.env.AI_HARNESS_AUTH_TOKEN = ''; process.env.AI_HARNESS_ADMIN_TOKEN = ''; process.env.AI_HARNESS_AGENT_DIR = agent; process.env.HOME = path.join(root, 'home');
  53  |         const manager = new SessionManager({ store: new JsonlSessionStore(path.join(dataDir, 'sessions')) });
  54  |         const history = await manager.create({ cwd, title: 'QUA02 history' }); historyId = history.id;
  55  |         for (let index = 0; index < 180; index++) await manager.addMessage(historyId, { role: index % 2 ? 'assistant' : 'user', content: historyText(index) });
  56  |         const server = await start({ port: 0, host: '127.0.0.1', dataDir, defaultCwd: cwd, allowedRoots: [cwd], webRoot: path.resolve('packages/web/dist'), enableMockProvider: true });
  57  |         nativeStarted = true; base = `http://127.0.0.1:${server.port}`;
  58  |         await reserveReadBudget(page.request, base);
  59  |         expect((await page.request.post(`${base}/api/workspaces/trust`, { data: { cwd, confirm: true } })).status()).toBe(200);
  60  |         const created = await page.request.post(`${base}/api/sessions`, { data: { cwd, title: 'QUA02 live turn' } }); expect(created.status()).toBe(201);
  61  |         liveId = (await created.json()).id;
  62  |       } else {
  63  |         model = createServer(async (request, response) => {
  64  |           let raw = ''; for await (const chunk of request) raw += chunk;
  65  |           const body = raw ? JSON.parse(raw) : {}; providerRequests.push({ path: request.url, body });
  66  |           if (request.url !== '/v1/chat/completions') { response.writeHead(404); response.end(); return; }
  67  |           response.writeHead(200, { 'content-type': 'text/event-stream' });
  68  |           const delta = (value: unknown) => response.write(`data: ${JSON.stringify(value)}\n\n`);
  69  |           delta({ id: 'qua02', object: 'chat.completion.chunk', model: 'qua02-fixture', choices: [{ index: 0, delta: { role: 'assistant', content: 'QUA02 synthetic reply.\n\nPersisted bounded turn.' }, finish_reason: null }] });
  70  |           delta({ id: 'qua02', object: 'chat.completion.chunk', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } });
  71  |           response.end('data: [DONE]\n\n');
  72  |         });
  73  |         model.listen(0, '127.0.0.1'); await once(model, 'listening');
  74  |         const modelPort = (model.address() as { port: number }).port;
  75  |         await writeFile(path.join(agent, 'models.json'), JSON.stringify({ providers: { qua02: { baseUrl: `http://127.0.0.1:${modelPort}/v1`, api: 'openai-completions', apiKey: 'synthetic-qua02-only', models: [{ id: 'qua02-fixture', name: 'QUA02 fixture', reasoning: false, input: ['text'], contextWindow: 32768, maxTokens: 1024, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 } }] } } }));
  76  |         await writeFile(path.join(agent, 'settings.json'), JSON.stringify({ defaultProvider: 'qua02', defaultModel: 'qua02-fixture', defaultThinkingLevel: 'off' }));
  77  |         historyId = 'qua02-history'; const timestamp = '2026-11-16T10:00:00.000Z';
  78  |         const sessionDir = path.join(agent, 'sessions', 'e2e'); await mkdir(sessionDir, { recursive: true });
  79  |         const entries: unknown[] = [{ type: 'session', version: 3, id: historyId, cwd, timestamp }, { type: 'session_info', id: 'name', parentId: null, timestamp, name: 'QUA02 history' }];
  80  |         for (let index = 0; index < 180; index++) entries.push({ type: 'message', id: `e${index}`, parentId: index ? `e${index - 1}` : 'name', timestamp, message: { role: index % 2 ? 'assistant' : 'user', content: historyText(index) } });
  81  |         await writeFile(path.join(sessionDir, 'history.jsonl'), entries.map(entry => JSON.stringify(entry)).join('\n') + '\n');
  82  |         child = spawn(process.execPath, ['/reference/node_modules/next/dist/bin/next', 'start', '-H', '127.0.0.1', '-p', '13041'], { cwd: '/reference', env: { ...process.env, HOME: path.join(root, 'home'), PI_CODING_AGENT_DIR: agent, PI_WEB_PASSWORD: '', PI_WEB_SKIP_VERSION_CHECK: '1', NEXT_TELEMETRY_DISABLED: '1', HISTFILE: '/dev/null' }, stdio: ['ignore', 'pipe', 'pipe'] });
  83  |         child.stdout!.on('data', chunk => { serverLog += chunk; }); child.stderr!.on('data', chunk => { serverLog += chunk; });
  84  |         base = 'http://127.0.0.1:13041';
  85  |         await expect.poll(async () => {
  86  |           if (child!.exitCode !== null || child!.signalCode !== null) throw new Error(`Reference server terminated: ${child!.exitCode}/${child!.signalCode}`);
  87  |           return fetch(`${base}/api/sessions`).then(response => response.status).catch(() => 0);
  88  |         }, { timeout: 120_000 }).toBe(200);
  89  |         const created = await page.request.post(`${base}/api/agent/new`, { data: { cwd, type: 'ensure_session', provider: 'qua02', modelId: 'qua02-fixture', thinkingLevel: 'off', toolNames: [] } });
  90  |         expect(created.status(), await created.text()).toBe(200); liveId = (await created.json()).sessionId;
  91  |       }
  92  |       await page.setViewportSize(viewport);
  93  |       await page.addInitScript(({ app, theme }) => {
  94  |         if (app === 'native') { localStorage.setItem('ai-harness-locale', 'en'); localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({ version: 4, theme })); }
  95  |         else { localStorage.setItem('pi-locale', 'en'); localStorage.setItem('pi-theme', theme); }
  96  |       }, { app, theme });
  97  |       page.on('pageerror', error => browserErrors.push(error.message));
  98  |       page.on('console', message => { if (message.type() === 'error') events.push({ consoleError: message.text() }); });
  99  |       page.on('response', response => {
  100 |         const url = new URL(response.url()); if (url.origin !== base || !url.pathname.startsWith('/api/')) return;
  101 |         events.push({ method: response.request().method(), path: url.pathname + url.search, status: response.status() });
  102 |         if (response.status() === 429 || response.status() >= 500) httpErrors.push(`${response.status()} ${url.pathname}`);
  103 |       });
  104 |       const sessionUrl = (id: string) => app === 'native' ? `${base}/chat/${id}?cwd=${encodeURIComponent(cwd)}` : `${base}/?session=${id}`;
  105 |       const input = page.locator(app === 'native' ? '.input-container textarea' : '.chat-input-textarea');
  106 |       stage = 'live'; await page.goto(sessionUrl(liveId)); await expect(input).toBeVisible(); await input.fill(prompt);
  107 |       await page.getByRole('button', { name: 'Send', exact: true }).click();
  108 |       const reply = app === 'native' ? page.locator('.message.assistant').last() : page.locator('[data-message-role="assistant"]').last();
  109 |       await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.', { timeout: 15_000 });
  110 |       await page.reload(); await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.');
  111 |       await capture('conversation');
  112 |       stage = 'history'; await sidebar();
  113 |       if (app === 'native') await page.locator('.sidebar-nav a.session-main').filter({ hasText: 'QUA02 history' }).click();
  114 |       else {
  115 |         const sessions = page.getByRole('tab', { name: 'Sessions', exact: true }); if (await sessions.isVisible() && await sessions.getAttribute('aria-selected') !== 'true') await sessions.click();
  116 |         await page.locator('.session-tree-session').filter({ has: page.locator('.session-tree-title', { hasText: /^QUA02 history$/ }) }).locator('.session-tree-main').click();
  117 |       }
  118 |       await expect(page.getByText(historyText(179), { exact: true })).toBeVisible();
  119 |       const earlier = page.getByText(app === 'native' ? 'Load earlier messages' : 'Scroll up to load earlier messages', { exact: true });
  120 |       if (app === 'native') { await earlier.scrollIntoViewIfNeeded(); await earlier.click(); }
  121 |       else await earlier.evaluate(element => element.scrollIntoView({ block: 'start', behavior: 'instant' }));
> 122 |       const older = page.getByText(historyText(90), { exact: true }); await expect(older).toBeAttached(); await older.scrollIntoViewIfNeeded(); await expect(older).toBeVisible();
      |                                                                                           ^ Error: expect(locator).toBeAttached() failed
  123 |       await capture('history'); await page.reload(); await expect(page.getByText(historyText(179), { exact: true })).toBeAttached();
  124 |       expect(page.url()).toContain(historyId);
  125 |       stage = 'settings';
  126 |       if (app === 'native') {
  127 |         await page.goto(`${base}/settings#appearance`);
  128 |         const control = page.locator('#appearance').getByLabel(/^Theme/); await control.selectOption(theme === 'light' ? 'dark' : 'light'); await control.selectOption(theme);
  129 |         await page.reload(); await expect(control).toHaveValue(theme); await control.scrollIntoViewIfNeeded();
  130 |       } else {
  131 |         await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  132 |         const radio = (value: string) => page.getByRole('radio', { name: value === 'light' ? 'Light' : 'Dark', exact: true });
  133 |         await radio(theme === 'light' ? 'dark' : 'light').locator('..').click(); await radio(theme).locator('..').click();
  134 |         await page.keyboard.press('Escape'); await page.reload(); await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  135 |         await expect(radio(theme)).toBeChecked();
  136 |       }
  137 |       expect(await page.locator('html').getAttribute('data-theme')).toBe(theme); await capture('settings');
  138 |       stage = 'workspace'; await page.goto(sessionUrl(historyId));
  139 |       if (app === 'native') {
  140 |         await page.evaluate(() => window.dispatchEvent(new Event('aih-show-files')));
  141 |         const explorer = page.getByRole('complementary', { name: 'Workspace explorer', exact: true });
  142 |         await explorer.getByRole('button', { name: /^📄 note\.md(?:\s|$)/ }).click();
  143 |         await expect(page.locator('.file-viewer')).toContainText('Synthetic file boundary.');
  144 |         await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
  145 |       } else {
  146 |         await refFiles(); await page.getByText('note.md', { exact: true }).click();
  147 |         await expect(page.locator('#file-panel')).toContainText('Synthetic file boundary.');
  148 |         await refFiles(); await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
  149 |       }
  150 |       const terminal = page.locator(app === 'native' ? '.terminal-panel' : '.terminal-panel:visible');
  151 |       const terminalInput = terminal.locator('.xterm-helper-textarea'); await terminalInput.focus();
  152 |       await terminalInput.type("printf 'QUA02_'\"PTY_OK\\n\""); await terminalInput.press('Enter');
  153 |       await expect(terminal.locator('.xterm-rows')).toContainText('QUA02_PTY_OK', { timeout: 10_000 });
  154 |       await capture('workspace');
  155 |       expect(browserErrors).toEqual([]); expect(httpErrors).toEqual([]);
  156 |       if (app === 'piweb') expect(providerRequests.filter((call: any) => call.path === '/v1/chat/completions')).toHaveLength(1);
  157 |       stage = 'complete';
  158 |     } catch (error) {
  159 |       await capture('failure').catch(() => undefined); throw error;
  160 |     } finally {
  161 |       await info.attach('outcomes', { body: JSON.stringify({ app, viewport, theme, stage, base, cwd, historyId, liveId, browserErrors, httpErrors, providerRequests, events }, null, 2), contentType: 'application/json' });
  162 |       if (serverLog) await info.attach('reference-server', { body: serverLog, contentType: 'text/plain' });
  163 |       await page.goto('about:blank').catch(() => undefined);
  164 |       if (nativeStarted) await stop();
  165 |       if (child && child.exitCode === null && child.signalCode === null) {
  166 |         const exit = once(child, 'exit'); child.kill('SIGTERM'); const timer = setTimeout(() => child!.kill('SIGKILL'), 10_000); await exit; clearTimeout(timer);
  167 |       }
  168 |       if (model) { model.closeAllConnections(); await new Promise<void>(resolve => model!.close(() => resolve())); }
  169 |       for (const [index, name] of names.entries()) { if (previous[index] === undefined) delete process.env[name]; else process.env[name] = previous[index]; }
  170 |     }
  171 |   });
  172 | }
  173 | 
```