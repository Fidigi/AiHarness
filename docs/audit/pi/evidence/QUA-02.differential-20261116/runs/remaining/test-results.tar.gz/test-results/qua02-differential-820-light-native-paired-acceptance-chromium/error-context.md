# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qua02-differential.spec.ts >> 820-light native paired acceptance
- Location: e2e/qua02-differential.spec.ts:16:3

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Open workspace terminal', exact: true })
    - locator resolved to <button class="terminal-launcher" aria-label="Open workspace terminal">⌘</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div class="viewer-content">…</div> from <aside aria-label="Workspace explorer" class="workspace-panel panel-open viewer-open ">…</aside> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div class="viewer-content">…</div> from <aside aria-label="Workspace explorer" class="workspace-panel panel-open viewer-open ">…</aside> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    107 × waiting for element to be visible, enabled and stable
        - element is visible, enabled and stable
        - scrolling into view if needed
        - done scrolling
        - <div class="viewer-content">…</div> from <aside aria-label="Workspace explorer" class="workspace-panel panel-open viewer-open ">…</aside> subtree intercepts pointer events
      - retrying click action
        - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=f5e3]:
  - button "Toggle navigation" [ref=f5e4]
  - button "Workspace explorer" [expanded] [ref=f5e6]: ☷
  - complementary [aria-hidden] [ref=f5e7]:
    - generic [ref=f5e8]:
      - heading [level=1] [ref=f5e9]: AiHarness
      - generic [ref=f5e10]:
        - generic [ref=f5e11]:
          - generic [aria-hidden] [ref=f5e12]: 🌐
          - generic [ref=f5e13]: Language
          - combobox [ref=f5e14] [cursor=pointer]
        - button [ref=f5e15] [cursor=pointer]: +
    - generic [ref=f5e16]:
      - generic [ref=f5e17]: Workspace
      - generic [ref=f5e18]:
        - button [ref=f5e19] [cursor=pointer]:
          - generic [ref=f5e20]: work
          - generic [ref=f5e21]: /tmp/qua02/820-light/native/work
        - link [ref=f5e22] [cursor=pointer]:
          - /url: /?cwd=%2Ftmp%2Fqua02%2F820-light%2Fnative%2Fwork
          - text: ↗
        - button [ref=f5e23] [cursor=pointer]: ↗
      - button [ref=f5e24] [cursor=pointer]: Linked directories
    - generic [ref=f5e25]:
      - searchbox [ref=f5e26]
      - button [ref=f5e27] [cursor=pointer]: ↻
    - group [ref=f5e28]:
      - generic [ref=f5e29] [cursor=pointer]: Organise navigation
    - navigation [ref=f5e30]:
      - list [ref=f5e31]:
        - listitem [ref=f5e32]:
          - link [ref=f5e34] [cursor=pointer]:
            - /url: /chat/a82ed977-f2c6-4304-96d8-459edcb57eed?cwd=%2Ftmp%2Fqua02%2F820-light%2Fnative%2Fwork
            - generic [ref=f5e35]: QUA02 live turn
            - generic [ref=f5e36]: 2 · 2 seconds ago
        - listitem [ref=f5e37]:
          - link [ref=f5e39] [cursor=pointer]:
            - /url: /chat/83dd8621-fdb2-4d38-a866-9cbf72c6cea1?cwd=%2Ftmp%2Fqua02%2F820-light%2Fnative%2Fwork
            - generic [ref=f5e40]: QUA02 history
            - generic [ref=f5e41]: 180 · 3 seconds ago
    - button [ref=f5e43] [cursor=pointer]: ⚙ Settings
  - main [ref=f5e44]:
    - generic [ref=f5e45]:
      - generic [ref=f5e46]:
        - generic [ref=f5e47]:
          - strong [ref=f5e48]: QUA02 history
          - generic [ref=f5e49]: /tmp/qua02/820-light/native/work
        - button "Open child agents (0)" [ref=f5e52] [cursor=pointer]:
          - generic [aria-hidden] [ref=f5e53]: A
          - generic [ref=f5e54]: "0"
      - navigation "Conversation actions" [ref=f5e55]:
        - button "Previous conversation" [ref=f5e56] [cursor=pointer]
        - button "Next conversation" [disabled] [ref=f5e58] [cursor=pointer]
        - button "Branches" [ref=f5e60] [cursor=pointer]
        - button "Context" [ref=f5e62] [cursor=pointer]
        - button "Information" [ref=f5e64] [cursor=pointer]
        - button "Conversation map" [ref=f5e66] [cursor=pointer]
      - log "Conversation messages" [ref=f5e68]:
        - button "Load earlier messages" [ref=f5e70] [cursor=pointer]
        - generic [ref=f5e71]:
          - 'article "assistant: History row 79: bounded qualification history." [ref=f5e73]':
            - generic [ref=f5e74]: 🤖 Assistant
            - region "Response" [ref=f5e76]:
              - paragraph [ref=f5e78]: "History row 79: bounded qualification history."
            - generic [ref=f5e79]:
              - time [ref=f5e80]: 5:43:21 PM
              - button "Copy" [ref=f5e81] [cursor=pointer]
          - 'article "user: History row 80: bounded qualification history." [ref=f5e83]':
            - generic [ref=f5e84]: 👤 You
            - paragraph [ref=f5e88]: "History row 80: bounded qualification history."
            - generic [ref=f5e89]:
              - time [ref=f5e90]: 5:43:21 PM
              - button "Copy" [ref=f5e91] [cursor=pointer]
              - button "Edit from here" [ref=f5e92] [cursor=pointer]
              - button "New chat from here" [ref=f5e93] [cursor=pointer]
          - 'article "assistant: History row 81: bounded qualification history." [ref=f5e95]':
            - generic [ref=f5e96]: 🤖 Assistant
            - region "Response" [ref=f5e98]:
              - paragraph [ref=f5e100]: "History row 81: bounded qualification history."
            - generic [ref=f5e101]:
              - time [ref=f5e102]: 5:43:21 PM
              - button "Copy" [ref=f5e103] [cursor=pointer]
          - 'article "user: History row 82: bounded qualification history." [ref=f5e105]':
            - generic [ref=f5e106]: 👤 You
            - paragraph [ref=f5e110]: "History row 82: bounded qualification history."
            - generic [ref=f5e111]:
              - time [ref=f5e112]: 5:43:21 PM
              - button "Copy" [ref=f5e113] [cursor=pointer]
              - button "Edit from here" [ref=f5e114] [cursor=pointer]
              - button "New chat from here" [ref=f5e115] [cursor=pointer]
          - 'article "assistant: History row 83: bounded qualification history." [ref=f5e117]':
            - generic [ref=f5e118]: 🤖 Assistant
            - region "Response" [ref=f5e120]:
              - paragraph [ref=f5e122]: "History row 83: bounded qualification history."
            - generic [ref=f5e123]:
              - time [ref=f5e124]: 5:43:21 PM
              - button "Copy" [ref=f5e125] [cursor=pointer]
          - 'article "user: History row 84: bounded qualification history." [ref=f5e127]':
            - generic [ref=f5e128]: 👤 You
            - paragraph [ref=f5e132]: "History row 84: bounded qualification history."
            - generic [ref=f5e133]:
              - time [ref=f5e134]: 5:43:21 PM
              - button "Copy" [ref=f5e135] [cursor=pointer]
              - button "Edit from here" [ref=f5e136] [cursor=pointer]
              - button "New chat from here" [ref=f5e137] [cursor=pointer]
          - 'article "assistant: History row 85: bounded qualification history." [ref=f5e139]':
            - generic [ref=f5e140]: 🤖 Assistant
            - region "Response" [ref=f5e142]:
              - paragraph [ref=f5e144]: "History row 85: bounded qualification history."
            - generic [ref=f5e145]:
              - time [ref=f5e146]: 5:43:21 PM
              - button "Copy" [ref=f5e147] [cursor=pointer]
          - 'article "user: History row 86: bounded qualification history." [ref=f5e149]':
            - generic [ref=f5e150]: 👤 You
            - paragraph [ref=f5e154]: "History row 86: bounded qualification history."
            - generic [ref=f5e155]:
              - time [ref=f5e156]: 5:43:21 PM
              - button "Copy" [ref=f5e157] [cursor=pointer]
              - button "Edit from here" [ref=f5e158] [cursor=pointer]
              - button "New chat from here" [ref=f5e159] [cursor=pointer]
          - 'article "assistant: History row 87: bounded qualification history." [ref=f5e161]':
            - generic [ref=f5e162]: 🤖 Assistant
            - region "Response" [ref=f5e164]:
              - paragraph [ref=f5e166]: "History row 87: bounded qualification history."
            - generic [ref=f5e167]:
              - time [ref=f5e168]: 5:43:21 PM
              - button "Copy" [ref=f5e169] [cursor=pointer]
          - 'article "user: History row 88: bounded qualification history." [ref=f5e171]':
            - generic [ref=f5e172]: 👤 You
            - paragraph [ref=f5e176]: "History row 88: bounded qualification history."
            - generic [ref=f5e177]:
              - time [ref=f5e178]: 5:43:21 PM
              - button "Copy" [ref=f5e179] [cursor=pointer]
              - button "Edit from here" [ref=f5e180] [cursor=pointer]
              - button "New chat from here" [ref=f5e181] [cursor=pointer]
          - 'article "assistant: History row 89: bounded qualification history." [ref=f5e183]':
            - generic [ref=f5e184]: 🤖 Assistant
            - region "Response" [ref=f5e186]:
              - paragraph [ref=f5e188]: "History row 89: bounded qualification history."
            - generic [ref=f5e189]:
              - time [ref=f5e190]: 5:43:21 PM
              - button "Copy" [ref=f5e191] [cursor=pointer]
          - 'article "user: History row 90: bounded qualification history." [ref=f5e193]':
            - generic [ref=f5e194]: 👤 You
            - paragraph [ref=f5e198]: "History row 90: bounded qualification history."
            - generic [ref=f5e199]:
              - time [ref=f5e200]: 5:43:21 PM
              - button "Copy" [ref=f5e201] [cursor=pointer]
              - button "Edit from here" [ref=f5e202] [cursor=pointer]
              - button "New chat from here" [ref=f5e203] [cursor=pointer]
          - 'article "assistant: History row 91: bounded qualification history." [ref=f5e205]':
            - generic [ref=f5e206]: 🤖 Assistant
            - region "Response" [ref=f5e208]:
              - paragraph [ref=f5e210]: "History row 91: bounded qualification history."
            - generic [ref=f5e211]:
              - time [ref=f5e212]: 5:43:21 PM
              - button "Copy" [ref=f5e213] [cursor=pointer]
          - 'article "user: History row 92: bounded qualification history." [ref=f5e215]':
            - generic [ref=f5e216]: 👤 You
            - paragraph [ref=f5e220]: "History row 92: bounded qualification history."
            - generic [ref=f5e221]:
              - time [ref=f5e222]: 5:43:21 PM
              - button "Copy" [ref=f5e223] [cursor=pointer]
              - button "Edit from here" [ref=f5e224] [cursor=pointer]
              - button "New chat from here" [ref=f5e225] [cursor=pointer]
          - 'article "assistant: History row 93: bounded qualification history." [ref=f5e227]':
            - generic [ref=f5e228]: 🤖 Assistant
            - region "Response" [ref=f5e230]:
              - paragraph [ref=f5e232]: "History row 93: bounded qualification history."
            - generic [ref=f5e233]:
              - time [ref=f5e234]: 5:43:21 PM
              - button "Copy" [ref=f5e235] [cursor=pointer]
          - 'article "user: History row 94: bounded qualification history." [ref=f5e237]':
            - generic [ref=f5e238]: 👤 You
            - paragraph [ref=f5e242]: "History row 94: bounded qualification history."
            - generic [ref=f5e243]:
              - time [ref=f5e244]: 5:43:21 PM
              - button "Copy" [ref=f5e245] [cursor=pointer]
              - button "Edit from here" [ref=f5e246] [cursor=pointer]
              - button "New chat from here" [ref=f5e247] [cursor=pointer]
          - 'article "assistant: History row 95: bounded qualification history." [ref=f5e249]':
            - generic [ref=f5e250]: 🤖 Assistant
            - region "Response" [ref=f5e252]:
              - paragraph [ref=f5e254]: "History row 95: bounded qualification history."
            - generic [ref=f5e255]:
              - time [ref=f5e256]: 5:43:21 PM
              - button "Copy" [ref=f5e257] [cursor=pointer]
          - 'article "user: History row 96: bounded qualification history." [ref=f5e259]':
            - generic [ref=f5e260]: 👤 You
            - paragraph [ref=f5e264]: "History row 96: bounded qualification history."
            - generic [ref=f5e265]:
              - time [ref=f5e266]: 5:43:21 PM
              - button "Copy" [ref=f5e267] [cursor=pointer]
              - button "Edit from here" [ref=f5e268] [cursor=pointer]
              - button "New chat from here" [ref=f5e269] [cursor=pointer]
          - 'article "assistant: History row 97: bounded qualification history." [ref=f5e271]':
            - generic [ref=f5e272]: 🤖 Assistant
            - region "Response" [ref=f5e274]:
              - paragraph [ref=f5e276]: "History row 97: bounded qualification history."
            - generic [ref=f5e277]:
              - time [ref=f5e278]: 5:43:21 PM
              - button "Copy" [ref=f5e279] [cursor=pointer]
          - 'article "user: History row 98: bounded qualification history." [ref=f5e281]':
            - generic [ref=f5e282]: 👤 You
            - paragraph [ref=f5e286]: "History row 98: bounded qualification history."
            - generic [ref=f5e287]:
              - time [ref=f5e288]: 5:43:21 PM
              - button "Copy" [ref=f5e289] [cursor=pointer]
              - button "Edit from here" [ref=f5e290] [cursor=pointer]
              - button "New chat from here" [ref=f5e291] [cursor=pointer]
          - 'article "assistant: History row 99: bounded qualification history." [ref=f5e293]':
            - generic [ref=f5e294]: 🤖 Assistant
            - region "Response" [ref=f5e296]:
              - paragraph [ref=f5e298]: "History row 99: bounded qualification history."
            - generic [ref=f5e299]:
              - time [ref=f5e300]: 5:43:21 PM
              - button "Copy" [ref=f5e301] [cursor=pointer]
          - 'article "user: History row 100: bounded qualification history." [ref=f5e303]':
            - generic [ref=f5e304]: 👤 You
            - paragraph [ref=f5e308]: "History row 100: bounded qualification history."
            - generic [ref=f5e309]:
              - time [ref=f5e310]: 5:43:21 PM
              - button "Copy" [ref=f5e311] [cursor=pointer]
              - button "Edit from here" [ref=f5e312] [cursor=pointer]
              - button "New chat from here" [ref=f5e313] [cursor=pointer]
          - 'article "assistant: History row 101: bounded qualification history." [ref=f5e315]':
            - generic [ref=f5e316]: 🤖 Assistant
            - region "Response" [ref=f5e318]:
              - paragraph [ref=f5e320]: "History row 101: bounded qualification history."
            - generic [ref=f5e321]:
              - time [ref=f5e322]: 5:43:21 PM
              - button "Copy" [ref=f5e323] [cursor=pointer]
          - 'article "user: History row 102: bounded qualification history." [ref=f5e325]':
            - generic [ref=f5e326]: 👤 You
            - paragraph [ref=f5e330]: "History row 102: bounded qualification history."
            - generic [ref=f5e331]:
              - time [ref=f5e332]: 5:43:21 PM
              - button "Copy" [ref=f5e333] [cursor=pointer]
              - button "Edit from here" [ref=f5e334] [cursor=pointer]
              - button "New chat from here" [ref=f5e335] [cursor=pointer]
      - generic [ref=f5e336]:
        - button "Back to bottom" [ref=f5e337] [cursor=pointer]: ↓ Back to bottom
        - textbox "Message composer" [ref=f5e338]:
          - /placeholder: "Type your message... (Provider: mock)"
        - generic [ref=f5e339]:
          - button "Add images" [ref=f5e340]
          - button "Add images" [ref=f5e341] [cursor=pointer]: ＋📷
          - generic [ref=f5e342]:
            - generic [ref=f5e343]: Model
            - combobox "Select the model" [ref=f5e344]
          - combobox "Thinking level" [ref=f5e345]:
            - option "Auto · off" [selected]
            - option "off"
            - option "minimal"
            - option "low"
            - option "medium"
            - option "high"
            - option "xhigh"
            - option "max"
          - combobox "Tool preset" [ref=f5e346]:
            - option "Auto · default" [selected]
            - option "configured"
            - option "chat-only"
            - option "read-only"
            - option "default"
            - option "full"
          - combobox "Auto-compaction" [ref=f5e347]:
            - option "Auto · On" [selected]
            - option "On"
            - option "Off"
          - button "Send" [disabled] [ref=f5e348]
        - generic "Effective conversation setting scopes" [ref=f5e349]:
          - group [ref=f5e350]:
            - generic "New-session model defaults" [ref=f5e351]: "Model: built-in default"
          - group [ref=f5e352]:
            - generic "New-session reasoning defaults" [ref=f5e353]: "Thinking level: built-in default"
          - generic [ref=f5e354]: "Tools: built-in default"
          - generic [ref=f5e355]: "Auto-compaction: built-in default"
  - complementary "Workspace explorer" [ref=f5e356]:
    - generic [ref=f5e357]:
      - generic [ref=f5e358]:
        - button "Files" [ref=f5e359] [cursor=pointer]
        - button "Changes" [ref=f5e360] [cursor=pointer]
      - generic [ref=f5e361]:
        - button "Close" [ref=f5e362] [cursor=pointer]: ×
        - button "Open terminal from file explorer" [ref=f5e363] [cursor=pointer]: ⌘
        - button "Collapse workspace explorer" [ref=f5e364] [cursor=pointer]: ›
    - button "Linked directories" [ref=f5e365] [cursor=pointer]
    - generic [ref=f5e366]:
      - searchbox "Search files" [ref=f5e367]
      - button "Refresh files" [ref=f5e368] [cursor=pointer]: ↻
      - generic "Upload files" [ref=f5e369] [cursor=pointer]: ↑
    - generic [ref=f5e371]:
      - text: On conflict
      - combobox "On conflict" [ref=f5e372]:
        - option "Reject" [selected]
        - option "Keep both"
        - option "Overwrite"
    - generic [ref=f5e373]:
      - checkbox "Show hidden files" [ref=f5e374]
      - text: Show hidden files
    - list [ref=f5e376]:
      - listitem [ref=f5e377]:
        - generic [ref=f5e378]:
          - button "📄 note.md" [active] [ref=f5e379] [cursor=pointer]
          - button "Mention note.md" [ref=f5e380] [cursor=pointer]: "@"
    - generic [ref=f5e381]:
      - tablist "Open files" [ref=f5e382]:
        - tab "note.md" [selected] [ref=f5e383] [cursor=pointer]
      - button "Close file note.md" [ref=f5e384] [cursor=pointer]: ×
    - tabpanel "note.md" [ref=f5e385]:
      - generic [ref=f5e386]:
        - strong [ref=f5e387]: note.md
        - generic [ref=f5e388]:
          - button "Maximize file viewer" [ref=f5e389] [cursor=pointer]: ↗
          - button "Close" [ref=f5e390] [cursor=pointer]: ×
      - generic [ref=f5e391]: markdown · 4 lines · 44 B
      - navigation [ref=f5e392]:
        - button "Source" [ref=f5e393] [cursor=pointer]
        - button "Preview" [ref=f5e394] [cursor=pointer]
        - button "Diff" [ref=f5e395] [cursor=pointer]
      - generic [ref=f5e397]:
        - generic [ref=f5e398]:
          - generic [ref=f5e399]: "1"
          - code [ref=f5e400]: "# QUA02 workspace"
        - generic [ref=f5e401]:
          - generic [ref=f5e402]: "2"
          - code [ref=f5e403]
        - generic [ref=f5e404]:
          - generic [ref=f5e405]: "3"
          - code [ref=f5e406]: Synthetic file boundary.
        - generic [ref=f5e407]:
          - generic [ref=f5e408]: "4"
          - code [ref=f5e409]
      - generic [ref=f5e410]:
        - button "@ Mention" [ref=f5e411] [cursor=pointer]
        - button "Copy" [ref=f5e412] [cursor=pointer]
        - link "Download" [ref=f5e413] [cursor=pointer]:
          - /url: /api/files/download?cwd=%2Ftmp%2Fqua02%2F820-light%2Fnative%2Fwork&path=note.md
  - button "Open workspace terminal" [ref=f5e414] [cursor=pointer]: ⌘
  - complementary "Status messages"
```

# Test source

```ts
  61  |         liveId = (await created.json()).id;
  62  |       } else {
  63  |         model = createServer(async (request, response) => {
  64  |           let raw = ''; for await (const chunk of request) raw += chunk;
  65  |           const body = raw ? JSON.parse(raw) : {}; providerRequests.push({ path: request.url, body });
  66  |           if (request.url !== '/v1/chat/completions') { response.writeHead(404); response.end(); return; }
  67  |           response.writeHead(200, { 'content-type': 'text/event-stream' });
  68  |           const delta = (value: unknown) => response.write(`data: ${JSON.stringify(value)}\n\n`);
  69  |           delta({ id: 'qua02', object: 'chat.completion.chunk', model: 'qua02-fixture', choices: [{ index: 0, delta: { role: 'assistant', content: 'QUA02 synthetic reply.\n\nPersisted bounded turn.' }, finish_reason: null }] });
  70  |           delta({ id: 'qua02', object: 'chat.completion.chunk', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } });
  71  |           response.end('data: [DONE]\n\n');
  72  |         });
  73  |         model.listen(0, '127.0.0.1'); await once(model, 'listening');
  74  |         const modelPort = (model.address() as { port: number }).port;
  75  |         await writeFile(path.join(agent, 'models.json'), JSON.stringify({ providers: { qua02: { baseUrl: `http://127.0.0.1:${modelPort}/v1`, api: 'openai-completions', apiKey: 'synthetic-qua02-only', models: [{ id: 'qua02-fixture', name: 'QUA02 fixture', reasoning: false, input: ['text'], contextWindow: 32768, maxTokens: 1024, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 } }] } } }));
  76  |         await writeFile(path.join(agent, 'settings.json'), JSON.stringify({ defaultProvider: 'qua02', defaultModel: 'qua02-fixture', defaultThinkingLevel: 'off' }));
  77  |         historyId = 'qua02-history'; const timestamp = '2026-11-16T10:00:00.000Z';
  78  |         const sessionDir = path.join(agent, 'sessions', 'e2e'); await mkdir(sessionDir, { recursive: true });
  79  |         const entries: unknown[] = [{ type: 'session', version: 3, id: historyId, cwd, timestamp }, { type: 'session_info', id: 'name', parentId: null, timestamp, name: 'QUA02 history' }];
  80  |         for (let index = 0; index < 180; index++) entries.push({ type: 'message', id: `e${index}`, parentId: index ? `e${index - 1}` : 'name', timestamp, message: { role: index % 2 ? 'assistant' : 'user', content: historyText(index) } });
  81  |         await writeFile(path.join(sessionDir, 'history.jsonl'), entries.map(entry => JSON.stringify(entry)).join('\n') + '\n');
  82  |         child = spawn(process.execPath, ['/reference/node_modules/next/dist/bin/next', 'start', '-H', '127.0.0.1', '-p', '13041'], { cwd: '/reference', env: { ...process.env, HOME: path.join(root, 'home'), PI_CODING_AGENT_DIR: agent, PI_WEB_PASSWORD: '', PI_WEB_SKIP_VERSION_CHECK: '1', NEXT_TELEMETRY_DISABLED: '1', HISTFILE: '/dev/null' }, stdio: ['ignore', 'pipe', 'pipe'] });
  83  |         child.stdout!.on('data', chunk => { serverLog += chunk; }); child.stderr!.on('data', chunk => { serverLog += chunk; });
  84  |         base = 'http://127.0.0.1:13041';
  85  |         await expect.poll(async () => {
  86  |           if (child!.exitCode !== null || child!.signalCode !== null) throw new Error(`Reference server terminated: ${child!.exitCode}/${child!.signalCode}`);
  87  |           return fetch(`${base}/api/sessions`).then(response => response.status).catch(() => 0);
  88  |         }, { timeout: 120_000 }).toBe(200);
  89  |         const created = await page.request.post(`${base}/api/agent/new`, { data: { cwd, type: 'ensure_session', provider: 'qua02', modelId: 'qua02-fixture', thinkingLevel: 'off', toolNames: [] } });
  90  |         expect(created.status(), await created.text()).toBe(200); liveId = (await created.json()).sessionId;
  91  |       }
  92  |       await page.setViewportSize(viewport);
  93  |       await page.addInitScript(({ app, theme }) => {
  94  |         if (app === 'native') { localStorage.setItem('ai-harness-locale', 'en'); if (!localStorage.getItem('ai-harness-preferences-v4')) localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({ version: 4, theme })); }
  95  |         else { localStorage.setItem('pi-locale', 'en'); if (!localStorage.getItem('pi-theme')) localStorage.setItem('pi-theme', theme); }
  96  |       }, { app, theme });
  97  |       page.on('pageerror', error => browserErrors.push(error.message));
  98  |       page.on('console', message => { if (message.type() === 'error') events.push({ consoleError: message.text() }); });
  99  |       page.on('response', response => {
  100 |         const url = new URL(response.url()); if (url.origin !== base || !url.pathname.startsWith('/api/')) return;
  101 |         events.push({ method: response.request().method(), path: url.pathname + url.search, status: response.status() });
  102 |         if (response.status() === 429 || response.status() >= 500) httpErrors.push(`${response.status()} ${url.pathname}`);
  103 |       });
  104 |       const sessionUrl = (id: string) => app === 'native' ? `${base}/chat/${id}?cwd=${encodeURIComponent(cwd)}` : `${base}/?session=${id}`;
  105 |       const input = page.locator(app === 'native' ? '.input-container textarea' : '.chat-input-textarea');
  106 |       stage = 'live'; await page.goto(sessionUrl(liveId)); await expect(input).toBeVisible(); await input.fill(prompt);
  107 |       await page.getByRole('button', { name: 'Send', exact: true }).click();
  108 |       const reply = app === 'native' ? page.locator('.message.assistant').last() : page.locator('[data-message-role="assistant"]').last();
  109 |       await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.', { timeout: 15_000 });
  110 |       if (app === 'piweb') {
  111 |         const persistedId = new URL(page.url()).searchParams.get('session'); expect(persistedId).toBeTruthy();
  112 |         events.push({ initialEmptySessionId: liveId, persistedSessionId: persistedId }); liveId = persistedId!;
  113 |       }
  114 |       await page.reload(); await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.');
  115 |       expect(page.url()).toContain(liveId);
  116 |       const persisted = await page.request.get(`${base}/api/sessions/${liveId}`); expect(persisted.status()).toBe(200);
  117 |       const snapshot = await persisted.json(), messages = app === 'native' ? snapshot.messages : snapshot.context.messages;
  118 |       expect(messages.filter((message: any) => message.role === 'user' && (typeof message.content === 'string' ? message.content === prompt : message.content.some((block: any) => block.text === prompt)))).toHaveLength(1);
  119 |       expect(messages.filter((message: any) => message.role === 'assistant')).toHaveLength(1);
  120 |       events.push({ persistedMessageRoles: messages.map((message: any) => message.role) });
  121 |       await capture('conversation');
  122 |       stage = 'history'; await sidebar();
  123 |       if (app === 'native') await page.locator('.sidebar-nav a.session-main').filter({ hasText: 'QUA02 history' }).click();
  124 |       else {
  125 |         const sessions = page.getByRole('tab', { name: 'Sessions', exact: true }); if (await sessions.isVisible() && await sessions.getAttribute('aria-selected') !== 'true') await sessions.click();
  126 |         await page.locator('.session-tree-session').filter({ has: page.locator('.session-tree-title', { hasText: /^QUA02 history$/ }) }).locator('.session-tree-main').click();
  127 |       }
  128 |       await expect(page.getByText(historyText(179), { exact: true })).toBeVisible();
  129 |       const earlier = page.getByText(app === 'native' ? 'Load earlier messages' : 'Scroll up to load earlier messages', { exact: true });
  130 |       if (app === 'native') { await earlier.scrollIntoViewIfNeeded(); await earlier.click(); }
  131 |       else await earlier.evaluate(element => element.scrollIntoView({ block: 'start', behavior: 'instant' }));
  132 |       if (app === 'native') { await page.getByRole('log').hover(); await page.mouse.wheel(0, -800); }
  133 |       const older = page.getByText(historyText(90), { exact: true }); await expect(older).toBeAttached(); await older.scrollIntoViewIfNeeded(); await expect(older).toBeVisible();
  134 |       const rendered = await page.getByText(/^History row \d+:/).allTextContents();
  135 |       const indices = rendered.map(value => Number(value.match(/^History row (\d+):/)![1]));
  136 |       expect(indices.length).toBeGreaterThan(0); expect(new Set(indices).size).toBe(indices.length);
  137 |       expect(indices.every((value, index) => index === 0 || value === indices[index - 1] + 1)).toBe(true);
  138 |       events.push({ renderedHistoryIndices: indices });
  139 |       await capture('history'); await page.reload();
  140 |       await expect(page.getByText(historyText(app === 'native' ? 90 : 179), { exact: true })).toBeVisible();
  141 |       expect(page.url()).toContain(historyId);
  142 |       stage = 'settings';
  143 |       if (app === 'native') {
  144 |         await page.goto(`${base}/settings#appearance`);
  145 |         const control = page.locator('#appearance').getByLabel(/^Theme/); await control.selectOption(theme === 'light' ? 'dark' : 'light'); await control.selectOption(theme);
  146 |         await page.reload(); await expect(control).toHaveValue(theme); await control.scrollIntoViewIfNeeded();
  147 |       } else {
  148 |         await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  149 |         const radio = (value: string) => page.getByRole('radio', { name: value === 'light' ? 'Light' : 'Dark', exact: true });
  150 |         await radio(theme === 'light' ? 'dark' : 'light').locator('..').click(); await radio(theme).locator('..').click();
  151 |         await page.keyboard.press('Escape'); await page.reload(); await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  152 |         await expect(radio(theme)).toBeChecked();
  153 |       }
  154 |       expect(await page.locator('html').getAttribute('data-theme')).toBe(theme); await capture('settings');
  155 |       stage = 'workspace'; await page.goto(sessionUrl(historyId));
  156 |       if (app === 'native') {
  157 |         await page.evaluate(() => window.dispatchEvent(new Event('aih-show-files')));
  158 |         const explorer = page.getByRole('complementary', { name: 'Workspace explorer', exact: true });
  159 |         await explorer.getByRole('button', { name: /^📄 note\.md(?:\s|$)/ }).click();
  160 |         await expect(page.locator('.file-viewer')).toContainText('Synthetic file boundary.');
> 161 |         await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
      |                                                                                          ^ Error: locator.click: Test timeout of 60000ms exceeded.
  162 |       } else {
  163 |         await refFiles(); await page.getByText('note.md', { exact: true }).click();
  164 |         await expect(page.locator('#file-panel')).toContainText('Synthetic file boundary.');
  165 |         await page.locator('#file-panel').getByRole('button', { name: 'Hide file panel', exact: true }).click();
  166 |         await refFiles(); await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
  167 |       }
  168 |       const terminal = page.locator(app === 'native' ? '.terminal-panel' : '.terminal-panel:visible');
  169 |       const terminalInput = terminal.locator('.xterm-helper-textarea'); await terminalInput.focus();
  170 |       await terminalInput.type("printf 'QUA02_'\"PTY_OK\\n\""); await terminalInput.press('Enter');
  171 |       await expect(terminal.locator('.xterm-rows')).toContainText('QUA02_PTY_OK', { timeout: 10_000 });
  172 |       await capture('workspace');
  173 |       expect(browserErrors).toEqual([]); expect(httpErrors).toEqual([]);
  174 |       if (app === 'piweb') expect(providerRequests.filter((call: any) => call.path === '/v1/chat/completions')).toHaveLength(1);
  175 |       stage = 'complete';
  176 |     } catch (error) {
  177 |       await capture('failure').catch(() => undefined); throw error;
  178 |     } finally {
  179 |       await info.attach('outcomes', { body: JSON.stringify({ app, viewport, theme, stage, base, cwd, historyId, liveId, browserErrors, httpErrors, providerRequests, events }, null, 2), contentType: 'application/json' });
  180 |       if (serverLog) await info.attach('reference-server', { body: serverLog, contentType: 'text/plain' });
  181 |       await page.goto('about:blank').catch(() => undefined);
  182 |       if (nativeStarted) await stop();
  183 |       if (child && child.exitCode === null && child.signalCode === null) {
  184 |         const exit = once(child, 'exit'); child.kill('SIGTERM'); const timer = setTimeout(() => child!.kill('SIGKILL'), 10_000); await exit; clearTimeout(timer);
  185 |       }
  186 |       if (model) { model.closeAllConnections(); await new Promise<void>(resolve => model!.close(() => resolve())); }
  187 |       for (const [index, name] of names.entries()) { if (previous[index] === undefined) delete process.env[name]; else process.env[name] = previous[index]; }
  188 |     }
  189 |   });
  190 | }
  191 | 
```