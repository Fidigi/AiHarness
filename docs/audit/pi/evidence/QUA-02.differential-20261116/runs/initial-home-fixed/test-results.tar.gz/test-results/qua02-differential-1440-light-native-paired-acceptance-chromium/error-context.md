# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qua02-differential.spec.ts >> 1440-light native paired acceptance
- Location: e2e/qua02-differential.spec.ts:16:3

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Send', exact: true })
    - locator resolved to <button type="submit">Send</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <aside class="pwa-status" aria-live="polite">…</aside> intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <aside class="pwa-status" aria-live="polite">…</aside> intercepts pointer events
    - retrying click action
      - waiting 100ms
    112 × waiting for element to be visible, enabled and stable
        - element is visible, enabled and stable
        - scrolling into view if needed
        - done scrolling
        - <aside class="pwa-status" aria-live="polite">…</aside> intercepts pointer events
      - retrying click action
        - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "Main navigation" [ref=e4]:
    - generic [ref=e5]:
      - heading "AiHarness" [level=1] [ref=e6]
      - generic [ref=e7]:
        - generic "Language" [ref=e8]:
          - generic [aria-hidden] [ref=e9]: 🌐
          - combobox "Language" [ref=e11] [cursor=pointer]:
            - option "English" [selected]
            - option "Français"
        - button "New chat" [ref=e12] [cursor=pointer]: +
    - generic [ref=e13]:
      - generic [ref=e14]: Workspace
      - generic [ref=e15]:
        - button "work /tmp/qua02/1440-light/native/work" [ref=e16] [cursor=pointer]:
          - generic [ref=e17]: work
          - generic [ref=e18]: /tmp/qua02/1440-light/native/work
        - link "Open project in a new tab" [ref=e19] [cursor=pointer]:
          - /url: /?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
          - text: ↗
        - button "Open workspace in file manager" [ref=e20] [cursor=pointer]: ↗
      - button "Linked directories" [ref=e21] [cursor=pointer]
    - generic [ref=e22]:
      - searchbox "Search conversations" [ref=e23]
      - button "Refresh files" [ref=e24] [cursor=pointer]: ↻
    - group [ref=e25]:
      - generic "Organise navigation" [ref=e26] [cursor=pointer]
    - navigation "Conversations" [ref=e27]:
      - list [ref=e28]:
        - listitem [ref=e29]:
          - link "QUA02 live turn 0 · 42 seconds ago" [ref=e31] [cursor=pointer]:
            - /url: /chat/9451adf7-e0e1-4c63-80b8-27ce6b9de79c?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
            - generic [ref=e32]: QUA02 live turn
            - generic [ref=e33]: 0 · 42 seconds ago
        - listitem [ref=e34]:
          - link "QUA02 history 180 · 42 seconds ago" [ref=e36] [cursor=pointer]:
            - /url: /chat/730610d2-c8bc-4c73-bdeb-f0a073a6db4a?cwd=%2Ftmp%2Fqua02%2F1440-light%2Fnative%2Fwork
            - generic [ref=e37]: QUA02 history
            - generic [ref=e38]: 180 · 42 seconds ago
    - button "⚙ Settings" [ref=e40] [cursor=pointer]
  - main [ref=e41]:
    - generic [ref=e42]:
      - generic [ref=e43]:
        - generic [ref=e44]:
          - strong [ref=e45]: QUA02 live turn
          - generic [ref=e46]: /tmp/qua02/1440-light/native/work
        - generic [ref=e47]:
          - group "Conversation navigation" [ref=e48]:
            - button "Previous conversation" [disabled] [ref=e49] [cursor=pointer]: ←
            - button "Next conversation" [ref=e50] [cursor=pointer]: →
          - status
          - button "Open child agents (0)" [ref=e52] [cursor=pointer]:
            - generic [ref=e53]: Child agents
            - generic [ref=e54]: "0"
          - button "Branches" [ref=e55] [cursor=pointer]
          - button "Context" [ref=e56] [cursor=pointer]
          - button "Information" [ref=e57] [cursor=pointer]
      - log "Conversation messages" [ref=e58]
      - generic [ref=e59]:
        - textbox "Message composer" [active] [ref=e60]:
          - /placeholder: "Type your message... (Provider: mock)"
          - text: QUA02 browser persistence check
        - generic [ref=e61]:
          - button "Add images" [ref=e62]
          - button "Add images" [ref=e63] [cursor=pointer]: ＋📷
          - generic [ref=e64]:
            - generic [ref=e65]: Model
            - combobox "Select the model" [ref=e66]
          - combobox "Thinking level" [ref=e67]:
            - option "Auto · off" [selected]
            - option "off"
            - option "minimal"
            - option "low"
            - option "medium"
            - option "high"
            - option "xhigh"
            - option "max"
          - combobox "Tool preset" [ref=e68]:
            - option "Auto · default" [selected]
            - option "configured"
            - option "chat-only"
            - option "read-only"
            - option "default"
            - option "full"
          - combobox "Auto-compaction" [ref=e69]:
            - option "Auto · On" [selected]
            - option "On"
            - option "Off"
          - button "Send" [ref=e70] [cursor=pointer]
        - generic "Effective conversation setting scopes" [ref=e71]:
          - group [ref=e72]:
            - generic "New-session model defaults" [ref=e73]: "Model: built-in default"
          - group [ref=e74]:
            - generic "New-session reasoning defaults" [ref=e75]: "Thinking level: built-in default"
          - generic [ref=e76]: "Tools: built-in default"
          - generic [ref=e77]: "Auto-compaction: built-in default"
  - complementary "Workspace explorer" [ref=e78]:
    - generic [ref=e79]:
      - generic [ref=e80]:
        - button "Files" [ref=e81] [cursor=pointer]
        - button "Changes" [ref=e82] [cursor=pointer]
      - generic [ref=e83]:
        - button "Close" [ref=e84] [cursor=pointer]: ×
        - button "Open terminal from file explorer" [ref=e85] [cursor=pointer]: ⌘
        - button "Collapse workspace explorer" [ref=e86] [cursor=pointer]: ›
    - button "Linked directories" [ref=e87] [cursor=pointer]
    - generic [ref=e88]:
      - searchbox "Search files" [ref=e89]
      - button "Refresh files" [ref=e90] [cursor=pointer]: ↻
      - generic "Upload files" [ref=e91] [cursor=pointer]: ↑
    - generic [ref=e93]:
      - text: On conflict
      - combobox "On conflict" [ref=e94]:
        - option "Reject" [selected]
        - option "Keep both"
        - option "Overwrite"
    - generic [ref=e95]:
      - checkbox "Show hidden files" [ref=e96]
      - text: Show hidden files
    - list [ref=e98]:
      - listitem [ref=e99]:
        - generic [ref=e100]:
          - button "📄 note.md" [ref=e101] [cursor=pointer]
          - button "Mention note.md" [ref=e102] [cursor=pointer]: "@"
  - button "Open workspace terminal" [ref=e103] [cursor=pointer]: ⌘
  - complementary "Status messages"
  - complementary [ref=e104]:
    - generic [ref=e105]: ● Offline — server actions are temporarily unavailable.
```

# Test source

```ts
  7   | import { start, stop } from '../packages/server/dist/index.js';
  8   | import { expect, test, reserveReadBudget } from './fixtures/test-budget';
  9   | 
  10  | // Temporary acceptance collector: existing native/upstream journeys, no product overrides.
  11  | test.describe.configure({ timeout: 60_000 });
  12  | const cells = [{ width: 1440, height: 900 }, { width: 820, height: 1180 }, { width: 390, height: 844 }];
  13  | const historyText = (index: number) => `History row ${index}: bounded qualification history.`;
  14  | const prompt = 'QUA02 browser persistence check';
  15  | for (const viewport of cells) for (const theme of ['light', 'dark']) for (const app of ['native', 'piweb']) {
  16  |   test(`${viewport.width}-${theme} ${app} paired acceptance`, async ({ page }, info) => {
  17  |     const root = `/tmp/qua02/${viewport.width}-${theme}/${app}`;
  18  |     const cwd = path.join(root, 'work'), dataDir = path.join(root, 'data'), agent = path.join(root, 'agent');
  19  |     await mkdir(cwd, { recursive: true }); await mkdir(agent, { recursive: true }); await mkdir(path.join(root, 'home'), { recursive: true });
  20  |     await writeFile(path.join(cwd, 'note.md'), '# QUA02 workspace\n\nSynthetic file boundary.\n');
  21  |     const events: unknown[] = [], browserErrors: string[] = [], httpErrors: string[] = [], providerRequests: unknown[] = [];
  22  |     let child: ChildProcess | undefined, model: ReturnType<typeof createServer> | undefined;
  23  |     let base = '', historyId = '', liveId = '', stage = 'bootstrap', serverLog = '';
  24  |     let nativeStarted = false;
  25  |     const names = ['AI_HARNESS_AUTH_TOKEN', 'AI_HARNESS_ADMIN_TOKEN', 'AI_HARNESS_AGENT_DIR', 'HOME'] as const;
  26  |     const previous = names.map(name => process.env[name]);
  27  |     const capture = async (name: string) => {
  28  |       await page.evaluate(() => document.fonts.ready);
  29  |       expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(viewport.width);
  30  |       const file = info.outputPath(`${name}.png`);
  31  |       await page.screenshot({ path: file, animations: 'disabled', caret: 'hide' });
  32  |       await info.attach(name, { path: file, contentType: 'image/png' });
  33  |     };
  34  |     const sidebar = async () => {
  35  |       const toggle = page.getByRole('button', { name: app === 'native' ? 'Toggle navigation' : 'Show sidebar', exact: true });
  36  |       if (app === 'native') {
  37  |         if (viewport.width < 960 && await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
  38  |       } else if (await toggle.isVisible()) await toggle.click();
  39  |     };
  40  |     const refFiles = async () => {
  41  |       await sidebar();
  42  |       const files = page.locator('#session-sidebar-panel-files');
  43  |       const tab = page.getByRole('tab', { name: 'Files', exact: true });
  44  |       const toggle = files.locator('.sidebar-files-section-toggle');
  45  |       await expect(tab.or(toggle).first()).toBeVisible();
  46  |       if (await tab.count()) { if (await tab.getAttribute('aria-selected') !== 'true') await tab.click(); }
  47  |       else if (await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
  48  |       await expect(files.locator('.sidebar-files-body')).toBeVisible();
  49  |     };
  50  |     try {
  51  |       if (app === 'native') {
  52  |         process.env.AI_HARNESS_AUTH_TOKEN = ''; process.env.AI_HARNESS_ADMIN_TOKEN = ''; process.env.AI_HARNESS_AGENT_DIR = agent; process.env.HOME = path.join(root, 'home');
  53  |         const manager = new SessionManager({ store: new JsonlSessionStore(path.join(dataDir, 'sessions')) });
  54  |         const history = await manager.create({ cwd, title: 'QUA02 history' }); historyId = history.id;
  55  |         for (let index = 0; index < 180; index++) await manager.addMessage(historyId, { role: index % 2 ? 'assistant' : 'user', content: historyText(index) });
  56  |         const server = await start({ port: 0, host: '127.0.0.1', dataDir, defaultCwd: cwd, allowedRoots: [cwd], webRoot: path.resolve('packages/web/dist'), enableMockProvider: true });
  57  |         nativeStarted = true; base = `http://127.0.0.1:${server.port}`;
  58  |         await reserveReadBudget(page.request, base);
  59  |         expect((await page.request.post(`${base}/api/workspaces/trust`, { data: { cwd, confirm: true } })).status()).toBe(200);
  60  |         const created = await page.request.post(`${base}/api/sessions`, { data: { cwd, title: 'QUA02 live turn' } }); expect(created.status()).toBe(201);
  61  |         liveId = (await created.json()).id;
  62  |       } else {
  63  |         model = createServer(async (request, response) => {
  64  |           let raw = ''; for await (const chunk of request) raw += chunk;
  65  |           const body = raw ? JSON.parse(raw) : {}; providerRequests.push({ path: request.url, body });
  66  |           if (request.url !== '/v1/chat/completions') { response.writeHead(404); response.end(); return; }
  67  |           response.writeHead(200, { 'content-type': 'text/event-stream' });
  68  |           const delta = (value: unknown) => response.write(`data: ${JSON.stringify(value)}\n\n`);
  69  |           delta({ id: 'qua02', object: 'chat.completion.chunk', model: 'qua02-fixture', choices: [{ index: 0, delta: { role: 'assistant', content: 'QUA02 synthetic reply.\n\nPersisted bounded turn.' }, finish_reason: null }] });
  70  |           delta({ id: 'qua02', object: 'chat.completion.chunk', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } });
  71  |           response.end('data: [DONE]\n\n');
  72  |         });
  73  |         model.listen(0, '127.0.0.1'); await once(model, 'listening');
  74  |         const modelPort = (model.address() as { port: number }).port;
  75  |         await writeFile(path.join(agent, 'models.json'), JSON.stringify({ providers: { qua02: { baseUrl: `http://127.0.0.1:${modelPort}/v1`, api: 'openai-completions', apiKey: 'synthetic-qua02-only', models: [{ id: 'qua02-fixture', name: 'QUA02 fixture', reasoning: false, input: ['text'], contextWindow: 32768, maxTokens: 1024, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 } }] } } }));
  76  |         await writeFile(path.join(agent, 'settings.json'), JSON.stringify({ defaultProvider: 'qua02', defaultModel: 'qua02-fixture', defaultThinkingLevel: 'off' }));
  77  |         historyId = 'qua02-history'; const timestamp = '2026-11-16T10:00:00.000Z';
  78  |         const sessionDir = path.join(agent, 'sessions', 'e2e'); await mkdir(sessionDir, { recursive: true });
  79  |         const entries: unknown[] = [{ type: 'session', version: 3, id: historyId, cwd, timestamp }, { type: 'session_info', id: 'name', parentId: null, timestamp, name: 'QUA02 history' }];
  80  |         for (let index = 0; index < 180; index++) entries.push({ type: 'message', id: `e${index}`, parentId: index ? `e${index - 1}` : 'name', timestamp, message: { role: index % 2 ? 'assistant' : 'user', content: historyText(index) } });
  81  |         await writeFile(path.join(sessionDir, 'history.jsonl'), entries.map(entry => JSON.stringify(entry)).join('\n') + '\n');
  82  |         child = spawn(process.execPath, ['/reference/node_modules/next/dist/bin/next', 'start', '-H', '127.0.0.1', '-p', '13041'], { cwd: '/reference', env: { ...process.env, HOME: path.join(root, 'home'), PI_CODING_AGENT_DIR: agent, PI_WEB_PASSWORD: '', PI_WEB_SKIP_VERSION_CHECK: '1', NEXT_TELEMETRY_DISABLED: '1', HISTFILE: '/dev/null' }, stdio: ['ignore', 'pipe', 'pipe'] });
  83  |         child.stdout!.on('data', chunk => { serverLog += chunk; }); child.stderr!.on('data', chunk => { serverLog += chunk; });
  84  |         base = 'http://127.0.0.1:13041';
  85  |         await expect.poll(async () => {
  86  |           if (child!.exitCode !== null || child!.signalCode !== null) throw new Error(`Reference server terminated: ${child!.exitCode}/${child!.signalCode}`);
  87  |           return fetch(`${base}/api/sessions`).then(response => response.status).catch(() => 0);
  88  |         }, { timeout: 120_000 }).toBe(200);
  89  |         const created = await page.request.post(`${base}/api/agent/new`, { data: { cwd, type: 'ensure_session', provider: 'qua02', modelId: 'qua02-fixture', thinkingLevel: 'off', toolNames: [] } });
  90  |         expect(created.status(), await created.text()).toBe(200); liveId = (await created.json()).sessionId;
  91  |       }
  92  |       await page.setViewportSize(viewport);
  93  |       await page.addInitScript(({ app, theme }) => {
  94  |         if (app === 'native') { localStorage.setItem('ai-harness-locale', 'en'); localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({ version: 4, theme })); }
  95  |         else { localStorage.setItem('pi-locale', 'en'); localStorage.setItem('pi-theme', theme); }
  96  |       }, { app, theme });
  97  |       page.on('pageerror', error => browserErrors.push(error.message));
  98  |       page.on('console', message => { if (message.type() === 'error') events.push({ consoleError: message.text() }); });
  99  |       page.on('response', response => {
  100 |         const url = new URL(response.url()); if (url.origin !== base || !url.pathname.startsWith('/api/')) return;
  101 |         events.push({ method: response.request().method(), path: url.pathname + url.search, status: response.status() });
  102 |         if (response.status() === 429 || response.status() >= 500) httpErrors.push(`${response.status()} ${url.pathname}`);
  103 |       });
  104 |       const sessionUrl = (id: string) => app === 'native' ? `${base}/chat/${id}?cwd=${encodeURIComponent(cwd)}` : `${base}/?session=${id}`;
  105 |       const input = page.locator(app === 'native' ? '.input-container textarea' : '.chat-input-textarea');
  106 |       stage = 'live'; await page.goto(sessionUrl(liveId)); await expect(input).toBeVisible(); await input.fill(prompt);
> 107 |       await page.getByRole('button', { name: 'Send', exact: true }).click();
      |                                                                     ^ Error: locator.click: Test timeout of 60000ms exceeded.
  108 |       const reply = app === 'native' ? page.locator('.message.assistant').last() : page.locator('[data-message-role="assistant"]').last();
  109 |       await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.', { timeout: 15_000 });
  110 |       await page.reload(); await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.');
  111 |       await capture('conversation');
  112 |       stage = 'history'; await sidebar();
  113 |       if (app === 'native') await page.locator('.sidebar-nav a.session-main').filter({ hasText: 'QUA02 history' }).click();
  114 |       else {
  115 |         const sessions = page.getByRole('tab', { name: 'Sessions', exact: true }); if (await sessions.isVisible() && await sessions.getAttribute('aria-selected') !== 'true') await sessions.click();
  116 |         await page.locator('.session-tree-session').filter({ has: page.locator('.session-tree-title', { hasText: /^QUA02 history$/ }) }).locator('.session-tree-main').click();
  117 |       }
  118 |       await expect(page.getByText(historyText(179), { exact: true })).toBeVisible();
  119 |       const earlier = page.getByText(app === 'native' ? 'Load earlier messages' : 'Scroll up to load earlier messages', { exact: true });
  120 |       if (app === 'native') { await earlier.scrollIntoViewIfNeeded(); await earlier.click(); }
  121 |       else await earlier.evaluate(element => element.scrollIntoView({ block: 'start', behavior: 'instant' }));
  122 |       const older = page.getByText(historyText(90), { exact: true }); await expect(older).toBeAttached(); await older.scrollIntoViewIfNeeded(); await expect(older).toBeVisible();
  123 |       await capture('history'); await page.reload(); await expect(page.getByText(historyText(179), { exact: true })).toBeAttached();
  124 |       expect(page.url()).toContain(historyId);
  125 |       stage = 'settings';
  126 |       if (app === 'native') {
  127 |         await page.goto(`${base}/settings#appearance`);
  128 |         const control = page.locator('#appearance').getByLabel(/^Theme/); await control.selectOption(theme === 'light' ? 'dark' : 'light'); await control.selectOption(theme);
  129 |         await page.reload(); await expect(control).toHaveValue(theme); await control.scrollIntoViewIfNeeded();
  130 |       } else {
  131 |         await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  132 |         const radio = (value: string) => page.getByRole('radio', { name: value === 'light' ? 'Light' : 'Dark', exact: true });
  133 |         await radio(theme === 'light' ? 'dark' : 'light').locator('..').click(); await radio(theme).locator('..').click();
  134 |         await page.keyboard.press('Escape'); await page.reload(); await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
  135 |         await expect(radio(theme)).toBeChecked();
  136 |       }
  137 |       expect(await page.locator('html').getAttribute('data-theme')).toBe(theme); await capture('settings');
  138 |       stage = 'workspace'; await page.goto(sessionUrl(historyId));
  139 |       if (app === 'native') {
  140 |         await page.evaluate(() => window.dispatchEvent(new Event('aih-show-files')));
  141 |         const explorer = page.getByRole('complementary', { name: 'Workspace explorer', exact: true });
  142 |         await explorer.getByRole('button', { name: /^📄 note\.md(?:\s|$)/ }).click();
  143 |         await expect(page.locator('.file-viewer')).toContainText('Synthetic file boundary.');
  144 |         await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
  145 |       } else {
  146 |         await refFiles(); await page.getByText('note.md', { exact: true }).click();
  147 |         await expect(page.locator('#file-panel')).toContainText('Synthetic file boundary.');
  148 |         await refFiles(); await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
  149 |       }
  150 |       const terminal = page.locator(app === 'native' ? '.terminal-panel' : '.terminal-panel:visible');
  151 |       const terminalInput = terminal.locator('.xterm-helper-textarea'); await terminalInput.focus();
  152 |       await terminalInput.type("printf 'QUA02_'\"PTY_OK\\n\""); await terminalInput.press('Enter');
  153 |       await expect(terminal.locator('.xterm-rows')).toContainText('QUA02_PTY_OK', { timeout: 10_000 });
  154 |       await capture('workspace');
  155 |       expect(browserErrors).toEqual([]); expect(httpErrors).toEqual([]);
  156 |       if (app === 'piweb') expect(providerRequests.filter((call: any) => call.path === '/v1/chat/completions')).toHaveLength(1);
  157 |       stage = 'complete';
  158 |     } catch (error) {
  159 |       await capture('failure').catch(() => undefined); throw error;
  160 |     } finally {
  161 |       await info.attach('outcomes', { body: JSON.stringify({ app, viewport, theme, stage, base, cwd, historyId, liveId, browserErrors, httpErrors, providerRequests, events }, null, 2), contentType: 'application/json' });
  162 |       if (serverLog) await info.attach('reference-server', { body: serverLog, contentType: 'text/plain' });
  163 |       await page.goto('about:blank').catch(() => undefined);
  164 |       if (nativeStarted) await stop();
  165 |       if (child && child.exitCode === null && child.signalCode === null) {
  166 |         const exit = once(child, 'exit'); child.kill('SIGTERM'); const timer = setTimeout(() => child!.kill('SIGKILL'), 10_000); await exit; clearTimeout(timer);
  167 |       }
  168 |       if (model) { model.closeAllConnections(); await new Promise<void>(resolve => model!.close(() => resolve())); }
  169 |       for (const [index, name] of names.entries()) { if (previous[index] === undefined) delete process.env[name]; else process.env[name] = previous[index]; }
  170 |     }
  171 |   });
  172 | }
  173 | 
```