# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: terminal-controls.spec.ts >> native terminal touch controls >> sends actual touch modifiers and application cursors through the native HTTP owner to a real PTY
- Location: e2e/terminal-controls.spec.ts:15:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('complementary', { name: 'Workspace explorer', exact: true })
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('complementary', { name: 'Workspace explorer', exact: true }) with timeout 5000ms
  - waiting for getByRole('complementary', { name: 'Workspace explorer', exact: true })
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "Toggle navigation" [ref=e4]
  - button "Workspace explorer" [expanded] [ref=e6]: ☷
  - complementary [aria-hidden] [ref=e7]:
    - generic [ref=e8]:
      - heading [level=1] [ref=e9]: AiHarness
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [aria-hidden] [ref=e12]: 🌐
          - generic [ref=e13]: Language
          - combobox [ref=e14] [cursor=pointer]
        - button [ref=e15] [cursor=pointer]: +
    - generic [ref=e16]:
      - generic [ref=e17]: Workspace
      - generic [ref=e18]:
        - button [ref=e19] [cursor=pointer]:
          - generic [ref=e20]: app
          - generic [ref=e21]: /app
        - link [ref=e22] [cursor=pointer]:
          - /url: /?cwd=%2Fapp
          - text: ↗
        - button [ref=e23] [cursor=pointer]: ↗
      - button [ref=e24] [cursor=pointer]: Linked directories
    - generic [ref=e25]:
      - searchbox [ref=e26]
      - button [ref=e27] [cursor=pointer]: ↻
    - group [ref=e28]:
      - generic [ref=e29] [cursor=pointer]: Organise navigation
    - navigation [ref=e30]
    - button [ref=e32] [cursor=pointer]: ⚙ Settings
  - main [ref=e33]:
    - generic [ref=e34]:
      - heading "Welcome to AiHarness" [level=2] [ref=e35]
      - paragraph [ref=e36]: Select a conversation or create a new one.
  - complementary "Workspace explorer" [ref=e37]:
    - generic [ref=e38]:
      - generic [ref=e39]:
        - button "Files" [ref=e40] [cursor=pointer]
        - button "Changes" [ref=e41] [cursor=pointer]
      - generic [ref=e42]:
        - button "Close" [ref=e43] [cursor=pointer]: ×
        - button "Open terminal from file explorer" [ref=e44] [cursor=pointer]: ⌘
        - button "Collapse workspace explorer" [ref=e45] [cursor=pointer]: ›
    - button "Linked directories" [ref=e46] [cursor=pointer]
    - generic [ref=e47]:
      - searchbox "Search files" [ref=e48]
      - button "Refresh files" [ref=e49] [cursor=pointer]: ↻
      - generic "Upload files" [ref=e50] [cursor=pointer]: ↑
    - generic [ref=e52]:
      - text: On conflict
      - combobox "On conflict" [ref=e53]:
        - option "Reject" [selected]
        - option "Keep both"
        - option "Overwrite"
    - generic [ref=e54]:
      - checkbox "Show hidden files" [ref=e55]
      - text: Show hidden files
    - list [ref=e57]:
      - listitem [ref=e58]:
        - button "📁 demo" [ref=e60] [cursor=pointer]
      - listitem [ref=e61]:
        - button "📁 e2e" [ref=e63] [cursor=pointer]
      - listitem [ref=e64]:
        - button "📁 node_modules" [ref=e66] [cursor=pointer]
      - listitem [ref=e67]:
        - button "📁 packages" [ref=e69] [cursor=pointer]
      - listitem [ref=e70]:
        - button "📁 scripts" [ref=e72] [cursor=pointer]
      - listitem [ref=e73]:
        - button "📁 test-results" [ref=e75] [cursor=pointer]
      - listitem [ref=e76]:
        - button "📁 tests" [ref=e78] [cursor=pointer]
      - listitem [ref=e79]:
        - generic [ref=e80]:
          - button "📄 package-lock.json" [ref=e81] [cursor=pointer]
          - button "Mention package-lock.json" [ref=e82] [cursor=pointer]: "@"
      - listitem [ref=e83]:
        - generic [ref=e84]:
          - button "📄 package.json" [ref=e85] [cursor=pointer]
          - button "Mention package.json" [ref=e86] [cursor=pointer]: "@"
      - listitem [ref=e87]:
        - generic [ref=e88]:
          - button "📄 playwright.config.ts" [ref=e89] [cursor=pointer]
          - button "Mention playwright.config.ts" [ref=e90] [cursor=pointer]: "@"
      - listitem [ref=e91]:
        - generic [ref=e92]:
          - button "📄 tsconfig.json" [ref=e93] [cursor=pointer]
          - button "Mention tsconfig.json" [ref=e94] [cursor=pointer]: "@"
      - listitem [ref=e95]:
        - generic [ref=e96]:
          - button "📄 vitest.config.ts" [ref=e97] [cursor=pointer]
          - button "Mention vitest.config.ts" [ref=e98] [cursor=pointer]: "@"
  - region "Terminal" [ref=e99]:
    - generic [ref=e100]:
      - navigation "Terminal tabs" [ref=e101]:
        - generic [ref=e102]:
          - button "Terminal 1" [ref=e103] [cursor=pointer]
          - button "Close Terminal 1" [ref=e105] [cursor=pointer]: ×
        - button "New terminal" [ref=e106] [cursor=pointer]: +
      - generic [ref=e107]:
        - combobox "Terminal theme" [ref=e108]:
          - option "Dark" [selected]
          - option "Light"
        - button "Hide terminal" [ref=e109] [cursor=pointer]: ⌄
    - application "Terminal 1" [ref=e110]:
      - generic [ref=e113]:
        - textbox "Terminal input" [active] [ref=e114]
        - generic [aria-hidden]:
          - generic: "#"
    - group "Terminal extra keys" [ref=e115]:
      - button "ESC" [ref=e116]
      - button / [ref=e117]
      - button "-" [ref=e118]
      - button "HOME" [ref=e119]
      - button "Up" [ref=e120]: ↑
      - button "END" [ref=e121]
      - button "PGUP" [ref=e122]
      - button "TAB" [ref=e123]
      - button "CTRL" [ref=e124]
      - button "ALT" [ref=e125]
      - button "Left" [ref=e126]: ←
      - button "Down" [ref=e127]: ↓
      - button "Right" [ref=e128]: →
      - button "PGDN" [ref=e129]
  - complementary "Status messages"
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright';
  2   | import { expect, test, type Page } from './fixtures/test-budget';
  3   | import { installTerminalControls } from './fixtures/terminal-controls';
  4   | 
  5   | async function open(page: Page, locale = 'en') {
  6   |   await page.goto('/');
  7   |   await page.getByRole('button', { name: locale === 'fr' ? 'Ouvrir le terminal du workspace' : 'Open workspace terminal', exact: true }).click();
  8   |   const panel = page.getByRole('region', { name: 'Terminal', exact: true });
  9   |   await expect(panel).toBeVisible();
  10  |   return panel;
  11  | }
  12  | 
  13  | test.describe('native terminal touch controls', () => {
  14  |   test.use({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  15  |   test('sends actual touch modifiers and application cursors through the native HTTP owner to a real PTY', async ({ page }) => {
  16  |     const workspaceResponse = await page.request.get('/api/workspaces/default'); expect(workspaceResponse.status()).toBe(200);
  17  |     const workspace = await workspaceResponse.json() as { cwd: string };
  18  |     // Explicit fixture consent through the unchanged administrator/trust route, not a browser permission grant.
  19  |     const trust = await page.request.post('/api/workspaces/trust', { data: { cwd: workspace.cwd, confirm: true } });
  20  |     expect(trust.status()).toBe(200);
  21  |     await page.goto('/'); await expect(page.locator('.workspace-button small')).not.toBeEmpty();
  22  |     await page.evaluate(() => window.dispatchEvent(new Event('aih-show-files')));
  23  |     const explorer = page.getByRole('complementary', { name: 'Workspace explorer', exact: true });
  24  |     await expect(explorer).toBeVisible();
  25  |     const created = page.waitForResponse(response => new URL(response.url()).pathname === '/api/terminals' && response.request().method() === 'POST');
  26  |     await explorer.getByRole('button', { name: 'Open terminal from file explorer', exact: true }).click();
  27  |     // The narrow explorer overlays the terminal: opening a PTY must reveal it,
  28  |     // not merely produce xterm output in an obscured DOM subtree.
> 29  |     await expect(explorer).toHaveCount(0);
      |                            ^ Error: expect(locator).toHaveCount(expected) failed
  30  |     const response = await created; expect(response.status()).toBe(201);
  31  |     const snapshot = await response.json() as { id: string }; expect(typeof snapshot.id).toBe('string');
  32  |     try {
  33  |       const panel = page.getByRole('region', { name: 'Terminal', exact: true });
  34  |       const code = 'process.stdin.setRawMode(true);process.stdin.resume();process.stdout.write("\\x1b[?1hKEY_"+"PROBE_READY\\r\\n");process.stdin.on("data",b=>{console.log("KEY_HEX="+b.toString("hex"));if(b.equals(Buffer.from([4])))process.exit(0)})';
  35  |       // Explicit fixture setup through the unchanged public, trust-gated input route.
  36  |       const setup = await page.request.post(`/api/terminals/${encodeURIComponent(snapshot.id)}/input`, { data: { data: `node -e '${code}'\r` } });
  37  |       expect(setup.status()).toBe(200);
  38  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_PROBE_READY');
  39  |       const keys = panel.getByRole('group', { name: 'Terminal extra keys' });
  40  |       await panel.locator('.xterm-helper-textarea').focus();
  41  |       await keys.getByRole('button', { name: 'CTRL', exact: true }).tap(); await page.keyboard.type('c');
  42  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=03');
  43  |       await page.keyboard.type('c'); await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=63');
  44  |       await keys.getByRole('button', { name: 'Up', exact: true }).tap();
  45  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=1b4f41');
  46  |       await panel.getByLabel('Terminal theme', { exact: true }).selectOption('light');
  47  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=1b4f41');
  48  |       await panel.locator('.xterm-helper-textarea').focus();
  49  |       await keys.getByRole('button', { name: 'ALT', exact: true }).tap(); await page.keyboard.type('x');
  50  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=1b78');
  51  |       await page.keyboard.type('x'); await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=78');
  52  |       await panel.locator('.xterm-helper-textarea').focus(); await keys.getByRole('button', { name: 'CTRL', exact: true }).tap(); await page.keyboard.type('d');
  53  |       await expect(panel.locator('.xterm-rows')).toContainText('KEY_HEX=04');
  54  |     } finally {
  55  |       const removed = await page.request.delete(`/api/terminals/${encodeURIComponent(snapshot.id)}`);
  56  |       expect(removed.status()).toBe(200);
  57  |     }
  58  |   });
  59  |   test('owns one-shot modifiers and cursor modes without blurring the terminal or duplicating touch input', async ({ page }) => {
  60  |     const f = await installTerminalControls(page);
  61  |     const panel = await open(page);
  62  |     await expect(panel.locator('.xterm-rows')).toContainText('TERMINAL_CONTROLS_READY');
  63  |     const keys = panel.getByRole('group', { name: 'Terminal extra keys' });
  64  |     const textarea = panel.locator('.xterm-helper-textarea');
  65  |     await textarea.focus(); await expect(textarea).toBeFocused();
  66  |     await keys.getByRole('button', { name: 'CTRL', exact: true }).tap();
  67  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toHaveAttribute('aria-pressed', 'true');
  68  |     await expect(textarea).toBeFocused();
  69  |     await page.keyboard.type('c');
  70  |     await expect.poll(() => [...f.input]).toEqual(['\x03']);
  71  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toHaveAttribute('aria-pressed', 'false');
  72  |     await page.keyboard.type('c');
  73  |     await keys.getByRole('button', { name: 'ALT', exact: true }).tap();
  74  |     await page.keyboard.type('x'); await page.keyboard.type('x');
  75  |     await keys.getByRole('button', { name: 'Up', exact: true }).tap();
  76  |     await expect.poll(() => [...f.input]).toEqual(['\x03', 'c', '\x1bx', 'x', '\x1b[A']);
  77  |     f.applicationCursor(true); await expect(panel.locator('.xterm-rows')).toContainText('APP_CURSOR_ON');
  78  |     await keys.getByRole('button', { name: 'Up', exact: true }).tap();
  79  |     await keys.getByRole('button', { name: 'CTRL', exact: true }).tap();
  80  |     await keys.getByRole('button', { name: 'ALT', exact: true }).tap();
  81  |     await keys.getByRole('button', { name: 'Left', exact: true }).tap();
  82  |     await keys.getByRole('button', { name: 'TAB', exact: true }).focus(); await page.keyboard.press('Enter');
  83  |     await expect.poll(() => f.input.slice(-3)).toEqual(['\x1bOA', '\x1b[1;7D', '\t']);
  84  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toHaveAttribute('aria-pressed', 'false');
  85  |     await expect(keys.getByRole('button', { name: 'ALT', exact: true })).toHaveAttribute('aria-pressed', 'false');
  86  |     expect(f.counts().created).toBe(1); expect(f.counts().deleted).toBe(0);
  87  |   });
  88  | 
  89  |   test('disables pending/disconnected/exited input and clears stale one-shot intent on recovery', async ({ page }) => {
  90  |     const f = await installTerminalControls(page, true);
  91  |     const panel = await open(page), keys = panel.getByRole('group', { name: 'Terminal extra keys' });
  92  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toBeDisabled();
  93  |     f.release(); await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toBeEnabled();
  94  |     await keys.getByRole('button', { name: 'CTRL', exact: true }).tap(); f.disconnect(true);
  95  |     await expect(panel.getByRole('alert')).toContainText('Terminal connection unavailable');
  96  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toBeDisabled();
  97  |     await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toHaveAttribute('aria-pressed', 'false');
  98  |     await panel.locator('.xterm-helper-textarea').focus(); await page.keyboard.type('x'); expect(f.input).toEqual([]);
  99  |     f.disconnect(false); await expect(keys.getByRole('button', { name: 'CTRL', exact: true })).toBeEnabled();
  100 |     await panel.locator('.xterm-helper-textarea').focus(); await page.keyboard.type('x');
  101 |     await expect.poll(() => [...f.input]).toEqual(['x']);
  102 |     f.exit(); await expect(keys.getByRole('button', { name: 'Up', exact: true })).toBeDisabled();
  103 |     await page.keyboard.type('z'); expect(f.input).toEqual(['x']);
  104 |     expect(f.counts().created).toBe(1);
  105 |   });
  106 | 
  107 |   test('keeps the same live xterm through terminal-only theme changes and viewport/keyboard geometry', async ({ page }) => {
  108 |     const f = await installTerminalControls(page); const panel = await open(page);
  109 |     await expect(panel.locator('.xterm-rows')).toContainText('TERMINAL_CONTROLS_READY');
  110 |     await panel.locator('.xterm').evaluate(node => node.setAttribute('data-owned-terminal', 'original'));
  111 |     const appTheme = await page.locator('html').getAttribute('data-theme');
  112 |     await panel.getByLabel('Terminal theme', { exact: true }).selectOption('light');
  113 |     await expect(panel.locator('.terminal-surface')).toHaveAttribute('data-terminal-theme', 'light');
  114 |     await expect(panel.locator('.xterm-scrollable-element')).toHaveCSS('background-color', 'rgb(248, 250, 252)');
  115 |     await expect(panel.locator('.xterm-viewport')).toHaveCSS('background-color', 'rgb(248, 250, 252)');
  116 |     await expect(panel.locator('.xterm')).toHaveCSS('background-color', 'rgb(248, 250, 252)');
  117 |     await expect(page.locator('html')).toHaveAttribute('data-theme', appTheme!);
  118 |     await expect(panel.locator('.xterm[data-owned-terminal="original"]')).toHaveCount(1);
  119 |     await page.setViewportSize({ width: 390, height: 570 });
  120 |     await expect(panel.locator('.xterm[data-owned-terminal="original"]')).toHaveCount(1);
  121 |     await page.setViewportSize({ width: 844, height: 390 });
  122 |     await expect(panel.getByRole('group', { name: 'Terminal extra keys' })).toHaveCount(0);
  123 |     await expect(panel.locator('.xterm[data-owned-terminal="original"]')).toHaveCount(1);
  124 |     await page.setViewportSize({ width: 390, height: 844 });
  125 |     await expect(panel.getByRole('group', { name: 'Terminal extra keys' })).toBeVisible();
  126 |     await panel.getByLabel('Terminal theme', { exact: true }).selectOption('dark');
  127 |     await expect(panel.locator('.xterm-scrollable-element')).toHaveCSS('background-color', 'rgb(17, 24, 39)');
  128 |     await expect(panel.locator('.xterm-viewport')).toHaveCSS('background-color', 'rgb(17, 24, 39)');
  129 |     await expect(panel.locator('.xterm')).toHaveCSS('background-color', 'rgb(17, 24, 39)');
```