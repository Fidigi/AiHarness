#!/bin/bash
set -u
base=/tmp/aih-qua02-differential-20261116
name=$1
selector=$2
container=aih-qua02-$name-20261116
mkdir -p "$base/results/$name"
printf 'start=%s\ncommand=node .docker/run-e2e.mjs e2e/qua02-differential.spec.ts %s --reporter=line,json --trace=on --max-failures=1\n' "$(date -u +%FT%TZ)" "$selector" > "$base/results/$name/command"
docker create --name "$container" --network=none --shm-size=1g aih-qua02:collector-20261116 node .docker/run-e2e.mjs e2e/qua02-differential.spec.ts "$selector" --reporter=line,json --trace=on --max-failures=1 > "$base/results/$name/container-id"
docker start --attach "$container" > "$base/results/$name/run.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/$name/command"
printf '%s\n' "$code" > "$base/results/$name/exit"
docker inspect "$container" > "$base/results/$name/container.json"
docker cp "$container:/app/test-results" "$base/results/$name/test-results"
docker cp "$container:/app/playwright-report" "$base/results/$name/playwright-report"
# Retain the exited owned container until final source/provenance readback.
exit "$code"
