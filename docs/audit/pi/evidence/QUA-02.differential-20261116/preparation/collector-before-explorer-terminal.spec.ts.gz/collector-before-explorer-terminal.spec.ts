import { createServer } from 'node:http';
import { spawn, type ChildProcess } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { once } from 'node:events';
import path from 'node:path';
import { JsonlSessionStore, SessionManager } from '@ai-harness/core';
import { start, stop } from '../packages/server/dist/index.js';
import { expect, test, reserveReadBudget } from './fixtures/test-budget';

// Temporary acceptance collector: existing native/upstream journeys, no product overrides.
test.describe.configure({ timeout: 60_000 });
const cells = [{ width: 1440, height: 900 }, { width: 820, height: 1180 }, { width: 390, height: 844 }];
const historyText = (index: number) => `History row ${index}: bounded qualification history.`;
const prompt = 'QUA02 browser persistence check';
for (const viewport of cells) for (const theme of ['light', 'dark']) for (const app of ['native', 'piweb']) {
  test(`${viewport.width}-${theme} ${app} paired acceptance`, async ({ page }, info) => {
    const root = `/tmp/qua02/${viewport.width}-${theme}/${app}`;
    const cwd = path.join(root, 'work'), dataDir = path.join(root, 'data'), agent = path.join(root, 'agent');
    await mkdir(cwd, { recursive: true }); await mkdir(agent, { recursive: true }); await mkdir(path.join(root, 'home'), { recursive: true });
    await writeFile(path.join(cwd, 'note.md'), '# QUA02 workspace\n\nSynthetic file boundary.\n');
    const events: unknown[] = [], browserErrors: string[] = [], httpErrors: string[] = [], providerRequests: unknown[] = [];
    let child: ChildProcess | undefined, model: ReturnType<typeof createServer> | undefined;
    let base = '', historyId = '', liveId = '', stage = 'bootstrap', serverLog = '';
    let nativeStarted = false;
    const names = ['AI_HARNESS_AUTH_TOKEN', 'AI_HARNESS_ADMIN_TOKEN', 'AI_HARNESS_AGENT_DIR', 'HOME'] as const;
    const previous = names.map(name => process.env[name]);
    const capture = async (name: string) => {
      await page.evaluate(() => document.fonts.ready);
      expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(viewport.width);
      const file = info.outputPath(`${name}.png`);
      await page.screenshot({ path: file, animations: 'disabled', caret: 'hide' });
      await info.attach(name, { path: file, contentType: 'image/png' });
    };
    const sidebar = async () => {
      const toggle = page.getByRole('button', { name: app === 'native' ? 'Toggle navigation' : 'Show sidebar', exact: true });
      if (app === 'native') {
        if (viewport.width < 960 && await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
      } else if (await toggle.isVisible()) await toggle.click();
    };
    const refFiles = async () => {
      await sidebar();
      const files = page.locator('#session-sidebar-panel-files');
      const tab = page.getByRole('tab', { name: 'Files', exact: true });
      const toggle = files.locator('.sidebar-files-section-toggle');
      await expect(tab.or(toggle).first()).toBeVisible();
      if (await tab.count()) { if (await tab.getAttribute('aria-selected') !== 'true') await tab.click(); }
      else if (await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click();
      await expect(files.locator('.sidebar-files-body')).toBeVisible();
    };
    try {
      if (app === 'native') {
        process.env.AI_HARNESS_AUTH_TOKEN = ''; process.env.AI_HARNESS_ADMIN_TOKEN = ''; process.env.AI_HARNESS_AGENT_DIR = agent; process.env.HOME = path.join(root, 'home');
        const manager = new SessionManager({ store: new JsonlSessionStore(path.join(dataDir, 'sessions')) });
        const history = await manager.create({ cwd, title: 'QUA02 history' }); historyId = history.id;
        for (let index = 0; index < 180; index++) await manager.addMessage(historyId, { role: index % 2 ? 'assistant' : 'user', content: historyText(index) });
        const server = await start({ port: 0, host: '127.0.0.1', dataDir, defaultCwd: cwd, allowedRoots: [cwd], webRoot: path.resolve('packages/web/dist'), enableMockProvider: true });
        nativeStarted = true; base = `http://127.0.0.1:${server.port}`;
        await reserveReadBudget(page.request, base);
        expect((await page.request.post(`${base}/api/workspaces/trust`, { data: { cwd, confirm: true } })).status()).toBe(200);
        const created = await page.request.post(`${base}/api/sessions`, { data: { cwd, title: 'QUA02 live turn' } }); expect(created.status()).toBe(201);
        liveId = (await created.json()).id;
      } else {
        model = createServer(async (request, response) => {
          let raw = ''; for await (const chunk of request) raw += chunk;
          const body = raw ? JSON.parse(raw) : {}; providerRequests.push({ path: request.url, body });
          if (request.url !== '/v1/chat/completions') { response.writeHead(404); response.end(); return; }
          response.writeHead(200, { 'content-type': 'text/event-stream' });
          const delta = (value: unknown) => response.write(`data: ${JSON.stringify(value)}\n\n`);
          delta({ id: 'qua02', object: 'chat.completion.chunk', model: 'qua02-fixture', choices: [{ index: 0, delta: { role: 'assistant', content: 'QUA02 synthetic reply.\n\nPersisted bounded turn.' }, finish_reason: null }] });
          delta({ id: 'qua02', object: 'chat.completion.chunk', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } });
          response.end('data: [DONE]\n\n');
        });
        model.listen(0, '127.0.0.1'); await once(model, 'listening');
        const modelPort = (model.address() as { port: number }).port;
        await writeFile(path.join(agent, 'models.json'), JSON.stringify({ providers: { qua02: { baseUrl: `http://127.0.0.1:${modelPort}/v1`, api: 'openai-completions', apiKey: 'synthetic-qua02-only', models: [{ id: 'qua02-fixture', name: 'QUA02 fixture', reasoning: false, input: ['text'], contextWindow: 32768, maxTokens: 1024, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 } }] } } }));
        await writeFile(path.join(agent, 'settings.json'), JSON.stringify({ defaultProvider: 'qua02', defaultModel: 'qua02-fixture', defaultThinkingLevel: 'off' }));
        historyId = 'qua02-history'; const timestamp = '2026-11-16T10:00:00.000Z';
        const sessionDir = path.join(agent, 'sessions', 'e2e'); await mkdir(sessionDir, { recursive: true });
        const entries: unknown[] = [{ type: 'session', version: 3, id: historyId, cwd, timestamp }, { type: 'session_info', id: 'name', parentId: null, timestamp, name: 'QUA02 history' }];
        for (let index = 0; index < 180; index++) entries.push({ type: 'message', id: `e${index}`, parentId: index ? `e${index - 1}` : 'name', timestamp, message: { role: index % 2 ? 'assistant' : 'user', content: historyText(index) } });
        await writeFile(path.join(sessionDir, 'history.jsonl'), entries.map(entry => JSON.stringify(entry)).join('\n') + '\n');
        child = spawn(process.execPath, ['/reference/node_modules/next/dist/bin/next', 'start', '-H', '127.0.0.1', '-p', '13041'], { cwd: '/reference', env: { ...process.env, HOME: path.join(root, 'home'), PI_CODING_AGENT_DIR: agent, PI_WEB_PASSWORD: '', PI_WEB_SKIP_VERSION_CHECK: '1', NEXT_TELEMETRY_DISABLED: '1', HISTFILE: '/dev/null' }, stdio: ['ignore', 'pipe', 'pipe'] });
        child.stdout!.on('data', chunk => { serverLog += chunk; }); child.stderr!.on('data', chunk => { serverLog += chunk; });
        base = 'http://127.0.0.1:13041';
        await expect.poll(async () => {
          if (child!.exitCode !== null || child!.signalCode !== null) throw new Error(`Reference server terminated: ${child!.exitCode}/${child!.signalCode}`);
          return fetch(`${base}/api/sessions`).then(response => response.status).catch(() => 0);
        }, { timeout: 120_000 }).toBe(200);
        const created = await page.request.post(`${base}/api/agent/new`, { data: { cwd, type: 'ensure_session', provider: 'qua02', modelId: 'qua02-fixture', thinkingLevel: 'off', toolNames: [] } });
        expect(created.status(), await created.text()).toBe(200); liveId = (await created.json()).sessionId;
      }
      await page.setViewportSize(viewport);
      await page.addInitScript(({ app, theme }) => {
        if (app === 'native') { localStorage.setItem('ai-harness-locale', 'en'); if (!localStorage.getItem('ai-harness-preferences-v4')) localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({ version: 4, theme })); }
        else { localStorage.setItem('pi-locale', 'en'); if (!localStorage.getItem('pi-theme')) localStorage.setItem('pi-theme', theme); }
      }, { app, theme });
      page.on('pageerror', error => browserErrors.push(error.message));
      page.on('console', message => { if (message.type() === 'error') events.push({ consoleError: message.text() }); });
      page.on('response', response => {
        const url = new URL(response.url()); if (url.origin !== base || !url.pathname.startsWith('/api/')) return;
        events.push({ method: response.request().method(), path: url.pathname + url.search, status: response.status() });
        if (response.status() === 429 || response.status() >= 500) httpErrors.push(`${response.status()} ${url.pathname}`);
      });
      const sessionUrl = (id: string) => app === 'native' ? `${base}/chat/${id}?cwd=${encodeURIComponent(cwd)}` : `${base}/?session=${id}`;
      const input = page.locator(app === 'native' ? '.input-container textarea' : '.chat-input-textarea');
      stage = 'live'; await page.goto(sessionUrl(liveId)); await expect(input).toBeVisible(); await input.fill(prompt);
      await page.getByRole('button', { name: 'Send', exact: true }).click();
      const reply = app === 'native' ? page.locator('.message.assistant').last() : page.locator('[data-message-role="assistant"]').last();
      await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.', { timeout: 15_000 });
      if (app === 'piweb') {
        const persistedId = new URL(page.url()).searchParams.get('session'); expect(persistedId).toBeTruthy();
        events.push({ initialEmptySessionId: liveId, persistedSessionId: persistedId }); liveId = persistedId!;
      }
      await page.reload(); await expect(reply).toContainText(app === 'native' ? '[Mock AI Response]' : 'QUA02 synthetic reply.');
      expect(page.url()).toContain(liveId);
      const persisted = await page.request.get(`${base}/api/sessions/${liveId}`); expect(persisted.status()).toBe(200);
      const snapshot = await persisted.json(), messages = app === 'native' ? snapshot.messages : snapshot.context.messages;
      expect(messages.filter((message: any) => message.role === 'user' && (typeof message.content === 'string' ? message.content === prompt : message.content.some((block: any) => block.text === prompt)))).toHaveLength(1);
      expect(messages.filter((message: any) => message.role === 'assistant')).toHaveLength(1);
      events.push({ persistedMessageRoles: messages.map((message: any) => message.role) });
      await capture('conversation');
      stage = 'history'; await sidebar();
      if (app === 'native') await page.locator('.sidebar-nav a.session-main').filter({ hasText: 'QUA02 history' }).click();
      else {
        const sessions = page.getByRole('tab', { name: 'Sessions', exact: true }); if (await sessions.isVisible() && await sessions.getAttribute('aria-selected') !== 'true') await sessions.click();
        await page.locator('.session-tree-session').filter({ has: page.locator('.session-tree-title', { hasText: /^QUA02 history$/ }) }).locator('.session-tree-main').click();
      }
      await expect(page.getByText(historyText(179), { exact: true })).toBeVisible();
      const earlier = page.getByText(app === 'native' ? 'Load earlier messages' : 'Scroll up to load earlier messages', { exact: true });
      if (app === 'native') { await earlier.scrollIntoViewIfNeeded(); await earlier.click(); }
      else await earlier.evaluate(element => element.scrollIntoView({ block: 'start', behavior: 'instant' }));
      if (app === 'native') { await page.getByRole('log').hover(); await page.mouse.wheel(0, -800); }
      const older = page.getByText(historyText(90), { exact: true }); await expect(older).toBeAttached(); await older.scrollIntoViewIfNeeded(); await expect(older).toBeVisible();
      const rendered = await page.getByText(/^History row \d+:/).allTextContents();
      const indices = rendered.map(value => Number(value.match(/^History row (\d+):/)![1]));
      expect(indices.length).toBeGreaterThan(0); expect(new Set(indices).size).toBe(indices.length);
      expect(indices.every((value, index) => index === 0 || value === indices[index - 1] + 1)).toBe(true);
      events.push({ renderedHistoryIndices: indices });
      await capture('history'); await page.reload();
      await expect(page.getByText(historyText(app === 'native' ? 90 : 179), { exact: true })).toBeVisible();
      expect(page.url()).toContain(historyId);
      stage = 'settings';
      if (app === 'native') {
        await page.goto(`${base}/settings#appearance`);
        const control = page.locator('#appearance').getByLabel(/^Theme/); await control.selectOption(theme === 'light' ? 'dark' : 'light'); await control.selectOption(theme);
        await page.reload(); await expect(control).toHaveValue(theme); await control.scrollIntoViewIfNeeded();
      } else {
        await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
        const radio = (value: string) => page.getByRole('radio', { name: value === 'light' ? 'Light' : 'Dark', exact: true });
        await radio(theme === 'light' ? 'dark' : 'light').locator('..').click(); await radio(theme).locator('..').click();
        await page.keyboard.press('Escape'); await page.reload(); await sidebar(); await page.getByRole('button', { name: 'Settings', exact: true }).click();
        await expect(radio(theme)).toBeChecked();
      }
      expect(await page.locator('html').getAttribute('data-theme')).toBe(theme); await capture('settings');
      stage = 'workspace'; await page.goto(sessionUrl(historyId));
      if (app === 'native') {
        await page.evaluate(() => window.dispatchEvent(new Event('aih-show-files')));
        const explorer = page.getByRole('complementary', { name: 'Workspace explorer', exact: true });
        await explorer.getByRole('button', { name: /^📄 note\.md(?:\s|$)/ }).click();
        await expect(page.locator('.file-viewer')).toContainText('Synthetic file boundary.');
        await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
      } else {
        await refFiles(); await page.getByText('note.md', { exact: true }).click();
        await expect(page.locator('#file-panel')).toContainText('Synthetic file boundary.');
        await page.locator('#file-panel').getByRole('button', { name: 'Hide file panel', exact: true }).click();
        await refFiles(); await page.getByRole('button', { name: 'Open workspace terminal', exact: true }).click();
      }
      const terminal = page.locator(app === 'native' ? '.terminal-panel' : '.terminal-panel:visible');
      const terminalInput = terminal.locator('.xterm-helper-textarea'); await terminalInput.focus();
      await terminalInput.type("printf 'QUA02_'\"PTY_OK\\n\""); await terminalInput.press('Enter');
      await expect(terminal.locator('.xterm-rows')).toContainText('QUA02_PTY_OK', { timeout: 10_000 });
      await capture('workspace');
      expect(browserErrors).toEqual([]); expect(httpErrors).toEqual([]);
      if (app === 'piweb') expect(providerRequests.filter((call: any) => call.path === '/v1/chat/completions')).toHaveLength(1);
      stage = 'complete';
    } catch (error) {
      await capture('failure').catch(() => undefined); throw error;
    } finally {
      await info.attach('outcomes', { body: JSON.stringify({ app, viewport, theme, stage, base, cwd, historyId, liveId, browserErrors, httpErrors, providerRequests, events }, null, 2), contentType: 'application/json' });
      if (serverLog) await info.attach('reference-server', { body: serverLog, contentType: 'text/plain' });
      await page.goto('about:blank').catch(() => undefined);
      if (nativeStarted) await stop();
      if (child && child.exitCode === null && child.signalCode === null) {
        const exit = once(child, 'exit'); child.kill('SIGTERM'); const timer = setTimeout(() => child!.kill('SIGKILL'), 10_000); await exit; clearTimeout(timer);
      }
      if (model) { model.closeAllConnections(); await new Promise<void>(resolve => model!.close(() => resolve())); }
      for (const [index, name] of names.entries()) { if (previous[index] === undefined) delete process.env[name]; else process.env[name] = previous[index]; }
    }
  });
}
