import { AiProvider } from "file:///tmp/aih-installed-cli-XYWfm7/consumer/node_modules/@ai-harness/core/dist/index.js";
    import { appendFileSync } from 'node:fs';
    class PickProvider extends AiProvider {
      constructor(config, name) { super(config); this.name = name; }
      validateConfig() { return Boolean(this.config.apiKey); }
      async chat() { throw new Error('Unexpected nonstreaming request'); }
      async streamChat(_messages, chunk, complete, _error, options) {
        appendFileSync('/tmp/mod02-runtime-diagnostic/steps.jsonl', JSON.stringify({actor:'extension',pid:process.pid,step:'provider:entered'})+'\n', {mode:0o600});
        appendFileSync("/tmp/aih-installed-cli-XYWfm7/aih-model-resolution-jY1UWa/calls", JSON.stringify({provider:this.name, model:options.model, thinking:options.thinking})+'\n');
        await chunk('Answer '+this.name); complete?.({content:'Answer '+this.name, model:options.model});
      }
    }
    export default api => { appendFileSync('/tmp/mod02-runtime-diagnostic/steps.jsonl', JSON.stringify({actor:'extension',pid:process.pid,step:'registration:entered'})+'\n', {mode:0o600}); for (const name of ['pick-alpha','pick-beta']) api.registerProvider(name, {
      defaultConfig: { model:"shared-reason-model:high" }, create:config=>new PickProvider(config,name)
    }); };