import { readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import path from 'node:path';

// Disposable diagnostic overlays only; never edit checkout runtime or emitted files.
const root = 'test-results/mod02-runtime-diagnostic';
const capture = '/tmp/mod02-runtime-diagnostic';
const hashes = [];
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
function replace(source, old, replacement) {
  if (source.split(old).length !== 2) throw new Error(`Non-unique diagnostic anchor: ${old}`);
  return source.replace(old, replacement);
}
function overlay(file, actor, anchor, changes) {
  const original = readFileSync(file, 'utf8');
  const typed = file.endsWith('.ts');
  const helper = `import { appendFileSync as mod02Append } from 'node:fs';\nfunction mod02Step(step${typed ? ': string' : ''})${typed ? ': void' : ''} {\n  mod02Append('${capture}/steps.jsonl', JSON.stringify({ actor: '${actor}', pid: process.pid, step }) + '\\n', { mode: 0o600 });\n}\n`;
  let observed = replace(original, anchor, helper + anchor);
  for (const [old, replacement] of changes) observed = replace(observed, old, replacement);
  const target = path.join(root, 'overlay', file);
  mkdirSync(path.dirname(target), { recursive: true });
  writeFileSync(target, observed, { mode: statSync(file).mode & 0o777 });
  hashes.push({ path: file, originalSha256: sha256(original), observedSha256: sha256(observed), mode: (statSync(file).mode & 0o777).toString(8) });
}

overlay('packages/cli/src/index.ts', 'cli-entry', 'const outputCredentialRedactor = new CredentialRedactor();', [
  ['const outputCredentialRedactor = new CredentialRedactor();', `mod02Step('module:evaluated');\nmod02Append('${capture}/application-runtime.jsonl', JSON.stringify({ version: process.version, execArgv: process.execArgv, nodeOptionsPresent: process.env.NODE_OPTIONS !== undefined }) + '\\n', { mode: 0o600 });\nconst outputCredentialRedactor = new CredentialRedactor();`],
  ['async function main(): Promise<void> {', "async function main(): Promise<void> {\n  mod02Step('main:entered');"],
  ["  if (applicationMode === 'rpc') {", "  if (applicationMode === 'rpc') {\n    mod02Step('rpc:dispatch');"],
  ['      const interrupted = await runRpcMode(rpcStartupOptions);', "      mod02Step('rpc:before-run');\n      const interrupted = await runRpcMode(rpcStartupOptions);\n      mod02Step('rpc:after-run');"],
  ['      await cleanupCliEarlyExit({ closeNetwork: closeProviderNetworkDispatchers, requireSettlement: true });', "      mod02Step('cleanup:before');\n      await cleanupCliEarlyExit({ closeNetwork: closeProviderNetworkDispatchers, requireSettlement: true });\n      mod02Step('cleanup:after');"],
  ['main().catch(error => {', "main().catch(error => {\n  mod02Step('main:rejected');"],
]);

overlay('packages/cli/src/rpc/rpc-server.ts', 'rpc-server', 'const MAX_PENDING_RPC_REQUESTS = 256;', [
  ["export async function runRpcMode(options: RpcStartupOptions = {}): Promise<'SIGINT' | 'SIGTERM' | undefined> {", "export async function runRpcMode(options: RpcStartupOptions = {}): Promise<'SIGINT' | 'SIGTERM' | undefined> {\n  mod02Step('run:entered');"],
  ['    await workspaceManager.initialize();', "    mod02Step('workspace:before');\n    await workspaceManager.initialize();\n    mod02Step('workspace:after');"],
  ['    let contextSettings = settingsResolution.settings;', "    mod02Step('settings:resolved');\n    let contextSettings = settingsResolution.settings;"],
  ['    const resourceLoadResult = await resourceManager.loadAll();', "    mod02Step('resources:before');\n    const resourceLoadResult = await resourceManager.loadAll();\n    mod02Step('resources:after');"],
  ['      const extensionLoadResult = await extensionLoader.loadAll();', "      mod02Step('extensions:before');\n      const extensionLoadResult = await extensionLoader.loadAll();\n      mod02Step('extensions:after');"],
  ['    const providerRuntime = await createCliProviderRuntime(', "    mod02Step('credentials:before');\n    const providerRuntime = await createCliProviderRuntime("],
  ['    const providers = createConfiguredProviders(process.env, {', "    mod02Step('credentials:after');\n    mod02Step('providers:before');\n    const providers = createConfiguredProviders(process.env, {"],
  ['    extensionRegistry.addVirtualProviders(providers);', "    extensionRegistry.addVirtualProviders(providers);\n    mod02Step('providers:after');"],
  ['    const startup = await resolveStartupProvider(providers, { ...effectiveModels.selection, offline }, process.env, extensionRegistry.virtualModels);', "    mod02Step('selection:before');\n    const startup = await resolveStartupProvider(providers, { ...effectiveModels.selection, offline }, process.env, extensionRegistry.virtualModels);\n    mod02Step('selection:after');"],
  ['    await controller.initialize();', "    mod02Step('controller:before-initialize');\n    await controller.initialize();\n    mod02Step('controller:after-initialize');"],
  ['        const response = await controller!.handle(parsed);', "        mod02Step('request:before-handle');\n        const response = await controller!.handle(parsed);\n        mod02Step('request:after-handle');"],
  ['    await controller.drain();', "    mod02Step('input:eof');\n    await controller.drain();\n    mod02Step('controller:drained');"],
  ['  try { await controller?.close(); }', "  mod02Step('controller:before-close');\n  try { await controller?.close(); }"],
  ['  try { await mcpHost?.shutdown(); }', "  mod02Step('controller:after-close');\n  try { await mcpHost?.shutdown(); }"],
  ['  return interrupted;', "  mod02Step('run:return');\n  return interrupted;"],
]);

overlay('packages/cli/src/rpc/rpc-controller.ts', 'rpc-controller', 'const FOREGROUND_SAFE_COMMANDS = new Set([', [
  ['  async initialize(): Promise<void> {', "  async initialize(): Promise<void> {\n    mod02Step('initialize:entered');"],
  ['          const prompt = await this.preparePrompt(message, request.images, signal!);\n          this.assertNoContextReload(command);\n          if (this.activeRun && !this.runAccepting)', "          mod02Step('prompt:before-prepare');\n          const prompt = await this.preparePrompt(message, request.images, signal!);\n          mod02Step('prompt:after-prepare');\n          this.assertNoContextReload(command);\n          if (this.activeRun && !this.runAccepting)"],
  ['          this.start(prompt, this.promptAdmission!.controller);', "          mod02Step('prompt:before-start');\n          this.start(prompt, this.promptAdmission!.controller);\n          mod02Step('prompt:after-start');"],
  ['                return await streamProviderTurn({', "                mod02Step('provider:before-turn');\n                return await streamProviderTurn({"],
]);

overlay('packages/cli/src/cli/fixtures/model-resolution-probe.mjs', 'probe', 'const [mode, scenario] = process.argv.slice(2);', [
  ['const [mode, scenario] = process.argv.slice(2);', "mod02Step('probe:entered');\nconst [mode, scenario] = process.argv.slice(2);"],
  ["      async streamChat(_messages, chunk, complete, _error, options) {", `      async streamChat(_messages, chunk, complete, _error, options) {\n        appendFileSync('${capture}/steps.jsonl', JSON.stringify({actor:'extension',pid:process.pid,step:'provider:entered'})+'\\\\n', {mode:0o600});`],
  ["    export default api => { for (const name of ['pick-alpha','pick-beta']) api.registerProvider(name, {", `    export default api => { appendFileSync('${capture}/steps.jsonl', JSON.stringify({actor:'extension',pid:process.pid,step:'registration:entered'})+'\\\\n', {mode:0o600}); for (const name of ['pick-alpha','pick-beta']) api.registerProvider(name, {`],
  ["  const reference = scenario === 'qualified'", `  await writeFile('${capture}/generated-provider.mjs', await readFile(extension));\n  mod02Step('extension:prepared');\n  const reference = scenario === 'qualified'`],
  ["  let stdout='',stderr='',buffer='',protocolError,turn=0;", "  child.once('spawn', () => mod02Step('cli:spawned'));\n  let stdout='',stderr='',buffer='',protocolError,turn=0;"],
  ["  assert.equal(exit.signal,null,JSON.stringify({exit,stdout,stderr}));assert.equal(protocolError,undefined);", `  mod02Step('cli:closed');\n  const callsSnapshot = await readFile(calls, 'utf8').catch(error => { if (error.code === 'ENOENT') return ''; throw error; });\n  await writeFile('${capture}/probe-observation.json', JSON.stringify({exit,stdout,stderr,childPid:child.pid,protocolRecordCount:records.length,providerCallsText:callsSnapshot},null,2)+'\\n');\n  assert.equal(exit.signal,null,JSON.stringify({exit,stdout,stderr}));assert.equal(protocolError,undefined);`],
]);

overlay('tests/functional-parity/installed-executable.test.ts', 'installed-harness', 'const checkout = fileURLToPath(', [
  ['beforeAll(async () => {', "beforeAll(async () => {\n  mod02Step('setup:entered');"],
  ["    await writeFile(path.join(evidence, 'inventory.json'),", `    for (const packed of inventory) await cp(path.join(artifactRoot, packed.filename), path.join(evidence, packed.filename));\n    for (const entry of ['index.js', 'rpc/rpc-server.js', 'rpc/rpc-controller.js']) {\n      await mkdir(path.dirname(path.join(evidence, 'installed-cli', entry)), {recursive:true});\n      await cp(path.join(consumer, 'node_modules/@ai-harness/cli/dist', entry), path.join(evidence, 'installed-cli', entry));\n    }\n    mod02Step('setup:complete');\n    await writeFile(path.join(evidence, 'inventory.json'),`],
  ["      expect(await run(process.execPath, [worker, mode, scenario], consumer, { ...environment, AIH_MODEL_RESOLUTION_COMMAND: 'ai-harness' }))\n        .toEqual({ code: 0, stdout: 'model resolution OK\\n', stderr: '' });", "      mod02Step('case:before-worker');\n      const result = await run(process.execPath, [worker, mode, scenario], consumer, { ...environment, AIH_MODEL_RESOLUTION_COMMAND: 'ai-harness' });\n      mod02Step('case:after-worker');\n      expect(result).toEqual({ code: 0, stdout: 'model resolution OK\\n', stderr: '' });"],
]);

const files = execFileSync('git', ['ls-files', '-z'], { encoding: 'utf8' }).split('\0').filter(Boolean).map(file => ({ path: file, sha256: sha256(readFileSync(file)), mode: (statSync(file).mode & 0o777).toString(8) }));
writeFileSync(path.join(root, 'preparation.json'), JSON.stringify({ head: execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim(), baseImage: 'sha256:023580878765ec88c214a0205167dfda65b770d6a5ac41a6254fc0c3a157b27f', overlays: hashes, trackedSnapshot: files, policy: 'One instrumented installed rpc/native case; no runtime flags, deadlines, assertions or public behavior changes. Compiler launcher remains unchanged. Observation perturbs source/import/timing and cannot qualify baseline or diagnose historical failures.' }, null, 2) + '\n');
console.log(`Prepared ${hashes.length} diagnostic source overlays; ${files.length} tracked paths frozen.`);
