# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tool-progress.spec.ts >> mobile-dark: genuine live phase, snapshot and durable terminal reload
- Location: e2e/tool-progress.spec.ts:260:3

# Error details

```
Error: expect(locator).toHaveScreenshot(expected) failed

Locator: getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true })
  2107 pixels (ratio 0.02 of all image pixels) are different.

  Snapshot: generic-progress-cancelled-mobile-dark.png

Call log:
  - Expect "toHaveScreenshot(generic-progress-cancelled-mobile-dark.png)" getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true }) with timeout 5000ms
    - verifying given screenshot expectation
  - waiting for getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true })
    - locator resolved to <section data-status="cancelled" class="generic-tool-progress" aria-label="Tool progress: arbitrary_custom">…</section>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - 2107 pixels (ratio 0.02 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - waiting for getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true })
    - locator resolved to <section data-status="cancelled" class="generic-tool-progress" aria-label="Tool progress: arbitrary_custom">…</section>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - captured a stable screenshot
  - 2107 pixels (ratio 0.02 of all image pixels) are different.

```

# Test source

```ts
  153 |       const content = mode === 'emptylength' ? '' : mode === 'length' ? 'Partial length answer.'
  154 |         : 'Partial visible output. disposable-generic-progress-test-key ' + 'safe tail '.repeat(20);
  155 |       res.end(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { content }, finish_reason: mode.endsWith('error') ? null : 'length' }] })}\n\n`
  156 |         + (mode.endsWith('error') ? 'data: INVALID_PROVIDER_JSON\n\n' : 'data: [DONE]\n\n'));
  157 |       return;
  158 |     }
  159 |     if (mode === 'parallel') {
  160 |       const delta = toolCount ? { content: 'Real progress probe complete' } : { tool_calls: ['one', 'two', 'parent'].map((part, index) => ({
  161 |         index, id: `parallel-${part}`, type: 'function', function: { name: part === 'parent' ? 'nested_parent' : 'parallel_read', arguments: JSON.stringify({ token, part }) },
  162 |       })) };
  163 |       res.writeHead(200, { 'Content-Type': 'text/event-stream' });
  164 |       res.end(`data: ${JSON.stringify({ choices: [{ delta, finish_reason: toolCount ? 'stop' : 'tool_calls' }] })}\n\ndata: [DONE]\n\n`); return;
  165 |     }
  166 |     const calls = mode === 'siblings' ? ['host-first', 'host-sibling'] : ['host-outer'];
  167 |     const delta = toolCount > 0 ? { content: 'Real progress probe complete' } : { tool_calls: calls.map((id, index) => ({
  168 |       index, id, type: 'function', function: mode === 'codemode'
  169 |         ? { name: 'codemode', arguments: JSON.stringify({ code: `text(await tools.arbitrary_custom(${JSON.stringify({ mode: 'success', token })}));` }) }
  170 |         : { name: 'arbitrary_custom', arguments: JSON.stringify({ mode: mode === 'siblings' && index === 1 ? 'clear' : mode, token }) },
  171 |     })) };
  172 |     res.writeHead(200, { 'Content-Type': 'text/event-stream' });
  173 |     res.end(`data: ${JSON.stringify({ choices: [{ index: 0, delta, finish_reason: null }] })}\n\ndata: [DONE]\n\n`);
  174 |   });
  175 |   await new Promise<void>(resolve => modelServer.listen(0, '127.0.0.1', resolve));
  176 |   modelPort = (modelServer.address() as { port: number }).port;
  177 |   const registered = await request.post('/api/provider-registry/custom', { data: {
  178 |     id: provider, name: 'Generic progress probe', dialect: 'openai-completions', baseUrl: `http://127.0.0.1:${modelPort}/v1`,
  179 |     apiKey: 'disposable-generic-progress-test-key',
  180 |   } });
  181 |   expect(registered.ok()).toBe(true);
  182 | });
  183 | test.afterAll(async ({ request }) => {
  184 |   await request.delete(`/api/provider-registry/custom/${provider}`);
  185 |   if (modelServer) await new Promise<void>(resolve => { modelServer.closeAllConnections(); modelServer.close(() => resolve()); });
  186 |   if (root) {
  187 |     await rm(root, { recursive: true, force: true });
  188 |     // Drop our generation, never modify another test's extension files.
  189 |     const defaultWorkspace = await (await request.get('/api/workspaces/default')).json() as { cwd: string };
  190 |     await request.post('/api/agent/reload', { data: { cwd: defaultWorkspace.cwd } });
  191 |   }
  192 | });
  193 | 
  194 | test.afterEach(async ({ page }, testInfo) => {
  195 |   const sessionId = probes.get(page);
  196 |   if (testInfo.status !== testInfo.expectedStatus && sessionId) {
  197 |     await testInfo.attach('actual-public-agent-state', {
  198 |       body: JSON.stringify(await state(page.request, sessionId), null, 2), contentType: 'application/json',
  199 |     });
  200 |   }
  201 | });
  202 | 
  203 | async function begin(page: Page, mode: string, seed?: string) {
  204 |   const token = `probe-${Date.now()}-${mode}`;
  205 |   const created = await page.request.post('/api/sessions', { data: { cwd: root, title: 'Generic tool progress' } });
  206 |   expect(created.status()).toBe(201);
  207 |   const session = await created.json() as { id: string };
  208 |   probes.set(page, session.id);
  209 |   // Meet the existing four-message compaction minimum before the overflow;
  210 |   // a length response must not be what makes the seeded history eligible.
  211 |   if (seed) for (const [role, content] of [['user', seed], ['assistant', 'Prior answer.'], ['user', 'Prior follow-up.'], ['assistant', 'Prior conclusion.']]) {
  212 |     const added = await page.request.post(`/api/sessions/${session.id}/messages`, { data: { role, content } }); expect(added.ok()).toBe(true);
  213 |   }
  214 |   await page.goto(`/chat/${session.id}?cwd=${encodeURIComponent(root)}`);
  215 |   await expect(page.getByRole('textbox', { name: 'Message composer', exact: true })).toBeVisible();
  216 |   await expect(page.locator('.generic-tool-progress')).toHaveCount(0);
  217 |   const started = await page.request.post('/api/agent/runs', { data: { sessionId: session.id, cwd: root,
  218 |     provider, model: 'progress-model', input: `${mode}:${token}`, toolPreset: 'full', autoCompaction: mode.startsWith('recover-'), maxRetries: 0 } });
  219 |   expect(started.status(), await started.text()).toBe(202);
  220 |   const { run } = await started.json() as { run: AgentRunSnapshot };
  221 |   return { sessionId: session.id, runId: run.id, token, gate: (name: string) => writeFile(path.join(root, `${token}-${name}`), 'go') };
  222 | }
  223 | async function state(request: APIRequestContext, sessionId: string) {
  224 |   return await (await request.get(`/api/agent/sessions/${sessionId}/state`)).json() as {
  225 |     run: AgentRunSnapshot; session: { messages: Message[]; messagePage?: { total: number } }; lastSequence: number;
  226 |   };
  227 | }
  228 | async function accessible(page: Page, card: Locator, width: number) {
  229 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
  230 |   const result = await new AxeBuilder({ page }).include('.generic-tool-progress').withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  231 |   expect(result.violations).toEqual([]);
  232 |   const summary = card.locator('summary');
  233 |   await summary.focus(); await expect(summary).toBeFocused();
  234 |   await page.keyboard.press('Enter');
  235 |   await expect(card.locator('details')).toHaveAttribute('open', '');
  236 |   expect(await page.evaluate(() => (window as unknown as { __progressExecuted?: number }).__progressExecuted)).toBeUndefined();
  237 |   await expect(card.locator('img, script, input, textarea, iframe')).toHaveCount(0);
  238 | }
  239 | async function positionCapture(card: Locator) {
  240 |   const page = card.page(), log = page.locator('.messages-container');
  241 |   // Retire saved-scroll settling with user intent, then use one complete origin.
  242 |   await log.hover({ position: { x: 5, y: 5 } });
  243 |   await page.mouse.wheel(0, 10_000);
  244 |   await log.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  245 |   await expect.poll(() => log.evaluate(element => Math.abs(element.scrollHeight - element.scrollTop - element.clientHeight))).toBeLessThan(1);
  246 |   await card.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
  247 |   await expect(card).toBeInViewport({ ratio: 1 });
  248 | }
  249 | async function capture(card: Locator, name: string) {
  250 |   // Assert real host duration separately; its wall-clock value is inherently variable.
  251 |   await expect(card.locator('small')).toContainText(/Host duration: \d+\.\d{2}s/);
  252 |   await positionCapture(card);
> 253 |   await expect(card).toHaveScreenshot(name, { animations: 'disabled', caret: 'hide', mask: [card.locator('small')] });
      |                      ^ Error: expect(locator).toHaveScreenshot(expected) failed
  254 | }
  255 | 
  256 | for (const scenario of [
  257 |   { name: 'desktop-light', width: 1440, theme: 'light' }, { name: 'desktop-dark', width: 1440, theme: 'dark' },
  258 |   { name: 'mobile-light', width: 390, theme: 'light' }, { name: 'mobile-dark', width: 390, theme: 'dark' },
  259 | ] as const) {
  260 |   test(`${scenario.name}: genuine live phase, snapshot and durable terminal reload`, async ({ page }) => {
  261 |     await page.setViewportSize({ width: scenario.width, height: 1000 });
  262 |     await page.addInitScript(theme => localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({
  263 |       version: 4, theme, sidebarVisible: false, filesOpen: false, sound: false,
  264 |     })), scenario.theme);
  265 |     const probe = await begin(page, 'success');
  266 |     const card = page.getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true });
  267 |     await expect(card).toContainText('Preparing custom work');
  268 |     const start = (await state(page.request, probe.sessionId)).run.activeTool!.progress!;
  269 |     expect(start).toMatchObject({ version: 1, toolCallId: 'host-outer', toolName: 'arbitrary_custom', status: 'running', sequence: 1 });
  270 |     await capture(card, `generic-progress-preparing-${scenario.name}.png`);
  271 |     const composer = page.getByRole('textbox', { name: 'Message composer', exact: true });
  272 |     await composer.focus();
  273 |     await probe.gate('latest');
  274 |     await expect(card).toContainText('**plain tool text**'); // actual live SSE update, not a fake fixture
  275 |     await expect(composer).toBeFocused(); // no automatic/native keyboard focus
  276 |     const latest = (await state(page.request, probe.sessionId)).run.activeTool!.progress!;
  277 |     expect(latest.sequence).toBe(3); expect(latest.durationMs).toBeGreaterThanOrEqual(start.durationMs);
  278 |     await accessible(page, card, scenario.width);
  279 |     await expect(card).toContainText('costUsd'); await expect(card).not.toContainText('$999');
  280 |     await capture(card, `generic-progress-running-${scenario.name}.png`);
  281 |     await page.reload(); // genuine current running snapshot restores the same public shape
  282 |     await expect(card).toContainText('**plain tool text**');
  283 |     expect((await state(page.request, probe.sessionId)).run.activeTool!.progress).toEqual(latest);
  284 |     await probe.gate('finish');
  285 |     await expect(card).toHaveAttribute('data-status', 'completed');
  286 |     await expect.poll(async () => (await state(page.request, probe.sessionId)).run.phase).toBe('completed');
  287 |     const completed = await state(page.request, probe.sessionId);
  288 |     expect(completed.run.activeTool).toBeUndefined();
  289 |     const results = completed.session.messages.filter(message => message.role === 'tool');
  290 |     expect(results).toHaveLength(1); expect(results[0]!.usage).toBeUndefined();
  291 |     const terminal = results[0]!.metadata!.toolProgress as ToolProgressSnapshot;
  292 |     expect(terminal).toMatchObject({ ...latest, status: 'completed', sequence: 4, durationMs: expect.any(Number) });
  293 |     expect(terminal.durationMs).toBeGreaterThanOrEqual(latest.durationMs);
  294 |     await page.reload();
  295 |     await expect(card).toHaveAttribute('data-status', 'completed');
  296 |     await expect(page.locator('.message.tool')).toHaveCount(1);
  297 |     await accessible(page, card, scenario.width);
  298 |     await capture(card, `generic-progress-terminal-${scenario.name}.png`);
  299 |     expect((await state(page.request, probe.sessionId)).session.messages.filter(message => message.role === 'tool')[0]!.metadata!.toolProgress).toEqual(terminal);
  300 | 
  301 |     const cancelled = await begin(page, 'stop');
  302 |     await expect(card).toContainText('Preparing custom work');
  303 |     await cancelled.gate('latest'); await expect(card).toContainText('plain tool text');
  304 |     await page.getByRole('button', { name: 'Stop tool', exact: true }).click();
  305 |     await expect.poll(async () => (await state(page.request, cancelled.sessionId)).run.phase).toBe('stopped');
  306 |     await page.reload(); await expect(card).toHaveAttribute('data-status', 'cancelled');
  307 |     await accessible(page, card, scenario.width);
  308 |     await capture(card, `generic-progress-cancelled-${scenario.name}.png`);
  309 | 
  310 |     const cleared = await begin(page, 'clear');
  311 |     await expect(card).toContainText('Preparing custom work');
  312 |     await cleared.gate('latest'); await expect(card).toContainText('plain tool text');
  313 |     await cleared.gate('finish');
  314 |     await expect(card).toHaveAttribute('data-status', 'completed');
  315 |     await page.reload(); await expect(card).toContainText('No progress text reported.');
  316 |     await expect(card.locator('details')).toHaveCount(0);
  317 |     expect((await state(page.request, cleared.sessionId)).session.messages.filter(message => message.role === 'tool')[0]!.metadata!.toolProgress)
  318 |       .toMatchObject({ content: '', details: null, status: 'completed' });
  319 |     await capture(card, `generic-progress-cleared-${scenario.name}.png`);
  320 |   });
  321 | }
  322 | 
  323 | test('stop durably cancels, ignores real late extension updates/results and reload never resurrects running activity', async ({ page }) => {
  324 |   const probe = await begin(page, 'stop');
  325 |   const card = page.getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true });
  326 |   await expect(card).toContainText('Preparing custom work');
  327 |   await probe.gate('latest'); await expect(card).toContainText('plain tool text');
  328 |   await page.getByRole('button', { name: 'Stop tool', exact: true }).click();
  329 |   await expect.poll(async () => (await state(page.request, probe.sessionId)).run.phase).toBe('stopped');
  330 |   expect(await readFile(path.join(root, `${probe.token}-late-attempted`), 'utf8')).toBe('yes');
  331 |   await expect(card).toHaveAttribute('data-status', 'cancelled');
  332 |   const stopped = await state(page.request, probe.sessionId);
  333 |   expect(stopped.run.activeTool).toBeUndefined();
  334 |   expect(stopped.session.messages.filter(message => message.role === 'tool')).toHaveLength(1);
  335 |   expect(JSON.stringify(stopped)).not.toMatch(/LATE UPDATE MUST NOT APPEAR|LATE RESULT MUST NOT APPEAR/);
  336 |   await page.reload(); await expect(card).toHaveAttribute('data-status', 'cancelled');
  337 |   await expect(page.locator('.message.tool')).toHaveCount(1);
  338 |   await expect(page.getByRole('button', { name: 'Stop tool', exact: true })).toHaveCount(0);
  339 | });
  340 | 
  341 | test('siblings keep host IDs independent, clear content/details are authoritative, and legacy tools load no progress card', async ({ page }) => {
  342 |   const probe = await begin(page, 'siblings');
  343 |   const card = page.getByRole('region', { name: 'Tool progress: arbitrary_custom', exact: true });
  344 |   await expect(card).toContainText('Preparing custom work');
  345 |   await probe.gate('latest'); await expect(card).toContainText('plain tool text');
  346 |   await probe.gate('finish');
  347 |   await expect.poll(async () => (await state(page.request, probe.sessionId)).run.phase).toBe('completed');
  348 |   await expect(card).toHaveCount(2);
  349 |   const results = (await state(page.request, probe.sessionId)).session.messages.filter(message => message.role === 'tool');
  350 |   expect(results.map(message => message.toolCallId)).toEqual(['host-first', 'host-sibling']);
  351 |   expect(results[1]!.metadata!.toolProgress).toMatchObject({ toolCallId: 'host-sibling', content: '', details: null });
  352 |   await page.reload(); await expect(card).toHaveCount(2);
  353 |   await expect(card.last()).toContainText('No progress text reported.');
```