# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mcp-selection.spec.ts >> MCP keeps one selected server detail across reload and restores the Settings section
- Location: e2e/mcp-selection.spec.ts:14:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#mcp').getByRole('region', { name: 'Server details: Global configuration / local-tools', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('#mcp').getByRole('region', { name: 'Server details: Global configuration / local-tools', exact: true }) with timeout 5000ms
  - waiting for locator('#mcp').getByRole('region', { name: 'Server details: Global configuration / local-tools', exact: true })

```

```yaml
- complementary "Main navigation":
  - heading "AiHarness" [level=1]
  - text: Language
  - combobox "Language":
    - option "English" [selected]
    - option "Français"
  - button "New chat": +
  - text: Workspace
  - button "workspace main"
  - link "Open project in a new tab":
    - /url: /?cwd=%2Fworkspace
    - text: ↗
  - button "Linked directories"
  - combobox "Git worktree":
    - option "main" [selected]
  - button "Create a worktree": +
  - searchbox "Search conversations"
  - button "Refresh files": ↻
  - group: Organise navigation
  - navigation "Conversations":
    - list
  - button "⚙ Settings"
- main:
  - region "Settings":
    - heading "Settings" [level=2]
    - status: Loading Settings translations…
    - link "Close":
      - /url: /
- complementary "Status messages"
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright';
  2   | import { expect, test, type Page } from './fixtures/test-budget.js';
  3   | import { installMockApi } from './fixtures/mock-api.js';
  4   | import { mcpStateInventory } from './fixtures/mcp.js';
  5   | import { switchMcpWorkspace } from './fixtures/mcp-navigation.js';
  6   | 
  7   | const key = 'ai-harness-mcp-selection-v1';
  8   | const scopeLabels = { global: 'Global configuration', project: 'Project configuration' };
  9   | const button = (page: Page, scope: keyof typeof scopeLabels, name: string) => page.locator('#mcp')
  10  |   .getByRole('button', { name: `Show details for ${scopeLabels[scope]} / ${name}`, exact: true });
  11  | const detail = (page: Page, scope: keyof typeof scopeLabels, name: string) => page.locator('#mcp')
  12  |   .getByRole('region', { name: `Server details: ${scopeLabels[scope]} / ${name}`, exact: true });
  13  | 
  14  | test('MCP keeps one selected server detail across reload and restores the Settings section', async ({ page }) => {
  15  |   const api = await installMockApi(page, { mcpConfig: mcpStateInventory() });
  16  |   await page.goto('/settings#mcp');
  17  |   const section = page.locator('#mcp');
  18  |   await expect(button(page, 'global', 'local-tools')).toBeVisible();
  19  |   await button(page, 'global', 'local-tools').click();
  20  |   const selected = detail(page, 'global', 'local-tools');
  21  |   await expect(selected).toBeVisible();
  22  |   await expect(selected).toContainText('env.CACHE_DIR reads host variables: CACHE_DIR');
  23  |   await expect(detail(page, 'global', 'remote-docs')).toHaveCount(0);
  24  |   await page.reload();
  25  |   await expect(selected).toBeVisible();
  26  |   await expect(button(page, 'global', 'local-tools')).toHaveAttribute('aria-expanded', 'true');
  27  |   await page.goto('/settings');
> 28  |   await expect(selected).toBeVisible();
      |                          ^ Error: expect(locator).toBeVisible() failed
  29  |   await expect(section.getByRole('heading', { name: 'MCP servers', exact: true })).toBeInViewport();
  30  |   expect(await page.evaluate(key => JSON.parse(localStorage.getItem(key)!), key)).toEqual({ version: 1, entries: [
  31  |     { cwd: '/workspace', scope: 'global', name: 'local-tools' },
  32  |   ] });
  33  |   expect(api.requests.filter(request => request.path === '/api/mcp/test' || request.path.startsWith('/api/mcp/oauth/flows'))).toEqual([]);
  34  | });
  35  | 
  36  | test('MCP distinguishes same-name scopes and invalidates a removed selected detail without falling into the other scope', async ({ page }) => {
  37  |   await installMockApi(page, { mcpConfig: mcpStateInventory() });
  38  |   await page.goto('/settings#mcp');
  39  |   const section = page.locator('#mcp');
  40  |   await button(page, 'project', 'shared').click();
  41  |   await expect(detail(page, 'project', 'shared')).toBeVisible();
  42  |   const next = mcpStateInventory();
  43  |   next.servers = next.servers.filter(server => server.scope !== 'project');
  44  |   await page.route(/\/api\/mcp(?:\?|$)/, route => route.fulfill({ json: next }));
  45  |   await section.getByRole('button', { name: 'Refresh', exact: true }).click();
  46  |   await expect(section.getByRole('status').filter({ hasText: 'The selected server is no longer available. Select another server.' })).toBeVisible();
  47  |   await expect(section.getByRole('region', { name: /^Server details:/ })).toHaveCount(0);
  48  |   await expect(button(page, 'global', 'shared')).toHaveAttribute('aria-expanded', 'false');
  49  | });
  50  | 
  51  | test('MCP opens explicit fresh rows with colliding escaped labels but never restores an ambiguous descriptor', async ({ page }) => {
  52  |   const inventory = mcpStateInventory();
  53  |   const invalid = inventory.servers.find(server => !server.valid)!;
  54  |   const valid = inventory.servers.find(server => server.name === 'remote-docs')!;
  55  |   inventory.servers = [
  56  |     { ...invalid, configKey: '3'.repeat(64) },
  57  |     { ...valid, name: invalid.name, configKey: '4'.repeat(64) },
  58  |   ];
  59  |   await installMockApi(page, { mcpConfig: inventory });
  60  |   await page.goto('/settings#mcp');
  61  |   const choices = button(page, 'global', invalid.name);
  62  |   await expect(choices).toHaveCount(2);
  63  |   await choices.nth(1).click();
  64  |   await expect(detail(page, 'global', invalid.name)).toContainText('https://docs.example.test/');
  65  |   expect(await page.evaluate(key => localStorage.getItem(key), key)).not.toContain('configKey');
  66  |   await page.reload();
  67  |   await expect(page.locator('#mcp')).toContainText('The selected server is no longer available. Select another server.');
  68  |   await expect(page.locator('#mcp').getByRole('region', { name: /^Server details:/ })).toHaveCount(0);
  69  |   await choices.nth(0).click();
  70  |   await expect(detail(page, 'global', invalid.name)).toContainText('The server name is empty, too long, or contains hidden characters.');
  71  |   await choices.nth(1).click();
  72  |   await expect(detail(page, 'global', invalid.name)).toContainText('https://docs.example.test/');
  73  | });
  74  | 
  75  | test('MCP works and restores a global selection without a project or implicit execution', async ({ page }) => {
  76  |   const inventory = mcpStateInventory();
  77  |   delete inventory.project;
  78  |   inventory.files = inventory.files.filter(file => file.scope === 'global');
  79  |   inventory.servers = inventory.servers.filter(server => server.scope === 'global');
  80  |   const api = await installMockApi(page, { mcpConfig: inventory });
  81  |   await page.route('**/api/workspaces/default', route => route.fulfill({ status: 404, json: { error: 'No default workspace.' } }));
  82  |   const reads: string[] = [];
  83  |   await page.route(/\/api\/mcp(?:\?|$)/, route => {
  84  |     reads.push(route.request().url());
  85  |     return route.fulfill({ json: inventory });
  86  |   });
  87  |   await page.goto('/settings#mcp');
  88  |   const section = page.locator('#mcp');
  89  |   await button(page, 'global', 'local-tools').click();
  90  |   await expect(section.locator('fieldset[data-scope="project"]')).toHaveCount(0);
  91  |   await page.reload();
  92  |   await expect(detail(page, 'global', 'local-tools')).toBeVisible();
  93  |   expect(reads.length).toBeGreaterThanOrEqual(2);
  94  |   expect(reads.every(url => !new URL(url).searchParams.has('cwd'))).toBe(true);
  95  |   expect(await page.evaluate(key => JSON.parse(localStorage.getItem(key)!), key)).toEqual({ version: 1, entries: [
  96  |     { cwd: null, scope: 'global', name: 'local-tools' },
  97  |   ] });
  98  |   expect(api.requests.filter(request => request.method === 'POST' && (request.path.startsWith('/api/mcp/') || request.path === '/api/agent/runs'))).toEqual([]);
  99  | });
  100 | 
  101 | test('MCP restores independent project selections through workspace navigation and a trust-locked inventory', async ({ page }) => {
  102 |   await installMockApi(page, { mcpConfig: mcpStateInventory() });
  103 |   await page.route(/\/api\/mcp(?:\?|$)/, route => {
  104 |     const inventory = mcpStateInventory();
  105 |     const cwd = new URL(route.request().url()).searchParams.get('cwd');
  106 |     if (cwd) {
  107 |       inventory.project!.cwd = cwd;
  108 |       for (const file of inventory.files) if (file.scope === 'project') file.path = `${cwd}/.ai-harness/mcp.json`;
  109 |       for (const server of inventory.servers) if (server.scope === 'project') server.sourcePath = `${cwd}/.ai-harness/mcp.json`;
  110 |     } else {
  111 |       delete inventory.project;
  112 |       inventory.files = inventory.files.filter(file => file.scope === 'global');
  113 |       inventory.servers = inventory.servers.filter(server => server.scope === 'global');
  114 |     }
  115 |     return route.fulfill({ json: inventory });
  116 |   });
  117 |   await page.goto('/settings?cwd=%2Fworkspace#mcp');
  118 |   const section = page.locator('#mcp');
  119 |   await button(page, 'project', 'shared').click();
  120 |   await switchMcpWorkspace(page, '/workspace/other');
  121 |   await button(page, 'global', 'local-tools').click();
  122 |   await switchMcpWorkspace(page, '/workspace');
  123 |   await expect(detail(page, 'project', 'shared')).toBeVisible();
  124 |   await switchMcpWorkspace(page, '/workspace/other');
  125 |   await expect(detail(page, 'global', 'local-tools')).toBeVisible();
  126 |   await button(page, 'project', 'shared').click();
  127 |   const locked = mcpStateInventory();
  128 |   locked.project = { cwd: '/workspace/other', contentTrusted: false, requiresTrust: true,
```