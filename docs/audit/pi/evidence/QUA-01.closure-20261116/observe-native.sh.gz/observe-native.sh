#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-authorized-worker-observation
docker create --name "$container" -e CI=true aih-qua01:native-ime-20261116 npm test -- packages/core/src/tools/codemode-intrinsics.test.ts --reporter=verbose || exit $?
docker cp "$base/authorized-review/codemode-intrinsics.test.ts" "$container:/app/packages/core/src/tools/codemode-intrinsics.test.ts" || exit $?
docker start --attach "$container"
status=$?
docker inspect "$container" > "$base/evidence/authorized-native-container.json"
exit "$status"
