#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-ime-production-smoke
docker create --name "$container" --network none aih-qua01:native-ime-prod-20261116 node /tmp/production-smoke.mjs || exit $?
docker cp "$base/evidence/production-smoke.mjs" "$container:/tmp/production-smoke.mjs" || exit $?
docker start --attach "$container"
status=$?
docker inspect "$container" > "$base/evidence/ime-integrated-smoke-container.json"
exit "$status"
