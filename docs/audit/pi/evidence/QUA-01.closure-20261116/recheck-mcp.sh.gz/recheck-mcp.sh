#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-authorized-mcp-recheck
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-ime-20261116 node .docker/run-e2e.mjs e2e/mcp-selection.spec.ts '--grep=keeps one selected server detail' --reporter=line,json || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/authorized-mcp-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/authorized-mcp-artifacts/"
docker inspect "$container" > "$base/evidence/authorized-mcp-container.json"
exit "$status"
