#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-authorized-openrouter-recheck
docker create --name "$container" -e CI=true aih-qua01:native-ime-20261116 npm test -- packages/core/src/providers/openrouter-completions.test.ts '--testNamePattern=for (nvidia/nemotron-3-super-120b-a12b|poolside/laguna-s-2\.1:free)$' --reporter=verbose || exit $?
docker start --attach "$container"
status=$?
docker inspect "$container" > "$base/evidence/authorized-openrouter-container.json"
exit "$status"
