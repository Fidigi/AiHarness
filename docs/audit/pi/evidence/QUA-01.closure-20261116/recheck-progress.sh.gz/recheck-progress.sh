#!/bin/bash
set -u
base=/tmp/aih-qua01-native-20261116
container=qua01-native-20261116-authorized-progress-recheck
docker create --name "$container" --shm-size=1g -e CI=true aih-qua01:native-ime-20261116 node .docker/run-e2e.mjs --config=e2e/tool-progress.config.ts '--grep=genuine live phase, snapshot and durable terminal reload' --reporter=line,json || exit $?
docker start --attach "$container"
status=$?
mkdir -p "$base/evidence/authorized-progress-artifacts"
docker cp "$container:/app/test-results/." "$base/evidence/authorized-progress-artifacts/"
docker inspect "$container" > "$base/evidence/authorized-progress-container.json"
exit "$status"
