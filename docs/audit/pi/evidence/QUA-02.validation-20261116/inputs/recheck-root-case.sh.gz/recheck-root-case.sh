#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
container=aih-qua02-root-case-20261116
printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\ncommand=npm test -- packages/core/src/providers/openrouter-completions.test.ts -t qwen/qwen3-vl-8b-instruct$\nreason=One unchanged exact-case non-reproduction control after the complete root result is reviewed; no instrumentation/retry/budget/flag change.\n' "$(date -u +%FT%TZ)" > "$base/results/root-case.command"
docker create --name "$container" -e CI=true aih-qua02:overlay-root-20261116 npm test -- packages/core/src/providers/openrouter-completions.test.ts -t 'qwen/qwen3-vl-8b-instruct$' > "$base/results/root-case.id"
docker start --attach "$container" > "$base/results/root-case.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/root-case.command"
printf '%s\n' "$code" > "$base/results/root-case.exit"
docker inspect "$container" > "$base/results/root-case-container.json"
exit "$code"
