#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
# Root exit2 and both exact-case passes were explicitly reviewed in root-disposition.json.
# Preserve that failed gate; this launches independent browser work, not another root.
test -f "$base/results/root-disposition.json" || exit 1
test "$(< "$base/results/root-case.exit")" = 0 && test "$(< "$base/results/cli-case.exit")" = 0 || exit 1
pids=()
for n in 1 2 3 4; do
  source="$base/partition-$n"
  mkdir -p "$source" "$base/results/partition-$n"
  tar -xf "$base/final-source.tar" -C "$source"
  (
    cd "$source"
    printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\ncommand=make test-e2e IMAGE_TEST=aih-qua02:overlay-partition-%s CONTAINER_PREFIX=aih-qua02-p%s E2E_ARGS="--ci-partition=%s/4 --reporter=line,json"\n' "$(date -u +%FT%TZ)" "$n" "$n" "$n" > "$base/results/partition-$n/command"
    make test-e2e IMAGE_TEST="aih-qua02:overlay-partition-$n" CONTAINER_PREFIX="aih-qua02-p$n" E2E_ARGS="--ci-partition=$n/4 --reporter=line,json" > "$base/results/partition-$n/run.log" 2>&1
    code=$?
    printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/partition-$n/command"
    printf '%s\n' "$code" > "$base/results/partition-$n/exit"
    cp -a test-results "$base/results/partition-$n/test-results"
    exit "$code"
  ) &
  pids+=("$!")
done
status=0
for pid in "${pids[@]}"; do wait "$pid" || status=1; done
printf '%s\n' "$status" > "$base/results/browser.exit"
exit "$status"
