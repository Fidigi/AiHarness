#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
out="$base/results/final-captures"
container=aih-qua02-final-overlay-network-fixed-20261116
image=aih-qua02:collector-overlay-20261116
mkdir -p "$out"
printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\ncommand=node .docker/run-e2e.mjs e2e/qua02-differential.spec.ts e2e/performance.spec.ts --reporter=line,json --trace=on --max-failures=1\nprotocol=final-protocol.md; native-sensitive performance/capture control serial, after all partitions stop.\n' "$(date -u +%FT%TZ)" > "$out/command"
docker image inspect "$image" > "$out/image.json"
docker network inspect aih-qua02-local-20261116 > "$out/network.json" || exit 1
docker create --name "$container" --network=aih-qua02-local-20261116 --shm-size=1g "$image" node .docker/run-e2e.mjs e2e/qua02-differential.spec.ts e2e/performance.spec.ts --reporter=line,json --trace=on --max-failures=1 > "$out/container-id"
docker start --attach "$container" > "$out/run.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$out/command"
printf '%s\n' "$code" > "$out/exit"
docker inspect "$container" > "$out/container.json"
docker cp "$container:/app/test-results" "$out/test-results"
docker cp "$container:/app/playwright-report" "$out/playwright-report"
# Retain exited owned container for exact bundle/source/environment readback before sealing.
exit "$code"
