#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
container=aih-qua02-cli-case-20261116
printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\ncommand=npm test -- packages/cli/src/cli/openrouter-process.test.ts -t rpc/native=true preserves anthropic-messages and explicit credential composition$\nreason=One unchanged exact-case non-reproduction control for the current emitted CLI child SIGTRAP, not a compiler waiver or repeated root.\n' "$(date -u +%FT%TZ)" > "$base/results/cli-case.command"
docker create --name "$container" -e CI=true aih-qua02:overlay-root-20261116 npm test -- packages/cli/src/cli/openrouter-process.test.ts -t 'rpc/native=true preserves anthropic-messages and explicit credential composition$' > "$base/results/cli-case.id"
docker start --attach "$container" > "$base/results/cli-case.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/cli-case.command"
printf '%s\n' "$code" > "$base/results/cli-case.exit"
docker inspect "$container" > "$base/results/cli-case-container.json"
exit "$code"
