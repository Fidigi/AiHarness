#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
mkdir -p "$base/root-source"
git -C /app/projects/AiHarness archive --format=tar 07bceeca6342d9add499cf10a521cce0649c7f0c -o "$base/final-source.tar"
sha256sum "$base/final-source.tar" > "$base/results/final-source.sha256"
tar -xf "$base/final-source.tar" -C "$base/root-source"
printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\ncommand=make test IMAGE_TEST_RUN=aih-qua02:overlay-root-20261116\n' "$(date -u +%FT%TZ)" > "$base/results/root.command"
cd "$base/root-source"
make test IMAGE_TEST_RUN=aih-qua02:overlay-root-20261116 > "$base/results/root.log" 2>&1
code=$?
printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$base/results/root.command"
printf '%s\n' "$code" > "$base/results/root.exit"
exit "$code"
