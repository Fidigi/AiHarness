import zipfile,json,hashlib,tarfile,sys,io
out=[]
archive=tarfile.open(fileobj=sys.stdin.buffer,mode='r|')
for member in archive:
 if not member.name.endswith('/trace.zip'): continue
 data=archive.extractfile(member).read()
 z=zipfile.ZipFile(io.BytesIO(data))
 rows=[json.loads(x) for name in z.namelist() if name.endswith('.trace') and name!='test.trace' for x in z.read(name).splitlines()]
 before=[r for r in rows if r.get('type')=='before']
 after={r['callId']:r for r in rows if r.get('type')=='after'}
 context=next(r for r in rows if r.get('type')=='context-options' and r.get('browserName')=='chromium')
 selected=[]
 for r in before:
  method=r.get('method')
  if method=='queryCount' or method=='reload' or method=='expect' and r['params'].get('selector')=='#long-message-101' or 'getBoundingClientRect' in r.get('params',{}).get('expression',''):
   selected.append({'before':r,'after':after.get(r['callId'])})
 result={'trace':member.name,'sha256':hashlib.sha256(data).hexdigest(),'context':context,'observations':selected}
 if any(r.get('method')=='reload' for r in before):
  reload=next(r for r in before if r.get('method')=='reload')
  visible=next(r for r in before if r.get('method')=='expect' and r['params'].get('selector')=='#long-message-101' and r['startTime']>reload['startTime'])
  result['reloadStartToVisibleAssertionEndMs']=round(after[visible['callId']]['endTime']-reload['startTime'],3)
 out.append(result)
print(json.dumps(out,indent=2))
