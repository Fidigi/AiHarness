import { readFileSync, readdirSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const root='/tmp/final-web-dist';
const html=readFileSync(`${root}/index.html`,'utf8');
const entry=html.match(/<script[^>]+src="\/assets\/([^"?]+\.js)"/)[1];
const files=readdirSync(`${root}/assets`).filter(x=>/\.(?:m?js|css)$/.test(x)).sort();
const assets=files.map(file=>{const b=readFileSync(`${root}/assets/${file}`);return {file,raw:b.length,gzip:gzipSync(b).length,sha256:createHash('sha256').update(b).digest('hex')};});
const eager=new Set([entry]);
for(const m of html.matchAll(/(?:src|href)="\/assets\/([^"?]+\.(?:js|css))"/g))eager.add(m[1]);
const pending=[entry];
while(pending.length){const file=pending.pop();const text=readFileSync(`${root}/assets/${file}`,'utf8');for(const m of text.matchAll(/(?:from\s*|import\s*)["']\.\/([^"']+\.js)["']/g)){if(!eager.has(m[1])){eager.add(m[1]);pending.push(m[1]);}}}
console.log(JSON.stringify({image:'sha256:a15bf787ea18b855bedd5c88c365ea503d5617a09fc989fcd511c81823c66879',entry:assets.find(x=>x.file===entry),eager:[...eager].sort(),eagerGzip:[...eager].reduce((a,x)=>a+assets.find(y=>y.file===x).gzip,0),assets},null,2));
