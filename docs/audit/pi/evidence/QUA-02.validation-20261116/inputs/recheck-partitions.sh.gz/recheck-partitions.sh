#!/bin/bash
set -u
base=/tmp/aih-qua02-repair-20261116
# Invoke manually only after reviewing completed original partitions1/4.
# One unchanged attempt per current compiler failure, serial and separate from all other controls.
for n in 1 4; do test -f "$base/results/partition-$n/exit" || exit 1; done
for n in 2 3; do
  source="$base/partition-$n-recheck"
  out="$base/results/partition-$n-recheck"
  mkdir -p "$source" "$out"
  tar -xf "$base/final-source.tar" -C "$source"
  cd "$source"
  printf 'start=%s\nsource=07bceeca6342d9add499cf10a521cce0649c7f0c\nreason=Single unmodified current compiler-preparation non-reproduction control plus first execution of this previously unrun browser partition; original preparation failure retained.\ncommand=make test-e2e IMAGE_TEST=aih-qua02:overlay-partition-%s-recheck CONTAINER_PREFIX=aih-qua02-p%sr E2E_ARGS="--ci-partition=%s/4 --reporter=line,json"\n' "$(date -u +%FT%TZ)" "$n" "$n" "$n" > "$out/command"
  make test-e2e IMAGE_TEST="aih-qua02:overlay-partition-$n-recheck" CONTAINER_PREFIX="aih-qua02-p${n}r" E2E_ARGS="--ci-partition=$n/4 --reporter=line,json" > "$out/run.log" 2>&1
  code=$?
  printf 'exit=%s\nend=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$out/command"
  printf '%s\n' "$code" > "$out/exit"
  cp -a test-results "$out/test-results"
  if test "$code" != 0; then echo "Partition$n current recheck failed: preserve results and stop before any further attempt or sibling control pending explicit classification."; exit "$code"; fi
done
