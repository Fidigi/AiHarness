# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-keyboard.spec.ts >> real product and disposable server >> integrated keyboard response does not require intercepted API fixtures
- Location: e2e/mobile-keyboard.spec.ts:287:3

# Error details

```
Error: expect(locator).toHaveScreenshot(expected) failed

Locator: locator('.mcp-import-panel')
  4664 pixels (ratio 0.04 of all image pixels) are different.

  Snapshot: keyboard-live-mcp-mobile-light.png

Call log:
  - Expect "toHaveScreenshot(keyboard-live-mcp-mobile-light.png)" locator('.mcp-import-panel') with timeout 5000ms
    - verifying given screenshot expectation
  - waiting for locator('.mcp-import-panel')
    - locator resolved to <details open="" class="mcp-import-panel">…</details>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - 4664 pixels (ratio 0.04 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - waiting for locator('.mcp-import-panel')
    - locator resolved to <details open="" class="mcp-import-panel">…</details>
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable
  - captured a stable screenshot
  - 4664 pixels (ratio 0.04 of all image pixels) are different.

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - button "Toggle navigation" [ref=e4]
  - complementary [aria-hidden] [ref=e6]:
    - generic [ref=e7]:
      - heading [level=1] [ref=e8]: AiHarness
      - generic [ref=e9]:
        - generic [ref=e10]:
          - generic [aria-hidden] [ref=e11]: 🌐
          - generic [ref=e12]: Language
          - combobox [ref=e13] [cursor=pointer]
        - button [ref=e14] [cursor=pointer]: +
    - generic [ref=e15]:
      - generic [ref=e16]: Workspace
      - generic [ref=e17]:
        - button [ref=e18] [cursor=pointer]:
          - generic [ref=e19]: app
          - generic [ref=e20]: /app
        - link [ref=e21] [cursor=pointer]:
          - /url: /?cwd=%2Fapp
          - text: ↗
        - button [ref=e22] [cursor=pointer]: ↗
      - button [ref=e23] [cursor=pointer]: Linked directories
    - generic [ref=e24]:
      - searchbox [ref=e25]
      - button [ref=e26] [cursor=pointer]: ↻
    - group [ref=e27]:
      - generic [ref=e28] [cursor=pointer]: Organise navigation
    - navigation [ref=e29]:
      - list [ref=e30]:
        - listitem [ref=e31]:
          - button [ref=e33] [cursor=pointer]:
            - generic [ref=e34]: Untitled
            - generic [ref=e35]: 0 · 1 second ago
    - button [ref=e37] [cursor=pointer]: ⚙ Settings
  - main [ref=e38]:
    - generic [ref=e39]:
      - heading "Settings" [level=2] [ref=e40]
      - generic [ref=e41]:
        - heading "Server authentication" [level=3] [ref=e42]
        - generic [ref=e43]:
          - textbox "Bearer token" [ref=e44]
          - button "Apply" [ref=e45] [cursor=pointer]
        - button "Sign out of the Web session" [ref=e46] [cursor=pointer]
      - generic [ref=e47]:
        - heading "AI Provider" [level=3] [ref=e48]
        - combobox "Select the AI Provider" [ref=e49] [cursor=pointer]:
          - option "OpenAI (GPT-4, GPT-3.5)"
          - option "Anthropic (Claude)"
          - option "Google AI (Gemini)"
          - option "Azure OpenAI"
          - option "Google Vertex AI (Gemini)"
          - option "AWS Bedrock (Claude)"
          - option "Local Model (Ollama, etc.)"
          - option "Mock (Testing Only)" [selected]
          - option "github-copilot"
          - option "openai-codex"
        - generic [ref=e50]:
          - generic [ref=e51]:
            - text: OpenAI
            - generic [ref=e52]:
              - textbox "API Key for OpenAI" [ref=e53]:
                - /placeholder: OPENAI_API_KEY (optional)
              - button "Save" [ref=e54] [cursor=pointer]
          - generic [ref=e55]:
            - text: Anthropic
            - generic [ref=e56]:
              - textbox "API Key for Anthropic" [ref=e57]:
                - /placeholder: ANTHROPIC_API_KEY (optional)
              - button "Save" [ref=e58] [cursor=pointer]
          - generic [ref=e59]:
            - text: Google AI
            - generic [ref=e60]:
              - textbox "API Key for Google AI" [ref=e61]:
                - /placeholder: GEMINI_API_KEY (optional)
              - button "Save" [ref=e62] [cursor=pointer]
          - generic [ref=e63]:
            - text: Azure OpenAI
            - generic [ref=e64]:
              - textbox "API Key for Azure OpenAI" [ref=e65]:
                - /placeholder: AZURE_OPENAI_API_KEY (optional)
              - button "Save" [ref=e66] [cursor=pointer]
          - generic [ref=e67]:
            - text: Google Vertex AI
            - combobox "Vertex credential type to save" [ref=e68] [cursor=pointer]:
              - option "Access token (legacy Bearer)" [selected]
              - option "Google Cloud API key"
            - generic [ref=e69]:
              - textbox "API Key for Google Vertex AI" [ref=e70]:
                - /placeholder: GOOGLE_VERTEX_ACCESS_TOKEN (optional)
              - button "Save" [ref=e71] [cursor=pointer]
          - generic [ref=e72]:
            - text: AWS Bedrock
            - generic [ref=e73]:
              - textbox "API Key for AWS Bedrock" [ref=e74]:
                - /placeholder: AWS_ACCESS_KEY_ID:AWS_SECRET_ACCESS_KEY (optional)
              - button "Save" [ref=e75] [cursor=pointer]
          - generic [ref=e76]:
            - text: Local Model
            - generic [ref=e77]:
              - textbox "API Key for Local Model" [ref=e78]:
                - /placeholder: API Key (optional)
              - button "Save" [ref=e79] [cursor=pointer]
          - generic [ref=e80]:
            - text: Mock (Testing)
            - generic [ref=e81]:
              - textbox "API Key for Mock (Testing)" [ref=e82]:
                - /placeholder: API Key (optional)
                - text: ••••••••
              - button "Save" [ref=e83] [cursor=pointer]
        - generic [ref=e84]: 🔧 Using Mock Provider (no API Key needed)
      - generic [ref=e85]:
        - heading "Provider connections and custom providers" [level=3] [ref=e86]
        - group [ref=e87]:
          - generic "Prompt cache" [ref=e88]
        - generic [ref=e89]:
          - article [ref=e90]:
            - generic [ref=e91]:
              - strong [ref=e92]: openai
              - code [ref=e93]: openai
            - generic [ref=e94]: disconnected · api-key
            - generic [ref=e95]:
              - button "Test connection" [disabled] [ref=e96] [cursor=pointer]
              - button "Disconnect" [ref=e97] [cursor=pointer]
          - article [ref=e98]:
            - generic [ref=e99]:
              - strong [ref=e100]: anthropic
              - code [ref=e101]: anthropic
            - generic [ref=e102]: disconnected · api-key
            - generic [ref=e103]:
              - button "Test connection" [disabled] [ref=e104] [cursor=pointer]
              - button "Disconnect" [ref=e105] [cursor=pointer]
          - article [ref=e106]:
            - generic [ref=e107]:
              - strong [ref=e108]: google
              - code [ref=e109]: google
            - generic [ref=e110]: disconnected · api-key
            - generic [ref=e111]:
              - button "Test connection" [disabled] [ref=e112] [cursor=pointer]
              - button "Disconnect" [ref=e113] [cursor=pointer]
          - article [ref=e114]:
            - generic [ref=e115]:
              - strong [ref=e116]: azure
              - code [ref=e117]: azure
            - generic [ref=e118]: disconnected · api-key
            - generic [ref=e119]:
              - button "Test connection" [disabled] [ref=e120] [cursor=pointer]
              - button "Disconnect" [ref=e121] [cursor=pointer]
          - article [ref=e122]:
            - generic [ref=e123]:
              - strong [ref=e124]: vertex
              - code [ref=e125]: vertex
            - generic [ref=e126]: disconnected · api-key
            - generic [ref=e127]:
              - button "Test connection" [disabled] [ref=e128] [cursor=pointer]
              - button "Disconnect" [ref=e129] [cursor=pointer]
          - article [ref=e130]:
            - generic [ref=e131]:
              - strong [ref=e132]: bedrock
              - code [ref=e133]: bedrock
            - generic [ref=e134]: disconnected · api-key
            - generic [ref=e135]:
              - button "Test connection" [disabled] [ref=e136] [cursor=pointer]
              - button "Disconnect" [ref=e137] [cursor=pointer]
          - article [ref=e138]:
            - generic [ref=e139]:
              - strong [ref=e140]: local
              - code [ref=e141]: local
            - generic [ref=e142]: disconnected · none
            - generic [ref=e143]:
              - button "Test connection" [disabled] [ref=e144] [cursor=pointer]
              - button "Disconnect" [ref=e145] [cursor=pointer]
          - article [ref=e146]:
            - generic [ref=e147]:
              - strong [ref=e148]: github-copilot
              - code [ref=e149]: github-copilot
            - generic [ref=e150]: disconnected · oauth
            - generic [ref=e151]:
              - button "Connect" [ref=e152] [cursor=pointer]
              - button "Test connection" [disabled] [ref=e153] [cursor=pointer]
              - button "Disconnect" [ref=e154] [cursor=pointer]
          - article [ref=e155]:
            - generic [ref=e156]:
              - strong [ref=e157]: openai-codex
              - code [ref=e158]: openai-codex
            - generic [ref=e159]: disconnected · oauth
            - generic [ref=e160]:
              - button "Connect" [ref=e161] [cursor=pointer]
              - button "Browser sign-in (PKCE)" [ref=e162] [cursor=pointer]
              - button "Test connection" [disabled] [ref=e163] [cursor=pointer]
              - button "Disconnect" [ref=e164] [cursor=pointer]
          - article [ref=e165]:
            - generic [ref=e166]:
              - strong [ref=e167]: mock
              - code [ref=e168]: mock
            - generic [ref=e169]: connected · none
            - button "Test connection" [ref=e171] [cursor=pointer]
        - group [ref=e172]:
          - generic "Create or edit a compatible provider" [ref=e173] [cursor=pointer]
          - option "OpenAI Chat Completions" [selected]
          - option "OpenAI Responses"
          - option "OpenAI mixed Responses / Decisions"
          - option "Mistral Chat / Conversations"
          - option "OpenRouter mixed A/C/I/T"
          - option "Cloudflare Workers AI mixed C/S"
          - option "Cerebras Chat Completions"
          - option "DeepSeek Chat Completions"
          - option "Groq Chat Completions"
          - option "Z.ai Coding Chat Completions"
          - option "Moonshot Chat Completions"
          - option "NVIDIA Chat Completions"
          - option "Ant Ling Chat Completions"
          - option "Baseten Chat Completions"
          - option "Fireworks Messages / Chat Completions"
          - option "Hugging Face Chat Completions"
          - option "Kimi Coding Messages (API key)"
          - option "Meta Responses (API key or Muse)"
          - option "MiniMax Messages"
          - option "MiniMax CN Messages"
          - option "OpenCode Go Messages / Chat / Responses"
          - option "OpenCode Zen Messages / Google / Chat / Responses"
          - option "Together Chat Completions"
          - option "xAI Responses (API key or Grok/X)"
          - option "Xiaomi Chat Completions"
          - option "Moonshot CN Chat Completions"
          - option "Qwen Token Plan"
          - option "Qwen Token Plan CN"
          - option "Qwen Token Plan Individual"
          - option "Xiaomi Token Plan AMS"
          - option "Xiaomi Token Plan CN"
          - option "Xiaomi Token Plan SGP"
          - option "Z.ai Coding CN"
          - option "TypeSafe System One"
          - option "Radius Pi Messages (gateway URL)"
          - option "Cloudflare AI Gateway (gateway root URL)"
          - option "Vercel AI Gateway (gateway root URL)"
          - option "Anthropic Messages"
          - option "Google Generative Language"
      - generic [ref=e174]:
        - heading "Real-time transport" [level=3] [ref=e175]
        - combobox "Select the real-time transport" [ref=e176] [cursor=pointer]:
          - option "Server-Sent Events (SSE)" [selected]
          - option "WebSocket"
      - generic [ref=e177]:
        - heading "Model" [level=3] [ref=e178]
        - combobox "Select the model" [ref=e179] [cursor=pointer]:
          - option "Mock model" [selected]
          - option "Mock model v1"
        - group [ref=e180]:
          - generic "Manage model catalogue" [ref=e181] [cursor=pointer]
      - generic [ref=e182]:
        - heading "Provider and model defaults" [level=3] [ref=e183]
        - paragraph [ref=e184]: Project values override global defaults; active conversations keep their explicit overrides.
        - paragraph [ref=e185]: "Effective: mock / — · default · provider: built-in · model: built-in · thinking: built-in · thinkingBudgets: built-in · toolPreset: built-in"
        - paragraph [ref=e186]: Empty project values inherit the winning global, environment, or built-in source shown above.
        - generic [ref=e187]:
          - text: Scope
          - combobox "Scope" [ref=e188] [cursor=pointer]:
            - option "global"
            - option "workspace" [selected]
        - generic [ref=e189]:
          - text: Provider
          - textbox "Provider" [ref=e190]:
            - /placeholder: Auto · mock
        - generic [ref=e191]:
          - text: Model
          - textbox "Model" [ref=e192]:
            - /placeholder: Auto · —
        - generic [ref=e193]:
          - text: Thinking level
          - combobox "Thinking level" [ref=e194] [cursor=pointer]:
            - option "Auto · off" [selected]
            - option "off"
            - option "minimal"
            - option "low"
            - option "medium"
            - option "high"
            - option "xhigh"
            - option "max"
        - generic [ref=e195]:
          - text: Reasoning budgets (JSON)
          - textbox "Reasoning budgets (JSON)" [ref=e196]:
            - /placeholder: "{}"
        - paragraph [ref=e197]: "Optional minimal/low/medium/high token counts. Numeric dialects clamp these values; effort-only models ignore them. A higher scope replaces the whole map. Empty text inherits; {} uses provider defaults."
        - generic [ref=e198]:
          - text: Default tool preset
          - combobox "Default tool preset" [ref=e199] [cursor=pointer]:
            - option "Auto · default" [selected]
            - option "configured"
            - option "chat-only"
            - option "read-only"
            - option "default"
            - option "full"
        - button "Save" [disabled] [ref=e200] [cursor=pointer]
      - generic [ref=e201]:
        - heading "Custom models" [level=3] [ref=e202]
        - group [ref=e203]:
          - generic "Create a custom model" [ref=e204] [cursor=pointer]
      - generic [ref=e205]:
        - heading "Skills" [level=3] [ref=e206]
        - paragraph [ref=e207]: Review discovered skills and choose which trusted instructions the model may load autonomously. Instruction bodies remain on the server.
        - generic [ref=e208]:
          - generic [ref=e209]:
            - generic [ref=e210]: Filter skills or sources
            - searchbox "Filter skills or sources" [ref=e211]
          - button "Refresh skills" [ref=e213] [cursor=pointer]
        - paragraph [ref=e214]: "Model invocation scope: built-in default (skill metadata) · Updated 11/16/2026, 7:19:52 PM"
        - paragraph [ref=e215]: No skill matches this filter.
        - group [ref=e216]:
          - generic "Browse Agent Skills registry" [ref=e217] [cursor=pointer]
          - option "Project" [selected]
          - option "Global"
        - paragraph [ref=e219]: Only changed displayed rows are saved. Hidden rows and other groups are preserved.
      - generic [ref=e220]:
        - heading "Tools and presets" [level=3] [ref=e221]
        - generic [ref=e222]:
          - text: Scope
          - combobox "Scope" [ref=e223] [cursor=pointer]:
            - option "global"
            - option "workspace" [selected]
        - paragraph [ref=e224]: default scope · built-in
        - generic [ref=e225]:
          - text: Default tool preset
          - combobox "Default tool preset" [ref=e226] [cursor=pointer]:
            - option "configured"
            - option "chat-only"
            - option "read-only"
            - option "default" [selected]
            - option "full"
        - group "Code mode sandbox" [ref=e227]:
          - status [ref=e229]: QuickJS · Sandbox self-test passed
          - generic [ref=e230]:
            - text: Code mode activation
            - combobox "Code mode activation" [ref=e231] [cursor=pointer]:
              - option "Automatic (eligible indirect tools)" [selected]
              - option "Always on"
          - generic [ref=e232]:
            - text: Tool presentation
            - combobox "Tool presentation" [ref=e233] [cursor=pointer]:
              - option "on" [selected]
              - option "only"
          - generic [ref=e234]:
            - text: Inline declaration budget (estimated tokens)
            - spinbutton "Inline declaration budget (estimated tokens)" [ref=e235]: "3000"
          - paragraph [ref=e236]: 10 s · 32 MiB VM · 64 calls · 4 concurrent · 64 KiB output. No Node, network, filesystem or timers in scripts.
          - paragraph [ref=e237]: Nested tools retain their real privileges and current read-only policy. Discovery is not authorization. Calls made before failure are not undone. Classifier/image helpers use only the current provider and its available models; image data shares the bounded result budget.
        - generic [ref=e238]:
          - generic [ref=e239]:
            - checkbox "read Read a text file. Output is truncated to 2000 lines or 50.0 KiB. Use offset/limit to continue. · builtin:workspace-tools" [checked] [ref=e240]
            - generic [ref=e241]:
              - strong [ref=e242]: read
              - generic [ref=e243]: Read a text file. Output is truncated to 2000 lines or 50.0 KiB. Use offset/limit to continue. · builtin:workspace-tools
          - generic [ref=e244]:
            - checkbox "write Create or overwrite a text file and create missing parent directories. Requires a trusted workspace. · builtin:workspace-tools" [checked] [ref=e245]
            - generic [ref=e246]:
              - strong [ref=e247]: write
              - generic [ref=e248]: Create or overwrite a text file and create missing parent directories. Requires a trusted workspace. · builtin:workspace-tools
          - generic [ref=e249]:
            - checkbox "edit Edit one file using exact, unique, non-overlapping replacements against the original content. Requires a trusted workspace. · builtin:workspace-tools" [checked] [ref=e250]
            - generic [ref=e251]:
              - strong [ref=e252]: edit
              - generic [ref=e253]: Edit one file using exact, unique, non-overlapping replacements against the original content. Requires a trusted workspace. · builtin:workspace-tools
          - generic [ref=e254]:
            - checkbox "ls List a directory alphabetically, including dotfiles. Output is bounded to 500 entries or 50.0 KiB by default. · builtin:workspace-tools" [checked] [ref=e255]
            - generic [ref=e256]:
              - strong [ref=e257]: ls
              - generic [ref=e258]: List a directory alphabetically, including dotfiles. Output is bounded to 500 entries or 50.0 KiB by default. · builtin:workspace-tools
          - generic [ref=e259]:
            - checkbox "find Find files by glob pattern. Git repositories respect .gitignore. Results are bounded to 1000 paths or 50.0 KiB by default. · builtin:workspace-tools" [checked] [ref=e260]
            - generic [ref=e261]:
              - strong [ref=e262]: find
              - generic [ref=e263]: Find files by glob pattern. Git repositories respect .gitignore. Results are bounded to 1000 paths or 50.0 KiB by default. · builtin:workspace-tools
          - generic [ref=e264]:
            - checkbox "grep Search text files with a regex or literal string. Git repositories respect .gitignore. Results are bounded to 100 matches or 50.0 KiB by default. · builtin:workspace-tools" [checked] [ref=e265]
            - generic [ref=e266]:
              - strong [ref=e267]: grep
              - generic [ref=e268]: Search text files with a regex or literal string. Git repositories respect .gitignore. Results are bounded to 100 matches or 50.0 KiB by default. · builtin:workspace-tools
          - generic [ref=e269]:
            - checkbox "bash Execute a shell command in the trusted workspace. Combined output is bounded to the last 2000 lines or 50.0 KiB. · builtin:workspace-tools" [checked] [ref=e270]
            - generic [ref=e271]:
              - strong [ref=e272]: bash
              - generic [ref=e273]: Execute a shell command in the trusted workspace. Combined output is bounded to the last 2000 lines or 50.0 KiB. · builtin:workspace-tools
          - generic [ref=e274]:
            - checkbox "load_skill List model-enabled skills, or load the instructions for one enabled skill by name. · builtin:skills" [checked] [ref=e275]
            - generic [ref=e276]:
              - strong [ref=e277]: load_skill
              - generic [ref=e278]: List model-enabled skills, or load the instructions for one enabled skill by name. · builtin:skills
          - generic [ref=e279]:
            - checkbox "spawn_subagent Delegate a focused task to an enabled child-agent profile. It can continue in the background. · builtin:subagents" [checked] [ref=e280]
            - generic [ref=e281]:
              - strong [ref=e282]: spawn_subagent
              - generic [ref=e283]: Delegate a focused task to an enabled child-agent profile. It can continue in the background. · builtin:subagents
          - generic [ref=e284]:
            - checkbox [checked] [ref=e285]
            - generic [ref=e286]:
              - strong [ref=e287]: codemode
              - generic [ref=e288]: "Run an async JavaScript body in bounded QuickJS. Use await tools.<name>({...}), Promise.allSettled(), text(), console.log(), return, exit(), store()/load(), searchTools(), describeTool() and describeNamespace(). No Node, filesystem, network or timers. Calls are real, unattended and not rolled back. Model-only control tools and recursive codemode are unavailable. models.getModelsOfType(\"classifier\"|\"image\"), models.classify({model,input,labels}), models.classifyQuestions({model,state,questions,images?}) and models.generateImages({model,prompt,count?,size?}) use credential-private current or explicitly host-authorized auxiliary models; use returned IDs exactly and recheck availability on each call. Use await image({mediaType,data}) to attach a validated image to the outer result. Images share the output budget and binary model results share the nested JSON budget. Default ceilings: 10 seconds, 32 MiB VM, 64 calls, 4 concurrent calls, 64 KiB output. Input is {code: \"JavaScript\"}. · builtin:codemode"
              - generic [ref=e289]: Inactive unless explicitly selected or required by eligible indirect tools.
          - generic [ref=e290]:
            - 'checkbox "tool_search # Tool discovery Searches deferred tool metadata with BM25 and exposes matching tools for the next model call. Some tools, including MCP tools, are intentionally not declared up front. Use `tool_search` to find and load only the tools needed for the task. · builtin:tool-search Inactive unless explicitly selected or required by eligible indirect tools." [checked] [ref=e291]'
            - generic [ref=e292]:
              - strong [ref=e293]: tool_search
              - generic [ref=e294]: "# Tool discovery Searches deferred tool metadata with BM25 and exposes matching tools for the next model call. Some tools, including MCP tools, are intentionally not declared up front. Use `tool_search` to find and load only the tools needed for the task. · builtin:tool-search"
              - generic [ref=e295]: Inactive unless explicitly selected or required by eligible indirect tools.
        - generic [ref=e296]:
          - checkbox "Enable PowerShell tool (Windows hosts only)" [disabled] [ref=e297]
          - text: Enable PowerShell tool (Windows hosts only)
      - generic [ref=e298]:
        - generic [ref=e299]:
          - generic [ref=e300]:
            - heading "Plugins and packages" [level=3] [ref=e301]
            - paragraph [ref=e302]: Install and inspect extensions, skills, prompts and themes. Installs, checks and updates run only when explicitly requested.
          - generic [ref=e303]: generation 0
        - generic [ref=e304]:
          - generic [ref=e305]:
            - generic [ref=e306]: Package source
            - textbox "Package source" [ref=e307]:
              - /placeholder: npm:@scope/package
          - generic [ref=e308]:
            - generic [ref=e309]: Install scope
            - combobox "Install scope" [ref=e310] [cursor=pointer]:
              - option "Global" [selected]
              - option "Project"
          - button "Install" [disabled] [ref=e311] [cursor=pointer]
          - generic [ref=e312]: "Accepted sources: npm:package, git:https://an-allowed-host/owner/repository, or an absolute path inside an allowed root."
        - generic [ref=e313]:
          - generic [ref=e314]:
            - generic [ref=e315]: Filter packages
            - searchbox "Filter packages" [ref=e316]
          - generic [ref=e317]:
            - button "Check all" [disabled] [ref=e318] [cursor=pointer]
            - button "Reload resources" [ref=e319] [cursor=pointer]
            - button "Refresh" [ref=e320] [cursor=pointer]
        - paragraph [ref=e322]: No package or standalone extension matches this workspace and filter.
        - generic [ref=e323]: 0 extensions · 0 skills · 0 prompts · 0 themes
      - generic [ref=e325]:
        - heading "Sub-agents" [level=3] [ref=e326]
        - paragraph [ref=e327]: Configure reusable child-agent profiles, their context, tools and execution limits.
        - generic [ref=e328]:
          - generic [ref=e329]:
            - generic [ref=e330]: Configuration scope
            - combobox "Configuration scope" [ref=e331] [cursor=pointer]:
              - option "Project workspace" [selected]
              - option "Global defaults"
          - generic [ref=e332]:
            - generic [ref=e333]: Maximum concurrent child agents
            - spinbutton "Maximum concurrent child agents" [ref=e334]: "4"
          - generic [ref=e335]:
            - checkbox "Enable the integrated sub-agent engine" [checked] [ref=e336]
            - text: Enable the integrated sub-agent engine
          - generic [ref=e337]: "Effective scope: global (built-in)"
        - generic [ref=e338]:
          - generic [ref=e339]:
            - generic [ref=e340]: Filter profiles
            - searchbox "Filter profiles" [ref=e341]
          - button "Create profile" [ref=e342] [cursor=pointer]
          - button "Refresh" [ref=e343] [cursor=pointer]
        - generic [ref=e344]:
          - article [ref=e345]:
            - generic [ref=e346]:
              - generic [ref=e347]:
                - strong [ref=e348]: Explore
                - generic [ref=e349]: explore
              - generic [ref=e350]: Explore · built-in
            - paragraph [ref=e351]: Inspect the workspace and report focused findings without modifying files.
            - generic [ref=e352]:
              - term [ref=e353]: Maximum turns
              - definition [ref=e354]: "8"
              - term [ref=e355]: Model
              - definition [ref=e356]: Auto
              - term [ref=e357]: Tools
              - definition [ref=e358]: ls, read, grep, find, load_skill
              - term [ref=e359]: Skills
              - definition [ref=e360]: All allowed by the parent
            - generic [ref=e361]:
              - generic [ref=e362]:
                - checkbox "Enable sub-agent profile Explore" [checked] [ref=e363]
                - text: Profile enabled
              - button "Edit" [ref=e364] [cursor=pointer]
              - button "Duplicate" [ref=e365] [cursor=pointer]
          - article [ref=e366]:
            - generic [ref=e367]:
              - generic [ref=e368]:
                - strong [ref=e369]: General purpose
                - generic [ref=e370]: general
              - generic [ref=e371]: General purpose · built-in
            - paragraph [ref=e372]: Handle a delegated implementation or investigation with the parent tool policy.
            - generic [ref=e373]:
              - term [ref=e374]: Maximum turns
              - definition [ref=e375]: "12"
              - term [ref=e376]: Model
              - definition [ref=e377]: Auto
              - term [ref=e378]: Tools
              - definition [ref=e379]: All allowed by the parent
              - term [ref=e380]: Skills
              - definition [ref=e381]: All allowed by the parent
            - generic [ref=e382]:
              - generic [ref=e383]:
                - checkbox "Enable sub-agent profile General purpose" [checked] [ref=e384]
                - text: Profile enabled
              - button "Edit" [ref=e385] [cursor=pointer]
              - button "Duplicate" [ref=e386] [cursor=pointer]
          - article [ref=e387]:
            - generic [ref=e388]:
              - generic [ref=e389]:
                - strong [ref=e390]: Plan
                - generic [ref=e391]: plan
              - generic [ref=e392]: Plan · built-in
            - paragraph [ref=e393]: Analyze a request and produce an actionable plan without modifying files.
            - generic [ref=e394]:
              - term [ref=e395]: Maximum turns
              - definition [ref=e396]: "8"
              - term [ref=e397]: Model
              - definition [ref=e398]: Auto
              - term [ref=e399]: Tools
              - definition [ref=e400]: ls, read, grep, find, load_skill
              - term [ref=e401]: Skills
              - definition [ref=e402]: All allowed by the parent
            - generic [ref=e403]:
              - generic [ref=e404]:
                - checkbox "Enable sub-agent profile Plan" [checked] [ref=e405]
                - text: Profile enabled
              - button "Edit" [ref=e406] [cursor=pointer]
              - button "Duplicate" [ref=e407] [cursor=pointer]
      - generic [ref=e408]:
        - heading "Appearance" [level=3] [ref=e409]
        - generic [ref=e410]:
          - generic [ref=e411]:
            - text: Theme
            - combobox "Theme" [ref=e412] [cursor=pointer]:
              - option "System"
              - option "Light" [selected]
              - option "Dark"
              - option "Mist"
              - option "Rose"
              - option "Pine"
          - generic [ref=e413]:
            - text: Send key
            - combobox "Send key" [ref=e414] [cursor=pointer]:
              - option "Enter (Shift+Enter for a new line)" [selected]
              - option "Ctrl/Cmd+Enter (Enter for a new line)"
          - generic [ref=e415]:
            - text: "Content width: 1000px"
            - 'slider "Content width: 1000px" [ref=e416]': "1000"
          - generic [ref=e417]:
            - text: "Font size: 16px"
            - 'slider "Font size: 16px" [ref=e418]': "16"
          - generic [ref=e419]:
            - checkbox "Open reasoning blocks by default" [ref=e420]
            - text: Open reasoning blocks by default
          - generic [ref=e421]:
            - checkbox "Play alert sounds" [ref=e422]
            - text: Play alert sounds
          - generic [ref=e423]:
            - text: Sound volume
            - slider "Sound volume" [ref=e424]: "0.25"
          - group "Sound events" [ref=e425]:
            - generic [ref=e427]:
              - checkbox "Agent completion" [checked] [ref=e428]
              - text: Agent completion
            - generic [ref=e429]:
              - checkbox "Attention required or failure" [checked] [ref=e430]
              - text: Attention required or failure
          - generic [ref=e431]:
            - checkbox "Show local notifications while this app is open" [ref=e432]
            - text: Show local notifications while this app is open
          - group "Local notification events" [ref=e433]:
            - generic [ref=e435]:
              - checkbox "Agent completion" [checked] [ref=e436]
              - text: Agent completion
            - generic [ref=e437]:
              - checkbox "Attention required or failure" [checked] [ref=e438]
              - text: Attention required or failure
          - generic [ref=e439]:
            - checkbox "Receive Web Push notifications when the app is closed" [ref=e440]
            - text: Receive Web Push notifications when the app is closed
          - group "Web Push events" [ref=e441]:
            - generic [ref=e443]:
              - checkbox "Agent completion" [checked] [ref=e444]
              - text: Agent completion
            - generic [ref=e445]:
              - checkbox "Attention required or failure" [checked] [ref=e446]
              - text: Attention required or failure
          - generic [ref=e447]:
            - checkbox "Show actions for selected text" [checked] [ref=e448]
            - text: Show actions for selected text
      - generic [ref=e449]:
        - heading "Keyboard shortcuts" [level=3] [ref=e450]
        - paragraph [ref=e451]: Focus a field and press a key combination. Backspace restores its default.
        - generic [ref=e452]:
          - generic [ref=e453]:
            - generic [ref=e454]: New session
            - textbox "Shortcut for New session" [ref=e455] [cursor=pointer]: Ctrl+Shift+O
          - generic [ref=e456]:
            - generic [ref=e457]: Focus prompt
            - textbox "Shortcut for Focus prompt" [ref=e458] [cursor=pointer]: Ctrl+L
          - generic [ref=e459]:
            - generic [ref=e460]: Show/hide sidebar
            - textbox "Shortcut for Show/hide sidebar" [ref=e461] [cursor=pointer]: Ctrl+Shift+S
          - generic [ref=e462]:
            - generic [ref=e463]: Show/hide files
            - textbox "Shortcut for Show/hide files" [ref=e464] [cursor=pointer]: Ctrl+Shift+F
          - generic [ref=e465]:
            - generic [ref=e466]: Show/hide terminal
            - textbox "Shortcut for Show/hide terminal" [ref=e467] [cursor=pointer]: Ctrl+Shift+T
          - generic [ref=e468]:
            - generic [ref=e469]: Open settings
            - textbox "Shortcut for Open settings" [ref=e470] [cursor=pointer]: Ctrl+,
          - generic [ref=e471]:
            - generic [ref=e472]: Open command palette
            - textbox "Shortcut for Open command palette" [ref=e473] [cursor=pointer]: Ctrl+K
        - button "Reset shortcuts" [ref=e474] [cursor=pointer]
      - generic [ref=e475]:
        - heading "Sessions" [level=3] [ref=e476]
        - paragraph [ref=e477]: "Total sessions: 1"
        - text: Persisted as JSONL files in ~/.ai-harness/sessions/
      - generic [ref=e478]:
        - generic [ref=e479]:
          - generic [ref=e480]:
            - heading "MCP servers" [level=3] [ref=e481]
            - paragraph [ref=e482]: Inspect and edit redacted configuration. Test explicitly rereads one entry, may resolve its values, run configured commands, start its process or contact its URL once, then closes it; it never starts OAuth sign-in.
          - button "Refresh" [ref=e483] [cursor=pointer]
        - group [ref=e484]:
          - generic "Paste and preview a server" [ref=e485] [cursor=pointer]
          - generic [ref=e486]:
            - paragraph [ref=e487]: Paste a URL, command, install link, or JSON/JSONC configuration. Review the redacted preview, complete required fields, then choose a scope. Previewing and saving never run commands, connect, or start OAuth.
            - generic [ref=e488]: MCP server text
            - textbox "MCP server text" [active] [ref=e489]:
              - /placeholder: Paste a URL, add command, or configuration object…
              - text: https://docs.example.test/mcp
            - generic [ref=e490]:
              - checkbox "Treat resolved values as AiHarness syntax" [ref=e491]
              - generic [ref=e492]: Treat resolved values as AiHarness syntax
            - paragraph [ref=e493]: Leave this off for another client. Foreign literals are escaped; explicit variable forms in supported shell/client commands remain references. Enable it only for values deliberately using AiHarness references or command-backed fields.
            - generic [ref=e494]:
              - button "Preview" [ref=e495] [cursor=pointer]
              - button "Clear paste" [ref=e496] [cursor=pointer]
        - group "Global configuration" [ref=e497]:
          - paragraph [ref=e499]: No MCP server is declared in this scope.
        - group "Project configuration" [ref=e500]:
          - paragraph [ref=e502]: No MCP server is declared in this scope.
      - generic [ref=e503]:
        - heading "About" [level=3] [ref=e504]
        - paragraph [ref=e505]: Unified AI Agent Platform
        - generic [ref=e506]:
          - generic [ref=e507]:
            - term [ref=e508]: Web version
            - definition [ref=e509]: 0.1.0
            - term [ref=e510]: Agent version
            - definition [ref=e511]: 0.1.0
          - group [ref=e512]:
            - generic "Update check details" [ref=e513]
          - button "Check again" [ref=e514] [cursor=pointer]
        - generic [ref=e515]:
          - link "📖 Documentation" [ref=e516] [cursor=pointer]:
            - /url: https://github.com/Fidigi/AiHarness#readme
          - generic [ref=e517]: •
          - link "⭐ Star on GitHub" [ref=e518] [cursor=pointer]:
            - /url: https://github.com/Fidigi/AiHarness
  - complementary "Status messages"
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright';
  2   | import { expect, test, type Page, type Request } from './fixtures/test-budget';
  3   | import { installMockApi, mockSession } from './fixtures/mock-api';
  4   | import { mcpStateInventory } from './fixtures/mcp';
  5   | 
  6   | // Match both Vite's dev filename and its exact fingerprinted production asset.
  7   | // Keep JS URL-module requests separate by resource type at each interception.
  8   | const MOBILE_STYLESHEET_URL = /\/mobile-keyboard(?:-[\w-]+)?\.css(?:[?#]|$)/u;
  9   | 
  10  | test('mobile stylesheet matching covers dev and production without unrelated assets', () => {
  11  |   for (const url of ['http://localhost:3080/src/hooks/mobile-keyboard.css', 'http://localhost:3080/assets/mobile-keyboard-Biz3w2xO.css', 'http://localhost:3080/assets/mobile-keyboard-AB_cd-01.css?v=1']) expect(MOBILE_STYLESHEET_URL.test(url)).toBe(true);
  12  |   for (const url of ['http://localhost:3080/assets/index.css', 'http://localhost:3080/assets/mobile-keyboard.js', 'http://localhost:3080/assets/mobile-keyboard.css.map', 'http://localhost:3080/assets/not-mobile-keyboard.css']) expect(MOBILE_STYLESHEET_URL.test(url)).toBe(false);
  13  | });
  14  | 
  15  | // This controls browser signals, NOT a native Android/iOS keyboard or Safari UI.
  16  | // Every assertion below exercises actual ChatView/Settings, never a test component.
  17  | interface ViewportSignals { height: number; width: number; scale: number; offsetTop: number }
  18  | interface KeyboardDriver {
  19  |   set(values: Partial<ViewportSignals>, event?: string): void;
  20  |   listeners: number;
  21  | }
  22  | 
  23  | declare global {
  24  |   interface Window { __mobileKeyboard: KeyboardDriver }
  25  | }
  26  | 
  27  | async function installViewportSignals(page: Page): Promise<void> {
  28  |   const size = page.viewportSize();
  29  |   if (!size) throw new Error('These mobile keyboard tests require a bounded viewport.');
  30  |   await page.addInitScript(size => {
  31  |     class ControlledViewport extends EventTarget {
  32  |       height = size.height;
  33  |       width = size.width;
  34  |       scale = 1;
  35  |       offsetTop = 0;
  36  |       offsetLeft = 0;
  37  |       pageTop = 0;
  38  |       pageLeft = 0;
  39  |       listeners = 0;
  40  |       override addEventListener(...args: Parameters<EventTarget['addEventListener']>) {
  41  |         super.addEventListener(...args); this.listeners++;
  42  |       }
  43  |       override removeEventListener(...args: Parameters<EventTarget['removeEventListener']>) {
  44  |         super.removeEventListener(...args); this.listeners--;
  45  |       }
  46  |     }
  47  |     const viewport = new ControlledViewport();
  48  |     Object.defineProperty(window, 'visualViewport', { configurable: true, value: viewport });
  49  |     window.__mobileKeyboard = {
  50  |       set(values, event = 'resize') { Object.assign(viewport, values); viewport.dispatchEvent(new Event(event)); },
  51  |       get listeners() { return viewport.listeners; },
  52  |     };
  53  |   }, size);
  54  | }
  55  | 
  56  | async function openNewChatFromRoot(page: Page): Promise<void> {
  57  |   await page.goto('/');
  58  |   await page.getByRole('button', { name: 'Toggle navigation', exact: true }).click();
  59  |   await expect(page.locator('.workspace-button small')).not.toBeEmpty();
  60  |   const warning = page.getByRole('button', { name: /Project not trusted/i });
  61  |   if (await warning.isVisible()) {
  62  |     await warning.click();
  63  |     const dialog = page.getByRole('alertdialog', { name: 'Trust this project?' });
  64  |     await dialog.getByRole('button', { name: 'Trust project', exact: true }).click();
  65  |     await expect(dialog).toHaveCount(0);
  66  |   }
  67  |   await page.getByRole('button', { name: 'New chat', exact: true }).click();
  68  | }
  69  | 
  70  | async function signals(page: Page, values: Partial<ViewportSignals>, event = 'resize'): Promise<void> {
  71  |   await page.evaluate(({ values, event }) => window.__mobileKeyboard.set(values, event), { values, event });
  72  |   // Flush the coalesced measurement and React commit, not a guessed keyboard delay.
  73  |   await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  74  | }
  75  | 
  76  | async function settle(page: Page): Promise<void> {
  77  |   await page.evaluate(async () => { await document.fonts.ready; });
  78  | }
  79  | 
  80  | async function capture(page: Page, name: string, selector = '.chat-view'): Promise<void> {
  81  |   await settle(page);
> 82  |   await expect(page.locator(selector)).toHaveScreenshot(name, {
      |                                        ^ Error: expect(locator).toHaveScreenshot(expected) failed
  83  |     animations: 'disabled', caret: 'hide', maxDiffPixelRatio: 0.02,
  84  |   });
  85  |   // Retain the current run's actual pixels for individual read-only inspection.
  86  |   await page.locator(selector).screenshot({ path: test.info().outputPath(name), animations: 'disabled', caret: 'hide' });
  87  | }
  88  | 
  89  | for (const scenario of [
  90  |   { name: 'desktop-light', width: 1440, mobile: false, theme: 'light' },
  91  |   { name: 'desktop-dark', width: 1440, mobile: false, theme: 'dark' },
  92  |   { name: 'mobile-light', width: 390, mobile: true, theme: 'light' },
  93  |   { name: 'mobile-dark', width: 390, mobile: true, theme: 'dark' },
  94  | ] as const) {
  95  |   test.describe(scenario.name, () => {
  96  |     test.use({ viewport: { width: scenario.width, height: 844 }, isMobile: scenario.mobile, hasTouch: scenario.mobile });
  97  |     test('keyboard signals preserve chat controls and MCP settings', async ({ page }) => {
  98  |       await page.addInitScript(theme => localStorage.setItem('ai-harness-preferences-v4', JSON.stringify({
  99  |         version: 4, theme, lastSettingsSection: 'mcp',
  100 |       })), scenario.theme);
  101 |       await installViewportSignals(page);
  102 |       const api = await installMockApi(page, {
  103 |         sessions: [mockSession('mobile-keyboard', 'Mobile keyboard', [
  104 |           { role: 'user', content: 'Keep the mobile composer usable.' },
  105 |           { role: 'assistant', content: 'Send, attachments and MCP navigation remain available.' },
  106 |         ])],
  107 |         mcpConfig: mcpStateInventory(), holdAgentRun: true,
  108 |       });
  109 |       await page.goto('/chat/mobile-keyboard?cwd=%2Fworkspace');
  110 |       const chat = page.locator('.chat-view');
  111 |       const composer = page.getByRole('textbox', { name: 'Message composer', exact: true });
  112 |       await composer.fill('Keyboard layout check');
  113 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', 'false');
  114 |       await expect(page.getByRole('combobox', { name: 'Select the model', exact: true })).toBeVisible();
  115 |       await capture(page, `keyboard-expanded-${scenario.name}.png`);
  116 | 
  117 |       // Toolbar movement and scroll-only panning are not keyboard detection.
  118 |       await signals(page, { height: 720, offsetTop: 64 });
  119 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', 'false');
  120 |       await signals(page, { offsetTop: 80 }, 'scroll');
  121 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', 'false');
  122 |       await signals(page, { scale: 2, width: scenario.width / 2, height: 422 });
  123 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', 'false');
  124 |       // Zoom plus extra height loss is distinguishable from pinch alone.
  125 |       await signals(page, { scale: 1.3, width: scenario.width / 1.3, height: 350, offsetTop: 0 });
  126 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', String(scenario.mobile));
  127 |       await signals(page, { scale: 1, width: scenario.width, height: 844, offsetTop: 0 });
  128 |       await signals(page, { height: 480, offsetTop: 12 });
  129 |       await expect(chat).toHaveAttribute('data-mobile-keyboard', String(scenario.mobile));
  130 |       if (scenario.mobile) {
  131 |         await expect(composer).toBeFocused();
  132 |         await expect(page.getByRole('combobox', { name: 'Select the model', exact: true })).toBeHidden();
  133 |         await expect(chat.locator('.composer-setting-scopes')).toBeHidden();
  134 |         await expect(chat.locator('.mobile-chat-actions')).toBeHidden();
  135 |         await expect(page.getByRole('button', { name: 'Send', exact: true })).toBeVisible();
  136 |         await expect(page.locator('button').and(page.getByRole('button', { name: 'Add images', exact: true }))).toBeVisible();
  137 |         const form = await chat.locator('.input-container').boundingBox();
  138 |         expect(form).not.toBeNull();
  139 |         expect(form!.y + form!.height).toBeLessThanOrEqual(493);
  140 |         expect(await composer.evaluate(element => Number.parseFloat(getComputedStyle(element.parentElement!).paddingBottom))).toBeGreaterThanOrEqual(12);
  141 |         expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(scenario.width);
  142 |         await capture(page, `keyboard-collapsed-${scenario.name}.png`);
  143 |         const accessibility = await new AxeBuilder({ page }).include('.input-container')
  144 |           .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  145 |         expect(accessibility.violations).toEqual([]);
  146 | 
  147 |         // The focused model field must never be hidden by chrome collapse.
  148 |         await signals(page, { height: 844, offsetTop: 0 });
  149 |         const model = page.getByRole('combobox', { name: 'Select the model', exact: true });
  150 |         await model.focus(); await signals(page, { height: 480 });
  151 |         await expect(model).toBeVisible(); await expect(model).toBeFocused();
  152 |         await composer.focus();
  153 |       }
  154 |       // Active Queue/Stop controls are retained, and /mcp is local navigation.
  155 |       await composer.press('Enter');
  156 |       await expect(page.getByRole('button', { name: 'Stop model', exact: true })).toBeVisible();
  157 |       await composer.fill('Queued keyboard check');
  158 |       await expect(page.getByRole('button', { name: 'Queue', exact: true })).toBeVisible();
  159 |       await expect(page.getByRole('combobox', { name: 'Queue mode', exact: true })).toBeVisible();
  160 |       await composer.fill('/mcp'); await page.getByRole('button', { name: 'Queue', exact: true }).click();
  161 |       await expect(page).toHaveURL(/\/settings#mcp$/);
  162 |       await expect(chat).toHaveCount(0);
  163 |       await expect.poll(() => page.evaluate(() => window.__mobileKeyboard.listeners)).toBe(0);
  164 |       expect(api.requests.filter(request => request.path === '/api/agent/runs' && request.method === 'POST')).toHaveLength(1);
  165 |       expect(api.requests.some(request => request.path.endsWith('/stop') || request.path.endsWith('/queue'))).toBe(false);
  166 |       // CSS is chat-local; MCP paste and administration stay focusable/scrollable.
  167 |       if (scenario.mobile) await page.setViewportSize({ width: scenario.width, height: 480 });
  168 |       await page.locator('.mcp-import-panel > summary').click();
  169 |       const paste = page.getByRole('textbox', { name: 'MCP server text', exact: true });
  170 |       await paste.fill('https://docs.example.test/mcp');
  171 |       await expect(paste).toBeFocused();
  172 |       await expect(page.getByRole('button', { name: 'Preview', exact: true })).toBeVisible();
  173 |       await capture(page, `keyboard-mcp-${scenario.name}.png`, '.mcp-import-panel');
  174 |       expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(scenario.width);
  175 |       await page.goto('/chat/mobile-keyboard?cwd=%2Fworkspace');
  176 |       await expect.poll(() => page.evaluate(() => window.__mobileKeyboard.listeners)).toBe(2);
  177 |     });
  178 |   });
  179 | }
  180 | 
  181 | test.describe('lazy stylesheet lifecycle in real ChatView', () => {
  182 |   test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
```