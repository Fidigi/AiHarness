# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chat.spec.ts >> Conversation detached agent >> préserve le scroll de lecture et permet de revenir en bas
- Location: e2e/chat.spec.ts:688:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "Main navigation" [ref=e4]:
    - generic [ref=e5]:
      - heading "AiHarness" [level=1] [ref=e6]
      - generic [ref=e7]:
        - generic "Language" [ref=e8]:
          - generic [aria-hidden] [ref=e9]: 🌐
          - combobox "Language" [ref=e11] [cursor=pointer]:
            - option "English" [selected]
            - option "Français"
        - button "New chat" [ref=e12] [cursor=pointer]: +
    - generic [ref=e13]:
      - generic [ref=e14]: Workspace
      - generic [ref=e15]:
        - button "workspace main" [ref=e16] [cursor=pointer]:
          - generic [ref=e17]: workspace
          - generic [ref=e18]: main
        - link "Open project in a new tab" [ref=e19] [cursor=pointer]:
          - /url: /?cwd=%2Fworkspace
          - text: ↗
      - button "Linked directories" [ref=e20] [cursor=pointer]
      - generic [ref=e21]:
        - combobox "Git worktree" [ref=e22]:
          - option "main" [selected]
        - button "Create a worktree" [ref=e23] [cursor=pointer]: +
    - generic [ref=e24]:
      - searchbox "Search conversations" [ref=e25]
      - button "Refresh files" [ref=e26] [cursor=pointer]: ↻
    - group [ref=e27]:
      - generic "Organise navigation" [ref=e28] [cursor=pointer]
    - navigation "Conversations" [ref=e29]:
      - list [ref=e30]:
        - listitem [ref=e31]:
          - link "Long historique 72 · 684 days ago" [ref=e33] [cursor=pointer]:
            - /url: /chat/long-session?cwd=%2Fworkspace
            - generic [ref=e34]: Long historique
            - generic [ref=e35]: 72 · 684 days ago
    - button "⚙ Settings" [ref=e37] [cursor=pointer]
  - main [ref=e38]:
    - generic [ref=e39]:
      - generic [ref=e40]:
        - generic [ref=e41]:
          - strong [ref=e42]: Long historique
          - generic [ref=e43]: /workspace
        - generic [ref=e44]:
          - status
          - button "Open child agents (0)" [ref=e46] [cursor=pointer]:
            - generic [ref=e47]: Child agents
            - generic [ref=e48]: "0"
          - button "Branches" [ref=e49] [cursor=pointer]
          - button "Context" [ref=e50] [cursor=pointer]
          - button "Information" [ref=e51] [cursor=pointer]
          - button "Conversation map" [ref=e52] [cursor=pointer]
      - log "Conversation messages" [ref=e53]:
        - 'article "user: Message 1 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e54]':
          - generic [ref=e55]: 👤 You
          - paragraph [ref=e59]: Message 1 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e60]:
            - time [ref=e61]: 12:00:00 PM
            - button "Copy" [ref=e62] [cursor=pointer]
            - button "Edit from here" [ref=e63] [cursor=pointer]
            - button "New chat from here" [ref=e64] [cursor=pointer]
        - 'article "assistant: Message 2 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e65]':
          - generic [ref=e66]: 🤖 Assistant
          - region "Response" [ref=e68]:
            - paragraph [ref=e70]: Message 2 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e71]:
            - time [ref=e72]: 12:00:00 PM
            - button "Copy" [ref=e73] [cursor=pointer]
        - 'article "user: Message 3 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e74]':
          - generic [ref=e75]: 👤 You
          - paragraph [ref=e79]: Message 3 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e80]:
            - time [ref=e81]: 12:00:00 PM
            - button "Copy" [ref=e82] [cursor=pointer]
            - button "Edit from here" [ref=e83] [cursor=pointer]
            - button "New chat from here" [ref=e84] [cursor=pointer]
        - 'article "assistant: Message 4 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e85]':
          - generic [ref=e86]: 🤖 Assistant
          - region "Response" [ref=e88]:
            - paragraph [ref=e90]: Message 4 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e91]:
            - time [ref=e92]: 12:00:00 PM
            - button "Copy" [ref=e93] [cursor=pointer]
        - 'article "user: Message 5 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e94]':
          - generic [ref=e95]: 👤 You
          - paragraph [ref=e99]: Message 5 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e100]:
            - time [ref=e101]: 12:00:00 PM
            - button "Copy" [ref=e102] [cursor=pointer]
            - button "Edit from here" [ref=e103] [cursor=pointer]
            - button "New chat from here" [ref=e104] [cursor=pointer]
        - 'article "assistant: Message 6 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e105]':
          - generic [ref=e106]: 🤖 Assistant
          - region "Response" [ref=e108]:
            - paragraph [ref=e110]: Message 6 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e111]:
            - time [ref=e112]: 12:00:00 PM
            - button "Copy" [ref=e113] [cursor=pointer]
        - 'article "user: Message 7 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e114]':
          - generic [ref=e115]: 👤 You
          - paragraph [ref=e119]: Message 7 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e120]:
            - time [ref=e121]: 12:00:00 PM
            - button "Copy" [ref=e122] [cursor=pointer]
            - button "Edit from here" [ref=e123] [cursor=pointer]
            - button "New chat from here" [ref=e124] [cursor=pointer]
        - 'article "assistant: Message 8 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e125]':
          - generic [ref=e126]: 🤖 Assistant
          - region "Response" [ref=e128]:
            - paragraph [ref=e130]: Message 8 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e131]:
            - time [ref=e132]: 12:00:00 PM
            - button "Copy" [ref=e133] [cursor=pointer]
        - 'article "user: Message 9 — contenu contenu contenu contenu contenu contenu contenu contenu cont" [ref=e134]':
          - generic [ref=e135]: 👤 You
          - paragraph [ref=e139]: Message 9 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e140]:
            - time [ref=e141]: 12:00:00 PM
            - button "Copy" [ref=e142] [cursor=pointer]
            - button "Edit from here" [ref=e143] [cursor=pointer]
            - button "New chat from here" [ref=e144] [cursor=pointer]
        - 'article "assistant: Message 10 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e145]':
          - generic [ref=e146]: 🤖 Assistant
          - region "Response" [ref=e148]:
            - paragraph [ref=e150]: Message 10 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e151]:
            - time [ref=e152]: 12:00:00 PM
            - button "Copy" [ref=e153] [cursor=pointer]
        - 'article "user: Message 11 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e154]':
          - generic [ref=e155]: 👤 You
          - paragraph [ref=e159]: Message 11 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e160]:
            - time [ref=e161]: 12:00:00 PM
            - button "Copy" [ref=e162] [cursor=pointer]
            - button "Edit from here" [ref=e163] [cursor=pointer]
            - button "New chat from here" [ref=e164] [cursor=pointer]
        - 'article "assistant: Message 12 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e165]':
          - generic [ref=e166]: 🤖 Assistant
          - region "Response" [ref=e168]:
            - paragraph [ref=e170]: Message 12 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e171]:
            - time [ref=e172]: 12:00:00 PM
            - button "Copy" [ref=e173] [cursor=pointer]
        - 'article "user: Message 13 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e174]':
          - generic [ref=e175]: 👤 You
          - paragraph [ref=e179]: Message 13 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e180]:
            - time [ref=e181]: 12:00:00 PM
            - button "Copy" [ref=e182] [cursor=pointer]
            - button "Edit from here" [ref=e183] [cursor=pointer]
            - button "New chat from here" [ref=e184] [cursor=pointer]
        - 'article "assistant: Message 14 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e185]':
          - generic [ref=e186]: 🤖 Assistant
          - region "Response" [ref=e188]:
            - paragraph [ref=e190]: Message 14 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e191]:
            - time [ref=e192]: 12:00:00 PM
            - button "Copy" [ref=e193] [cursor=pointer]
        - 'article "user: Message 15 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e194]':
          - generic [ref=e195]: 👤 You
          - paragraph [ref=e199]: Message 15 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e200]:
            - time [ref=e201]: 12:00:00 PM
            - button "Copy" [ref=e202] [cursor=pointer]
            - button "Edit from here" [ref=e203] [cursor=pointer]
            - button "New chat from here" [ref=e204] [cursor=pointer]
        - 'article "assistant: Message 16 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e205]':
          - generic [ref=e206]: 🤖 Assistant
          - region "Response" [ref=e208]:
            - paragraph [ref=e210]: Message 16 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e211]:
            - time [ref=e212]: 12:00:00 PM
            - button "Copy" [ref=e213] [cursor=pointer]
        - 'article "user: Message 17 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e214]':
          - generic [ref=e215]: 👤 You
          - paragraph [ref=e219]: Message 17 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e220]:
            - time [ref=e221]: 12:00:00 PM
            - button "Copy" [ref=e222] [cursor=pointer]
            - button "Edit from here" [ref=e223] [cursor=pointer]
            - button "New chat from here" [ref=e224] [cursor=pointer]
        - 'article "assistant: Message 18 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e225]':
          - generic [ref=e226]: 🤖 Assistant
          - region "Response" [ref=e228]:
            - paragraph [ref=e230]: Message 18 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e231]:
            - time [ref=e232]: 12:00:00 PM
            - button "Copy" [ref=e233] [cursor=pointer]
        - 'article "user: Message 19 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e234]':
          - generic [ref=e235]: 👤 You
          - paragraph [ref=e239]: Message 19 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e240]:
            - time [ref=e241]: 12:00:00 PM
            - button "Copy" [ref=e242] [cursor=pointer]
            - button "Edit from here" [ref=e243] [cursor=pointer]
            - button "New chat from here" [ref=e244] [cursor=pointer]
        - 'article "assistant: Message 20 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e245]':
          - generic [ref=e246]: 🤖 Assistant
          - region "Response" [ref=e248]:
            - paragraph [ref=e250]: Message 20 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e251]:
            - time [ref=e252]: 12:00:00 PM
            - button "Copy" [ref=e253] [cursor=pointer]
        - 'article "user: Message 21 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e254]':
          - generic [ref=e255]: 👤 You
          - paragraph [ref=e259]: Message 21 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e260]:
            - time [ref=e261]: 12:00:00 PM
            - button "Copy" [ref=e262] [cursor=pointer]
            - button "Edit from here" [ref=e263] [cursor=pointer]
            - button "New chat from here" [ref=e264] [cursor=pointer]
        - 'article "assistant: Message 22 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e265]':
          - generic [ref=e266]: 🤖 Assistant
          - region "Response" [ref=e268]:
            - paragraph [ref=e270]: Message 22 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e271]:
            - time [ref=e272]: 12:00:00 PM
            - button "Copy" [ref=e273] [cursor=pointer]
        - 'article "user: Message 23 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e274]':
          - generic [ref=e275]: 👤 You
          - paragraph [ref=e279]: Message 23 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e280]:
            - time [ref=e281]: 12:00:00 PM
            - button "Copy" [ref=e282] [cursor=pointer]
            - button "Edit from here" [ref=e283] [cursor=pointer]
            - button "New chat from here" [ref=e284] [cursor=pointer]
        - 'article "assistant: Message 24 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e285]':
          - generic [ref=e286]: 🤖 Assistant
          - region "Response" [ref=e288]:
            - paragraph [ref=e290]: Message 24 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e291]:
            - time [ref=e292]: 12:00:00 PM
            - button "Copy" [ref=e293] [cursor=pointer]
        - 'article "user: Message 25 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e294]':
          - generic [ref=e295]: 👤 You
          - paragraph [ref=e299]: Message 25 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e300]:
            - time [ref=e301]: 12:00:00 PM
            - button "Copy" [ref=e302] [cursor=pointer]
            - button "Edit from here" [ref=e303] [cursor=pointer]
            - button "New chat from here" [ref=e304] [cursor=pointer]
        - 'article "assistant: Message 26 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e305]':
          - generic [ref=e306]: 🤖 Assistant
          - region "Response" [ref=e308]:
            - paragraph [ref=e310]: Message 26 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e311]:
            - time [ref=e312]: 12:00:00 PM
            - button "Copy" [ref=e313] [cursor=pointer]
        - 'article "user: Message 27 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e314]':
          - generic [ref=e315]: 👤 You
          - paragraph [ref=e319]: Message 27 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e320]:
            - time [ref=e321]: 12:00:00 PM
            - button "Copy" [ref=e322] [cursor=pointer]
            - button "Edit from here" [ref=e323] [cursor=pointer]
            - button "New chat from here" [ref=e324] [cursor=pointer]
        - 'article "assistant: Message 28 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e325]':
          - generic [ref=e326]: 🤖 Assistant
          - region "Response" [ref=e328]:
            - paragraph [ref=e330]: Message 28 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e331]:
            - time [ref=e332]: 12:00:00 PM
            - button "Copy" [ref=e333] [cursor=pointer]
        - 'article "user: Message 29 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e334]':
          - generic [ref=e335]: 👤 You
          - paragraph [ref=e339]: Message 29 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e340]:
            - time [ref=e341]: 12:00:00 PM
            - button "Copy" [ref=e342] [cursor=pointer]
            - button "Edit from here" [ref=e343] [cursor=pointer]
            - button "New chat from here" [ref=e344] [cursor=pointer]
        - 'article "assistant: Message 30 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e345]':
          - generic [ref=e346]: 🤖 Assistant
          - region "Response" [ref=e348]:
            - paragraph [ref=e350]: Message 30 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e351]:
            - time [ref=e352]: 12:00:00 PM
            - button "Copy" [ref=e353] [cursor=pointer]
        - 'article "user: Message 31 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e354]':
          - generic [ref=e355]: 👤 You
          - paragraph [ref=e359]: Message 31 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e360]:
            - time [ref=e361]: 12:00:00 PM
            - button "Copy" [ref=e362] [cursor=pointer]
            - button "Edit from here" [ref=e363] [cursor=pointer]
            - button "New chat from here" [ref=e364] [cursor=pointer]
        - 'article "assistant: Message 32 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e365]':
          - generic [ref=e366]: 🤖 Assistant
          - region "Response" [ref=e368]:
            - paragraph [ref=e370]: Message 32 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e371]:
            - time [ref=e372]: 12:00:00 PM
            - button "Copy" [ref=e373] [cursor=pointer]
        - 'article "user: Message 33 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e374]':
          - generic [ref=e375]: 👤 You
          - paragraph [ref=e379]: Message 33 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e380]:
            - time [ref=e381]: 12:00:00 PM
            - button "Copy" [ref=e382] [cursor=pointer]
            - button "Edit from here" [ref=e383] [cursor=pointer]
            - button "New chat from here" [ref=e384] [cursor=pointer]
        - 'article "assistant: Message 34 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e385]':
          - generic [ref=e386]: 🤖 Assistant
          - region "Response" [ref=e388]:
            - paragraph [ref=e390]: Message 34 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e391]:
            - time [ref=e392]: 12:00:00 PM
            - button "Copy" [ref=e393] [cursor=pointer]
        - 'article "user: Message 35 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e394]':
          - generic [ref=e395]: 👤 You
          - paragraph [ref=e399]: Message 35 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e400]:
            - time [ref=e401]: 12:00:00 PM
            - button "Copy" [ref=e402] [cursor=pointer]
            - button "Edit from here" [ref=e403] [cursor=pointer]
            - button "New chat from here" [ref=e404] [cursor=pointer]
        - 'article "assistant: Message 36 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e405]':
          - generic [ref=e406]: 🤖 Assistant
          - region "Response" [ref=e408]:
            - paragraph [ref=e410]: Message 36 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e411]:
            - time [ref=e412]: 12:00:00 PM
            - button "Copy" [ref=e413] [cursor=pointer]
        - 'article "user: Message 37 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e414]':
          - generic [ref=e415]: 👤 You
          - paragraph [ref=e419]: Message 37 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e420]:
            - time [ref=e421]: 12:00:00 PM
            - button "Copy" [ref=e422] [cursor=pointer]
            - button "Edit from here" [ref=e423] [cursor=pointer]
            - button "New chat from here" [ref=e424] [cursor=pointer]
        - 'article "assistant: Message 38 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e425]':
          - generic [ref=e426]: 🤖 Assistant
          - region "Response" [ref=e428]:
            - paragraph [ref=e430]: Message 38 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e431]:
            - time [ref=e432]: 12:00:00 PM
            - button "Copy" [ref=e433] [cursor=pointer]
        - 'article "user: Message 39 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e434]':
          - generic [ref=e435]: 👤 You
          - paragraph [ref=e439]: Message 39 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e440]:
            - time [ref=e441]: 12:00:00 PM
            - button "Copy" [ref=e442] [cursor=pointer]
            - button "Edit from here" [ref=e443] [cursor=pointer]
            - button "New chat from here" [ref=e444] [cursor=pointer]
        - 'article "assistant: Message 40 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e445]':
          - generic [ref=e446]: 🤖 Assistant
          - region "Response" [ref=e448]:
            - paragraph [ref=e450]: Message 40 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e451]:
            - time [ref=e452]: 12:00:00 PM
            - button "Copy" [ref=e453] [cursor=pointer]
        - 'article "user: Message 41 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e454]':
          - generic [ref=e455]: 👤 You
          - paragraph [ref=e459]: Message 41 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e460]:
            - time [ref=e461]: 12:00:00 PM
            - button "Copy" [ref=e462] [cursor=pointer]
            - button "Edit from here" [ref=e463] [cursor=pointer]
            - button "New chat from here" [ref=e464] [cursor=pointer]
        - 'article "assistant: Message 42 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e465]':
          - generic [ref=e466]: 🤖 Assistant
          - region "Response" [ref=e468]:
            - paragraph [ref=e470]: Message 42 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e471]:
            - time [ref=e472]: 12:00:00 PM
            - button "Copy" [ref=e473] [cursor=pointer]
        - 'article "user: Message 43 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e474]':
          - generic [ref=e475]: 👤 You
          - paragraph [ref=e479]: Message 43 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e480]:
            - time [ref=e481]: 12:00:00 PM
            - button "Copy" [ref=e482] [cursor=pointer]
            - button "Edit from here" [ref=e483] [cursor=pointer]
            - button "New chat from here" [ref=e484] [cursor=pointer]
        - 'article "assistant: Message 44 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e485]':
          - generic [ref=e486]: 🤖 Assistant
          - region "Response" [ref=e488]:
            - paragraph [ref=e490]: Message 44 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e491]:
            - time [ref=e492]: 12:00:00 PM
            - button "Copy" [ref=e493] [cursor=pointer]
        - 'article "user: Message 45 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e494]':
          - generic [ref=e495]: 👤 You
          - paragraph [ref=e499]: Message 45 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e500]:
            - time [ref=e501]: 12:00:00 PM
            - button "Copy" [ref=e502] [cursor=pointer]
            - button "Edit from here" [ref=e503] [cursor=pointer]
            - button "New chat from here" [ref=e504] [cursor=pointer]
        - 'article "assistant: Message 46 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e505]':
          - generic [ref=e506]: 🤖 Assistant
          - region "Response" [ref=e508]:
            - paragraph [ref=e510]: Message 46 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e511]:
            - time [ref=e512]: 12:00:00 PM
            - button "Copy" [ref=e513] [cursor=pointer]
        - 'article "user: Message 47 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e514]':
          - generic [ref=e515]: 👤 You
          - paragraph [ref=e519]: Message 47 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e520]:
            - time [ref=e521]: 12:00:00 PM
            - button "Copy" [ref=e522] [cursor=pointer]
            - button "Edit from here" [ref=e523] [cursor=pointer]
            - button "New chat from here" [ref=e524] [cursor=pointer]
        - 'article "assistant: Message 48 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e525]':
          - generic [ref=e526]: 🤖 Assistant
          - region "Response" [ref=e528]:
            - paragraph [ref=e530]: Message 48 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e531]:
            - time [ref=e532]: 12:00:00 PM
            - button "Copy" [ref=e533] [cursor=pointer]
        - 'article "user: Message 49 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e534]':
          - generic [ref=e535]: 👤 You
          - paragraph [ref=e539]: Message 49 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e540]:
            - time [ref=e541]: 12:00:00 PM
            - button "Copy" [ref=e542] [cursor=pointer]
            - button "Edit from here" [ref=e543] [cursor=pointer]
            - button "New chat from here" [ref=e544] [cursor=pointer]
        - 'article "assistant: Message 50 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e545]':
          - generic [ref=e546]: 🤖 Assistant
          - region "Response" [ref=e548]:
            - paragraph [ref=e550]: Message 50 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e551]:
            - time [ref=e552]: 12:00:00 PM
            - button "Copy" [ref=e553] [cursor=pointer]
        - 'article "user: Message 51 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e554]':
          - generic [ref=e555]: 👤 You
          - paragraph [ref=e559]: Message 51 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e560]:
            - time [ref=e561]: 12:00:00 PM
            - button "Copy" [ref=e562] [cursor=pointer]
            - button "Edit from here" [ref=e563] [cursor=pointer]
            - button "New chat from here" [ref=e564] [cursor=pointer]
        - 'article "assistant: Message 52 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e565]':
          - generic [ref=e566]: 🤖 Assistant
          - region "Response" [ref=e568]:
            - paragraph [ref=e570]: Message 52 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e571]:
            - time [ref=e572]: 12:00:00 PM
            - button "Copy" [ref=e573] [cursor=pointer]
        - 'article "user: Message 53 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e574]':
          - generic [ref=e575]: 👤 You
          - paragraph [ref=e579]: Message 53 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e580]:
            - time [ref=e581]: 12:00:00 PM
            - button "Copy" [ref=e582] [cursor=pointer]
            - button "Edit from here" [ref=e583] [cursor=pointer]
            - button "New chat from here" [ref=e584] [cursor=pointer]
        - 'article "assistant: Message 54 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e585]':
          - generic [ref=e586]: 🤖 Assistant
          - region "Response" [ref=e588]:
            - paragraph [ref=e590]: Message 54 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e591]:
            - time [ref=e592]: 12:00:00 PM
            - button "Copy" [ref=e593] [cursor=pointer]
        - 'article "user: Message 55 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e594]':
          - generic [ref=e595]: 👤 You
          - paragraph [ref=e599]: Message 55 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e600]:
            - time [ref=e601]: 12:00:00 PM
            - button "Copy" [ref=e602] [cursor=pointer]
            - button "Edit from here" [ref=e603] [cursor=pointer]
            - button "New chat from here" [ref=e604] [cursor=pointer]
        - 'article "assistant: Message 56 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e605]':
          - generic [ref=e606]: 🤖 Assistant
          - region "Response" [ref=e608]:
            - paragraph [ref=e610]: Message 56 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e611]:
            - time [ref=e612]: 12:00:00 PM
            - button "Copy" [ref=e613] [cursor=pointer]
        - 'article "user: Message 57 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e614]':
          - generic [ref=e615]: 👤 You
          - paragraph [ref=e619]: Message 57 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e620]:
            - time [ref=e621]: 12:00:00 PM
            - button "Copy" [ref=e622] [cursor=pointer]
            - button "Edit from here" [ref=e623] [cursor=pointer]
            - button "New chat from here" [ref=e624] [cursor=pointer]
        - 'article "assistant: Message 58 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e625]':
          - generic [ref=e626]: 🤖 Assistant
          - region "Response" [ref=e628]:
            - paragraph [ref=e630]: Message 58 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e631]:
            - time [ref=e632]: 12:00:00 PM
            - button "Copy" [ref=e633] [cursor=pointer]
        - 'article "user: Message 59 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e634]':
          - generic [ref=e635]: 👤 You
          - paragraph [ref=e639]: Message 59 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e640]:
            - time [ref=e641]: 12:00:00 PM
            - button "Copy" [ref=e642] [cursor=pointer]
            - button "Edit from here" [ref=e643] [cursor=pointer]
            - button "New chat from here" [ref=e644] [cursor=pointer]
        - 'article "assistant: Message 60 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e645]':
          - generic [ref=e646]: 🤖 Assistant
          - region "Response" [ref=e648]:
            - paragraph [ref=e650]: Message 60 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e651]:
            - time [ref=e652]: 12:00:00 PM
            - button "Copy" [ref=e653] [cursor=pointer]
        - 'article "user: Message 61 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e654]':
          - generic [ref=e655]: 👤 You
          - paragraph [ref=e659]: Message 61 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e660]:
            - time [ref=e661]: 12:00:00 PM
            - button "Copy" [ref=e662] [cursor=pointer]
            - button "Edit from here" [ref=e663] [cursor=pointer]
            - button "New chat from here" [ref=e664] [cursor=pointer]
        - 'article "assistant: Message 62 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e665]':
          - generic [ref=e666]: 🤖 Assistant
          - region "Response" [ref=e668]:
            - paragraph [ref=e670]: Message 62 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e671]:
            - time [ref=e672]: 12:00:00 PM
            - button "Copy" [ref=e673] [cursor=pointer]
        - 'article "user: Message 63 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e674]':
          - generic [ref=e675]: 👤 You
          - paragraph [ref=e679]: Message 63 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e680]:
            - time [ref=e681]: 12:00:00 PM
            - button "Copy" [ref=e682] [cursor=pointer]
            - button "Edit from here" [ref=e683] [cursor=pointer]
            - button "New chat from here" [ref=e684] [cursor=pointer]
        - 'article "assistant: Message 64 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e685]':
          - generic [ref=e686]: 🤖 Assistant
          - region "Response" [ref=e688]:
            - paragraph [ref=e690]: Message 64 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e691]:
            - time [ref=e692]: 12:00:00 PM
            - button "Copy" [ref=e693] [cursor=pointer]
        - 'article "user: Message 65 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e694]':
          - generic [ref=e695]: 👤 You
          - paragraph [ref=e699]: Message 65 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e700]:
            - time [ref=e701]: 12:00:00 PM
            - button "Copy" [ref=e702] [cursor=pointer]
            - button "Edit from here" [ref=e703] [cursor=pointer]
            - button "New chat from here" [ref=e704] [cursor=pointer]
        - 'article "assistant: Message 66 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e705]':
          - generic [ref=e706]: 🤖 Assistant
          - region "Response" [ref=e708]:
            - paragraph [ref=e710]: Message 66 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e711]:
            - time [ref=e712]: 12:00:00 PM
            - button "Copy" [ref=e713] [cursor=pointer]
        - 'article "user: Message 67 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e714]':
          - generic [ref=e715]: 👤 You
          - paragraph [ref=e719]: Message 67 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e720]:
            - time [ref=e721]: 12:00:00 PM
            - button "Copy" [ref=e722] [cursor=pointer]
            - button "Edit from here" [ref=e723] [cursor=pointer]
            - button "New chat from here" [ref=e724] [cursor=pointer]
        - 'article "assistant: Message 68 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e725]':
          - generic [ref=e726]: 🤖 Assistant
          - region "Response" [ref=e728]:
            - paragraph [ref=e730]: Message 68 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e731]:
            - time [ref=e732]: 12:00:00 PM
            - button "Copy" [ref=e733] [cursor=pointer]
        - 'article "user: Message 69 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e734]':
          - generic [ref=e735]: 👤 You
          - paragraph [ref=e739]: Message 69 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e740]:
            - time [ref=e741]: 12:00:00 PM
            - button "Copy" [ref=e742] [cursor=pointer]
            - button "Edit from here" [ref=e743] [cursor=pointer]
            - button "New chat from here" [ref=e744] [cursor=pointer]
        - 'article "assistant: Message 70 — contenu contenu contenu contenu contenu contenu contenu contenu con" [ref=e745]':
          - generic [ref=e746]: 🤖 Assistant
          - region "Response" [ref=e748]:
            - paragraph [ref=e750]: Message 70 — contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu contenu
          - generic [ref=e751]:
            - time [ref=e752]: 12:00:00 PM
            - button "Copy" [ref=e753] [cursor=pointer]
        - 'article "user: Nouveau message hors écran" [ref=e754]':
          - generic [ref=e755]: 👤 You
          - paragraph [ref=e759]: Nouveau message hors écran
          - generic [ref=e760]:
            - time [ref=e761]: 12:00:00 PM
            - button "Copy" [ref=e762] [cursor=pointer]
            - button "Edit from here" [ref=e763] [cursor=pointer]
            - button "New chat from here" [ref=e764] [cursor=pointer]
        - 'article "assistant: Mock response" [ref=e765]':
          - generic [ref=e766]: 🤖 Assistant
          - region "Response" [ref=e768]:
            - paragraph [ref=e770]: Mock response
          - generic [ref=e771]:
            - time [ref=e772]: 12:00:00 PM
            - button "Copy" [ref=e773] [cursor=pointer]
      - generic [ref=e774]:
        - button "Back to bottom" [ref=e775] [cursor=pointer]: ↓ Back to bottom (1)
        - textbox "Message composer" [ref=e776]:
          - /placeholder: "Type your message... (Provider: mock)"
        - generic [ref=e777]:
          - button "Add images" [ref=e778]
          - button "Add images" [ref=e779] [cursor=pointer]: ＋📷
          - generic [ref=e780]:
            - generic [ref=e781]: Model
            - combobox "Select the model" [ref=e782]: mock-model
          - combobox "Thinking level" [ref=e783]:
            - option "Auto · off"
            - option "off" [selected]
            - option "minimal"
            - option "low"
            - option "medium"
            - option "high"
            - option "xhigh"
            - option "max"
          - combobox "Tool preset" [ref=e784]:
            - option "Auto · default"
            - option "configured"
            - option "chat-only"
            - option "read-only"
            - option "default" [selected]
            - option "full"
          - combobox "Auto-compaction" [ref=e785]:
            - option "Auto · On" [selected]
            - option "On"
            - option "Off"
          - button "Send" [disabled] [ref=e786]
        - generic "Effective conversation setting scopes" [ref=e787]:
          - group [ref=e788]:
            - generic "New-session model defaults" [ref=e789]: "Model: this conversation"
          - group [ref=e790]:
            - generic "New-session reasoning defaults" [ref=e791]: "Thinking level: this conversation"
          - generic [ref=e792]: "Tools: this conversation"
          - generic [ref=e793]: "Auto-compaction: built-in default"
  - complementary "Workspace explorer" [ref=e794]:
    - generic [ref=e795]:
      - generic [ref=e796]:
        - button "Files" [ref=e797] [cursor=pointer]
        - button "Changes" [ref=e798] [cursor=pointer]
      - generic [ref=e799]:
        - button "Close" [ref=e800] [cursor=pointer]: ×
        - button "Open terminal from file explorer" [ref=e801] [cursor=pointer]: ⌘
        - button "Collapse workspace explorer" [ref=e802] [cursor=pointer]: ›
    - button "Linked directories" [ref=e803] [cursor=pointer]
    - generic [ref=e804]:
      - searchbox "Search files" [ref=e805]
      - button "Refresh files" [ref=e806] [cursor=pointer]: ↻
      - generic "Upload files" [ref=e807] [cursor=pointer]: ↑
    - generic [ref=e809]:
      - text: On conflict
      - combobox "On conflict" [ref=e810]:
        - option "Reject" [selected]
        - option "Keep both"
        - option "Overwrite"
    - generic [ref=e811]:
      - checkbox "Show hidden files" [ref=e812]
      - text: Show hidden files
    - paragraph [ref=e814]: This directory is empty.
  - button "Open workspace terminal" [ref=e815] [cursor=pointer]: ⌘
  - complementary "Status messages"
```

# Test source

```ts
  609 |         },
  610 |         { type: 'text', text: 'Deployment checked.' },
  611 |       ],
  612 |     });
  613 |     await installMockApi(page, { sessions: [session] });
  614 |     await page.goto('/chat/process-session');
  615 | 
  616 |     const process = page.getByLabel('Agent process');
  617 |     await expect(process).toContainText('3 process blocks');
  618 |     await expect(process).toContainText('mock/tool-model');
  619 |     await expect(process).toContainText('1.25s');
  620 |     await expect(process).toContainText('125 tokens');
  621 |     await expect(process).toContainText('$0.001250');
  622 |     const result = process.locator('details').filter({ hasText: 'Tool result: inspect' });
  623 |     await result.locator('summary').click();
  624 |     await expect(result.getByText('truncated')).toBeVisible();
  625 |     await expect(result.getByRole('button', { name: 'Show complete output' })).toBeVisible();
  626 |     await expect(result.getByRole('button', { name: 'Download' })).toBeVisible();
  627 |     await result.getByRole('button', { name: 'Show complete output' }).click();
  628 |     await expect(result).toContainText('complete output');
  629 |   });
  630 | 
  631 |   test('identifie les appels MCP par serveur et outil dans le transcript', async ({ page }) => {
  632 |     const session = mockSession('mcp-process-session', 'MCP process');
  633 |     session.messages.push({
  634 |       id: 'assistant-mcp', role: 'assistant', content: '', timestamp: '2025-01-01T12:00:01.000Z',
  635 |       blocks: [
  636 |         { type: 'tool_call', id: 'mcp-call', name: 'mcp__docs_server__lookup_item__0123456789', input: { query: 'runtime' } },
  637 |         { type: 'tool_result', toolCallId: 'mcp-call', name: 'mcp__docs_server__lookup_item__0123456789', content: '{"found":true}', isError: false },
  638 |       ],
  639 |     });
  640 |     await installMockApi(page, { sessions: [session] });
  641 |     await page.goto('/chat/mcp-process-session');
  642 | 
  643 |     const process = page.getByLabel('Agent process');
  644 |     await expect(process).toContainText('Tool call: MCP docs_server / lookup_item');
  645 |     await expect(process).toContainText('Tool result: MCP docs_server / lookup_item');
  646 |   });
  647 | 
  648 |   test('charge palette et widgets d’extension puis résout une interaction déclarative', async ({ page }) => {
  649 |     const session = mockSession('extension-session', 'Extension interaction');
  650 |     const api = await installMockApi(page, {
  651 |       sessions: [session], holdAgentRun: true,
  652 |       extensionWidgets: [{ name: 'Build status', placement: 'status', content: '<b>plain text only</b>', extensionId: 'e2e-extension' }],
  653 |       extensionInteraction: {
  654 |         id: 'interaction-e2e', kind: 'custom', title: 'Approve deployment', message: 'Choose a safe target.',
  655 |         output: '\u001b[31mValidation required\u001b[0m', ansi: true, createdAt: '2025-01-01T12:00:00.000Z',
  656 |         fields: [
  657 |           { name: 'target', label: 'Target', type: 'select', required: true, options: [{ value: 'staging', label: 'Staging' }] },
  658 |           { name: 'remember', label: 'Remember', type: 'checkbox' },
  659 |         ],
  660 |       },
  661 |     });
  662 |     await page.goto('/chat/extension-session');
  663 | 
  664 |     const panels = page.getByLabel('Extension panels');
  665 |     await expect(panels).toContainText('Build status');
  666 |     await expect(panels).toContainText('<b>plain text only</b>');
  667 |     await expect(panels.locator('b')).toHaveCount(0);
  668 | 
  669 |     const input = page.getByPlaceholder(/Type your message/);
  670 |     await input.fill('/');
  671 |     const palette = page.getByRole('listbox', { name: 'Commands, prompts, and skills' });
  672 |     await expect(palette).toContainText('review');
  673 |     await expect(palette).toContainText('release-notes');
  674 |     await expect(palette).toContainText('approve');
  675 | 
  676 |     await input.fill('Run deployment approval');
  677 |     await page.getByRole('button', { name: 'Send', exact: true }).click();
  678 |     const dialog = page.getByRole('dialog', { name: 'Approve deployment' });
  679 |     await expect(dialog).toContainText('Validation required');
  680 |     await dialog.getByLabel('Target').selectOption('staging');
  681 |     await dialog.getByLabel('Remember').check();
  682 |     await dialog.getByRole('button', { name: 'Submit' }).click();
  683 |     await expect(dialog).toHaveCount(0);
  684 |     await expect.poll(() => api.requests.filter(request => request.path.endsWith('/interactions/interaction-e2e')).at(-1)?.body)
  685 |       .toEqual({ cancelled: false, value: { target: 'staging', remember: true } });
  686 |   });
  687 | 
  688 |   test('préserve le scroll de lecture et permet de revenir en bas', async ({ page }) => {
  689 |     const messages = Array.from({ length: 70 }, (_, index) => ({
  690 |       role: index % 2 ? 'assistant' as const : 'user' as const,
  691 |       content: `Message ${index + 1} — ${'contenu '.repeat(12)}`,
  692 |     }));
  693 |     await installMockApi(page, { sessions: [mockSession('long-session', 'Long historique', messages)] });
  694 |     await page.goto('/chat/long-session');
  695 |     const container = page.locator('.messages-container');
  696 |     await expect.poll(() => container.evaluate(element => element.scrollHeight > element.clientHeight)).toBe(true);
  697 |     await container.evaluate(element => {
  698 |       element.scrollTop = 0;
  699 |       element.dispatchEvent(new Event('scroll'));
  700 |     });
  701 |     const backToBottom = page.getByRole('button', { name: /Back to bottom/ });
  702 |     await expect(backToBottom).toBeVisible();
  703 |     await page.getByPlaceholder(/Type your message/).fill('Nouveau message hors écran');
  704 |     await page.getByRole('button', { name: 'Send', exact: true }).click();
  705 |     await expect.poll(() => page.locator('.message').count()).toBeGreaterThan(70);
  706 |     await expect(backToBottom).toContainText(/\([1-9]\d*\)/);
  707 |     await expect.poll(() => container.evaluate(element => element.scrollTop)).toBeLessThan(100);
  708 |     await backToBottom.click();
> 709 |     await expect.poll(() => container.evaluate(element => element.scrollHeight - element.scrollTop - element.clientHeight < 96)).toBe(true);
      |                                                                                                                                  ^ Error: expect(received).toBe(expected) // Object.is equality
  710 |   });
  711 | 
  712 |   test('suit les agents enfants, signale leur attention et navigue parent/enfant', async ({ page }) => {
  713 |     const parent = mockSession('subagent-parent', 'Coordination');
  714 |     const child = mockSession('subagent-child', 'Explore: inspect sources', [
  715 |       { role: 'assistant', content: 'Inspection complete.' },
  716 |     ]);
  717 |     child.parentId = parent.id;
  718 |     child.metadata = { subagent: true, subagentRunId: 'child-run-complete', subagentProfileId: 'explore' };
  719 |     const api = await installMockApi(page, {
  720 |       sessions: [parent, child],
  721 |       subagentRuns: [
  722 |         {
  723 |           id: 'child-run-complete', parentSessionId: parent.id, childSessionId: child.id,
  724 |           workspaceId: 'workspace-e2e', profileId: 'explore', profileName: 'Explore', task: 'Inspect sources',
  725 |           provider: 'mock', model: 'mock-model', status: 'completed', phase: 'completed', background: true,
  726 |           attention: true, turn: 2, maxTurns: 8, startedAt: '2025-01-01T12:00:00.000Z',
  727 |           completedAt: '2025-01-01T12:00:03.000Z', output: 'Inspection complete.',
  728 |         },
  729 |         {
  730 |           id: 'child-run-active', parentSessionId: parent.id, childSessionId: 'subagent-running-child',
  731 |           workspaceId: 'workspace-e2e', profileId: 'general', profileName: 'General purpose', task: 'Run checks',
  732 |           provider: 'mock', model: 'mock-model', status: 'running', phase: 'tool', background: true,
  733 |           attention: false, turn: 3, maxTurns: 12, startedAt: '2025-01-01T12:00:04.000Z',
  734 |         },
  735 |       ],
  736 |     });
  737 |     await page.goto('/settings');
  738 |     await expect(page.getByText('Explore child agent completed.')).toBeVisible();
  739 |     await page.goto(`/chat/${parent.id}`);
  740 | 
  741 |     const toggle = page.getByRole('button', { name: 'Open child agents (2)' });
  742 |     await expect(toggle.locator('.subagent-toggle-count')).toHaveText('2');
  743 |     await expect(toggle.locator('b')).toHaveText('1');
  744 |     await toggle.click();
  745 |     const panel = page.getByRole('complementary', { name: 'Child agents' });
  746 |     await expect(panel).toContainText('Inspect sources');
  747 |     await expect(panel).toContainText('Turn 3/12 · tool');
  748 |     const active = panel.locator('.subagent-run').filter({ hasText: 'General purpose' });
  749 |     await active.getByRole('button', { name: 'Stop child agent' }).click();
  750 |     await expect(active).toHaveClass(/stopped/);
  751 |     await expect.poll(() => api.requests.filter(request => request.path === '/api/subagents/runs/child-run-active/stop').length).toBe(1);
  752 | 
  753 |     const complete = panel.locator('.subagent-run').filter({ hasText: 'Explore' });
  754 |     await complete.getByRole('button', { name: 'Open details' }).click();
  755 |     await expect(page).toHaveURL(/\/chat\/subagent-child/);
  756 |     await expect(page.getByRole('button', { name: 'Back to parent agent' })).toBeVisible();
  757 |     await page.getByRole('button', { name: 'Back to parent agent' }).click();
  758 |     await expect(page).toHaveURL(/\/chat\/subagent-parent/);
  759 |   });
  760 | 
  761 |   test('rend Markdown, tableau, raisonnement, outils et HTML comme texte sûr', async ({ page }) => {
  762 |     const session = mockSession('formatted-session', 'Réponse formatée', [{
  763 |       role: 'assistant',
  764 |       content: '# Titre\n\nUtilisez `npm test` et $x^2$.\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n```ts\nconst safe = "<script>";\n```\n\n```mermaid\nflowchart TD\nA[Start] --> B[Done]\n```\n<script>alert(1)</script>',
  765 |     }]);
  766 |     session.messages[0]!.model = 'mock-rich-model';
  767 |     session.messages[0]!.usage = {
  768 |       inputTokens: 1_000, outputTokens: 500, cacheReadTokens: 250, totalTokens: 1_500, costUsd: 0.0123,
  769 |     };
  770 |     session.messages[0]!.blocks = [
  771 |       { type: 'reasoning', text: 'Résumé du raisonnement' },
  772 |       { type: 'text', text: session.messages[0]!.content },
  773 |       { type: 'tool_call', id: 'tool-1', name: 'write', input: { path: 'src/generated.ts', content: 'export {};' } },
  774 |     ];
  775 |     await installMockApi(page, {
  776 |       sessions: [session],
  777 |       workspaceFiles: [{ path: 'src/generated.ts', content: 'export {};', language: 'typescript' }],
  778 |     });
  779 |     await page.goto('/chat/formatted-session');
  780 | 
  781 |     await expect(page.locator('.message-content h1')).toHaveText('Titre');
  782 |     await expect(page.locator('code.inline-code')).toHaveText('npm test');
  783 |     await expect(page.locator('table')).toContainText('2');
  784 |     await expect(page.locator('pre.code-block code')).toContainText('const safe = "<script>";');
  785 |     await expect(page.locator('pre.code-block .syntax-keyword').filter({ hasText: /^const$/ })).toHaveCount(1);
  786 |     await expect(page.locator('.katex')).toBeVisible();
  787 |     await expect(page.getByLabel('Mermaid diagram').locator('svg')).toBeVisible();
  788 |     await expect(page.getByLabel('Mermaid diagram')).toContainText('Start');
  789 |     const mermaid = page.locator('.mermaid-block');
  790 |     const zoom = mermaid.getByRole('button', { name: 'Zoom' });
  791 |     await zoom.click();
  792 |     await expect(page.getByRole('dialog', { name: 'Mermaid diagram' })).toBeVisible();
  793 |     await page.keyboard.press('Escape');
  794 |     await expect(zoom).toBeFocused();
  795 |     const download = page.waitForEvent('download');
  796 |     await mermaid.getByRole('button', { name: 'Download' }).click();
  797 |     expect((await download).suggestedFilename()).toBe('diagram.svg');
  798 |     await expect(page.locator('.message-content script')).toHaveCount(0);
  799 |     await expect(page.locator('.message-content')).not.toContainText('alert(1)');
  800 |     await expect(page.locator('details.reasoning-block')).toContainText('Résumé du raisonnement');
  801 |     await expect(page.locator('details.tool-block')).toContainText('write');
  802 | 
  803 |     const message = page.locator('.message.assistant');
  804 |     await expect(message.locator('time')).toHaveAttribute('datetime', '2025-01-01T12:00:00.000Z');
  805 |     await expect(message.locator('.message-meta')).toContainText('mock-rich-model');
  806 |     await expect(message.locator('.message-meta')).toContainText(/1[,.\s]500 tokens · \$0\.0123/);
  807 |     await expect(message.locator('.message-meta span[title]')).toHaveAttribute('title', /1[,.\s]000 input.*500 output.*250 cache read/);
  808 |     await message.locator('.message-meta').getByRole('button', { name: 'Copy' }).click();
  809 |     await expect(message.locator('.message-meta').getByRole('button', { name: 'Assistant response copied.' })).toBeVisible();
```