start=2026-11-16T17:58:01Z
command=make test-e2e IMAGE_TEST=aih-qua02:overlay-owning E2E_ARGS="e2e/terminal-controls.spec.ts --reporter=line,json --trace=on"
exit=0
end=2026-11-16T17:58:58Z
