start=2026-11-16T18:00:31Z
source=07bceeca6342d9add499cf10a521cce0649c7f0c
command=make test IMAGE_TEST_RUN=aih-qua02:overlay-root-20261116
exit=2
end=2026-11-16T18:53:30Z
