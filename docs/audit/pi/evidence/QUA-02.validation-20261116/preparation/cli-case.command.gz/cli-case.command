start=2026-11-16T18:54:35Z
source=07bceeca6342d9add499cf10a521cce0649c7f0c
command=npm test -- packages/cli/src/cli/openrouter-process.test.ts -t rpc/native=true preserves anthropic-messages and explicit credential composition$
reason=One unchanged exact-case non-reproduction control for the current emitted CLI child SIGTRAP, not a compiler waiver or repeated root.
exit=0
end=2026-11-16T18:54:36Z
