start=2026-11-16T20:02:56Z
command=docker build --progress=plain -f Dockerfile.collector -t aih-qua02:collector-overlay-20261116 .
nativeBase=sha256:44f92c315e2f5f6473e56a06eb61bf4a0e844234f58a1f750ffee35342aafb11
reference=sha256:2d291cd9a43500455e460b5da35ab71ec486b769e14734ae4057420b4394974f
collectorSha256=72f1f4a0afcf3891397db4371394a110f2c6777781db14b319a33f95bc2bc5ec
exit=0
end=2026-11-16T20:03:42Z
